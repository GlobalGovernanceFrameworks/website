# GGF schema status rationalisation

Applies the final status-field migration on top of the GEM migration v2 and hardened-validator integration.

## Install

Copy the 15 files under `replacement-files/` into `src/lib/data/schema/`.

`complete-schema/` is a full snapshot of all schema TypeScript files after the migration, for comparison or wholesale replacement.

## Status vocabulary

```ts
status?: 'Proposed' | 'Draft' | 'Review' | 'Stable' | 'Pilot' | 'Retired';
```

The field is internal and is not an adoption or deployment claim. External validation remains represented only by `ui.outline.maturity` / `ui.prose.maturity`.

## Mechanical changes

- `Ready` → `Stable`: 22 entities (21 published frameworks plus the unpublished Pathfinder Program process)
- Removed unused union values: `Implemented`, `Active`, `Coming-Soon`, `Planned`, `Ready`
- `framework_consciousness_development`: `Planned` → `Proposed`

## Published `Planned` decisions

- `framework_memorial_commons` → `Draft`
  - Version 0.8 and its standfirst explicitly describe it as a proposal/design document.
- `framework_prometheus_protocol` → `Review`
  - Published and extensively developed, but its own standfirst says the prior implementation-ready claim is unsupported.
- `framework_discovery_commons` → `Review`
  - Published v1.1 with substantive recent revisions, without evidence that the text is stable.
- `framework_kintsugi_protocol` → `Review`
  - Published v2.2.1 with recent constitutional bounding and no explicit stability claim.
- `framework_implementation_adaptation` → `Review`
  - Published v1.1.1 and recently revised to remove residual authority; it exists but is still being reviewed.

## Validator change

Removed `maturity-overstated`. Added `publication-status-mismatch`:

- published + `Proposed` is a warning;
- unpublished + `Draft`, `Review`, or `Stable` is a warning;
- retirement status/provenance checks remain unchanged.

## Verification

Strict TypeScript compilation passes.

With the existing baseline:

- 2 errors
- 102 warnings
- 265 info
- 0 stale baseline entries

The two errors remain the pre-existing blockers:

1. duplicate `protocol_ethical_ip` ID;
2. Millennium Protocol ↔ Deep Time dependency cycle.

The warning increase is expected:

- 21 `maturity-overstated` warnings were removed;
- 76 `publication-status-mismatch` warnings were added;
- net change from 47 to 102 warnings.

The 76 mismatches are 75 unpublished entities carrying `Draft`, plus the unpublished `process_pathfinder_program` carrying `Stable`. This is newly visible debt rather than a regression introduced by the migration.

## Resulting status distribution

Published entities (73):

- Draft: 6
- Review: 46
- Stable: 21

Unpublished entities (255):

- Proposed: 157
- Draft: 75
- Pilot: 17
- Stable: 1
- Retired: 5

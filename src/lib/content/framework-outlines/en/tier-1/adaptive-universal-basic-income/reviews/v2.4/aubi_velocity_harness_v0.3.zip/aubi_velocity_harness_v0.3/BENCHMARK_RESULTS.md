# Benchmark results — v0.2, seed 7, 250 replicates per state

The clean benchmark sampled 3,000 synthetic pure-state cases: 250 noisy realizations of each of the twelve hidden states. Sampling is deterministic for a fixed seed.

| Policy / observation view | State accuracy | Specific intervention accuracy | Safe action rate | Harmful intervention rate | Unresolved rate |
|---|---:|---:|---:|---:|---:|
| Current provider heuristic | 8.3% | 8.3% | 8.3% | 58.3% | 0.0% |
| Current demurrage heuristic | 0.0% | 0.0% | 0.1% | 99.9% | 0.1% |
| Conservative current response | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, current view | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, decomposed view | 25.1% | 25.1% | 100.0% | 0.0% | 74.9% |
| Nearest prototype, full view | 99.3% | 99.3% | 100.0% | 0.0% | 0.7% |

## Interpretation

- The **current dashboard contains zero prototype separation by construction**. All twelve states have identical headline values, so a responsible evaluator records `cause unresolved`.
- Direct provider or demurrage responses are unsafe because they act on one possible cause as though it were identified.
- Decomposed financial telemetry identifies some states—especially concentration and unusual redemption—but leaves most cases unresolved.
- The full proposed sensor portfolio makes the twelve designed pure prototypes almost completely separable at the default noise level.
- The adversarial audit demonstrates that this clean result does **not** generalize to mixed states, correlated observation failures, or coordinated reporting attacks.

These results establish only internal separability of the pure synthetic corpus. They do not validate the numerical prototypes, state frequencies, observation channels, or real-world intervention effects.

# Non-additive interaction gate — v0.3, seed 29, 300 replicates per interaction

The v0.3 gate sampled 2,400 synthetic joint-state cases across eight interaction specifications.

| Measure | Result |
|---|---:|
| Cautious pure-state unresolved rate | 85.8% |
| Both active constituents recalled in top two | 59.2% |
| Additive pair accuracy | 87.2% |
| Interaction-aware pair accuracy | 99.8% |
| Path-dependence rate | 73.9% |
| Preferred order wins | 73.9% |
| Forced singular action has >0.02 utility regret | 76.6% |
| Forced singular action reduces utility | 11.7% |
| Demurrage improves velocity while reducing utility | 100.0% |

Two interactions are intentionally order-insensitive negative controls. Among the six interaction specifications designed to contain sequencing effects, the preferred order wins in approximately 98.5% of cases.

The 100% demurrage divergence is a property of the deliberately adversarial transition fixture, not an empirical estimate. It demonstrates that a mechanism indicator can improve while the purpose variables deteriorate.

See `NONADDITIVE_INTERACTION_AUDIT.md` for the full interpretation and limitations.

"""Benchmarks for the adversarial corpus audit."""

from __future__ import annotations

import csv
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

from .adversarial import (
    ACTOR_FIELDS,
    ATTACK_PROFILES,
    ambiguous_midpoint,
    apply_correlated_failure,
    blend_cases,
    find_minimum_targeted_attack,
    harmful_target_states,
    integrity_gated_diagnosis,
    stratified_mixture_diagnosis,
)
from .model import (
    Diagnosis,
    field_value,
    intervention_is_harmful,
    nearest_prototype_diagnosis,
    sample_case,
)
from .scenarios import SCENARIOS, Scenario
from .views import FIELD_DEFAULTS, FULL_FIELDS


def _conflicting_pairs() -> List[Tuple[Scenario, Scenario]]:
    return [
        (a, b)
        for i, a in enumerate(SCENARIOS)
        for b in SCENARIOS[i + 1 :]
        if a.primary_intervention != b.primary_intervention
    ]


def mixture_benchmark(
    replicates_per_pair: int = 50,
    seed: int = 19,
    noise_scale: float = 1.0,
    min_weight: float = 0.20,
    max_weight: float = 0.80,
) -> List[Dict[str, float]]:
    rng = random.Random(seed)
    policies = {
        "aggregate_full": lambda case: nearest_prototype_diagnosis(case.aggregate, "full"),
        "stratified_full": stratified_mixture_diagnosis,
    }
    counters: Dict[str, Dict[str, float]] = {
        name: defaultdict(float) for name in policies
    }
    pairs = _conflicting_pairs()
    for left, right in pairs:
        for _ in range(replicates_per_pair):
            w = rng.uniform(min_weight, max_weight)
            mixed = blend_cases(left, right, w, rng, noise_scale=noise_scale)
            for name, policy in policies.items():
                d = policy(mixed)
                c = counters[name]
                c["n"] += 1
                c["unresolved"] += int(d.unresolved)
                c["heterogeneity_detected"] += int(d.predicted_state == "mixed_or_heterogeneous")
                c["component_state_hit"] += int(d.predicted_state in {left.name, right.name})
                if not d.unresolved:
                    c["false_singular"] += 1
                c["partial_action"] += int(
                    d.intervention in left.acceptable_interventions
                    or d.intervention in right.acceptable_interventions
                )
                c["full_action_coverage"] += int(
                    d.intervention in left.acceptable_interventions
                    and d.intervention in right.acceptable_interventions
                )
                c["harmful_to_any_component"] += int(
                    d.intervention in left.harmful_interventions
                    or d.intervention in right.harmful_interventions
                )
    rows = []
    for name, c in counters.items():
        n = max(c["n"], 1)
        rows.append(
            {
                "policy": name,
                "n": int(c["n"]),
                "unresolved_rate": c["unresolved"] / n,
                "heterogeneity_detection_rate": c["heterogeneity_detected"] / n,
                "false_singular_rate": c["false_singular"] / n,
                "component_state_hit_rate": c["component_state_hit"] / n,
                "partial_action_rate": c["partial_action"] / n,
                "full_action_coverage_rate": c["full_action_coverage"] / n,
                "harmful_to_any_component_rate": c["harmful_to_any_component"] / n,
            }
        )
    return rows


def correlated_failure_benchmark(
    replicates_per_state: int = 100,
    seed: int = 23,
    noise_scale: float = 1.0,
) -> List[Dict[str, float]]:
    rng = random.Random(seed)
    rows: List[Dict[str, float]] = []
    for profile in ATTACK_PROFILES:
        for concealed in (False, True):
            for policy_name in ("nearest_full", "integrity_gated"):
                n = correct = unresolved = harmful = safe = 0
                for scenario in SCENARIOS:
                    for _ in range(replicates_per_state):
                        clean = sample_case(scenario, rng, noise_scale=noise_scale)
                        obs = apply_correlated_failure(
                            clean.observations, profile, concealed=concealed
                        )
                        diagnosis = (
                            nearest_prototype_diagnosis(obs, "full")
                            if policy_name == "nearest_full"
                            else integrity_gated_diagnosis(obs)
                        )
                        n += 1
                        correct += int(diagnosis.predicted_state == scenario.name)
                        unresolved += int(diagnosis.unresolved)
                        harmful += int(
                            diagnosis.intervention in scenario.harmful_interventions
                        )
                        safe += int(
                            diagnosis.unresolved
                            or diagnosis.intervention in scenario.acceptable_interventions
                        )
                rows.append(
                    {
                        "profile": profile.name,
                        "concealed": concealed,
                        "policy": policy_name,
                        "n": n,
                        "state_accuracy": correct / n,
                        "unresolved_rate": unresolved / n,
                        "safe_action_rate": safe / n,
                        "harmful_intervention_rate": harmful / n,
                    }
                )
    return rows


def ambiguity_margin_sweep(
    replicates_per_pair: int = 100,
    seed: int = 29,
    noise_scale: float = 0.6,
    margins: Sequence[float] = (0.02, 0.07, 0.12, 0.20),
) -> List[Dict[str, float]]:
    rng = random.Random(seed)
    pairs = _conflicting_pairs()
    rows: List[Dict[str, float]] = []
    for margin in margins:
        ambiguous_n = false_resolution = conflict_risk = 0
        for left, right in pairs:
            for _ in range(replicates_per_pair):
                case = ambiguous_midpoint(left, right, rng, noise_scale=noise_scale)
                diagnosis = nearest_prototype_diagnosis(
                    case.observations, "full", unresolved_margin=margin
                )
                ambiguous_n += 1
                false_resolution += int(not diagnosis.unresolved)
                conflict_risk += int(
                    not diagnosis.unresolved
                    and (
                        diagnosis.intervention in left.harmful_interventions
                        or diagnosis.intervention in right.harmful_interventions
                    )
                )

        pure_n = pure_correct = pure_unresolved = 0
        for scenario in SCENARIOS:
            for _ in range(replicates_per_pair * 2):
                case = sample_case(scenario, rng, noise_scale=1.0)
                d = nearest_prototype_diagnosis(
                    case.observations, "full", unresolved_margin=margin
                )
                pure_n += 1
                pure_correct += int(d.predicted_state == scenario.name)
                pure_unresolved += int(d.unresolved)
        rows.append(
            {
                "unresolved_margin": margin,
                "ambiguous_n": ambiguous_n,
                "ambiguous_correct_restraint_rate": 1.0 - false_resolution / ambiguous_n,
                "ambiguous_false_resolution_rate": false_resolution / ambiguous_n,
                "ambiguous_conflict_risk_rate": conflict_risk / ambiguous_n,
                "pure_state_accuracy": pure_correct / pure_n,
                "pure_unresolved_rate": pure_unresolved / pure_n,
            }
        )
    return rows


def strategic_reporting_audit() -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for source in SCENARIOS:
        for target in harmful_target_states(source):
            for actor in ACTOR_FIELDS:
                result = find_minimum_targeted_attack(source, target, actor)
                rows.append(
                    {
                        "source_state": result.source_state,
                        "target_state": result.target_state,
                        "target_intervention": result.target_intervention,
                        "actor": result.actor,
                        "success": result.success,
                        "alpha": result.alpha,
                        "normalized_cost": result.normalized_cost,
                        "changed_fields": result.changed_fields,
                        "resulting_state": result.resulting_state,
                        "resulting_intervention": result.resulting_intervention,
                    }
                )
    return rows


def sensor_group_ablation(
    replicates_per_state: int = 150,
    seed: int = 31,
) -> List[Dict[str, object]]:
    rng = random.Random(seed)
    # Mean imputation intentionally hides the group without signalling missingness.
    field_means = {
        field: statistics.mean(field_value(s, field) for s in SCENARIOS)
        for field in FULL_FIELDS
    }
    rows: List[Dict[str, object]] = []
    groups = {**ACTOR_FIELDS, "none": frozenset()}
    for group_name, fields in groups.items():
        n = correct = unresolved = harmful = 0
        for scenario in SCENARIOS:
            for _ in range(replicates_per_state):
                case = sample_case(scenario, rng, noise_scale=1.0)
                obs = dict(case.observations)
                for field in fields & FULL_FIELDS:
                    obs[field] = field_means[field]
                d = nearest_prototype_diagnosis(obs, "full")
                n += 1
                correct += int(d.predicted_state == scenario.name)
                unresolved += int(d.unresolved)
                harmful += int(d.intervention in scenario.harmful_interventions)
        rows.append(
            {
                "ablated_group": group_name,
                "n": n,
                "state_accuracy": correct / n,
                "unresolved_rate": unresolved / n,
                "harmful_intervention_rate": harmful / n,
                "fields_ablated": len(fields & FULL_FIELDS),
            }
        )
    return rows


def write_csv(rows: Sequence[Mapping[str, object]], path: Path) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_json(data: Mapping[str, object], path: Path) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def run_all(
    output_dir: Path,
    mixture_replicates: int = 50,
    failure_replicates: int = 100,
    ambiguity_replicates: int = 100,
) -> Dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    results: Dict[str, object] = {
        "mixtures": mixture_benchmark(replicates_per_pair=mixture_replicates),
        "correlated_failures": correlated_failure_benchmark(
            replicates_per_state=failure_replicates
        ),
        "ambiguity_margin_sweep": ambiguity_margin_sweep(
            replicates_per_pair=ambiguity_replicates
        ),
        "strategic_reporting": strategic_reporting_audit(),
        "sensor_group_ablation": sensor_group_ablation(),
    }
    write_json(results, output_dir / "adversarial_results.json")
    for key, value in results.items():
        if isinstance(value, list) and value:
            write_csv(value, output_dir / f"{key}.csv")
    return results

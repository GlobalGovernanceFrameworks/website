# Source map

The harness preserves the terminology and control architecture of the four supplied framework files while adding a synthetic diagnostic layer.

## AUBI Framework v2.4

- **§2.3:** LMCI-Measurement and LMCI-Allocation are separate pipelines.
- **§4.1–4.4:** Social Resilience Council, slow-variable quorum, institutional drift, and adversarial observation.
- **§5.0–5.3:** Layer 0 sacredness boundary, universal baseline, Layer 2 contribution bonuses, and Layer 3 needs/equity.
- **§7.4:** BAZ Starter Pack, provider categories, 30-day Hearts velocity, 90-day dormancy, reserves, fraud, and progression rules.
- **§7.6:** Minimum viable implementation and graceful degradation.
- **§8:** LMCI-M sources, validation, and success indicators.

## Financial Systems Framework v3.3

- **§2.1:** Data ethics, privacy, and public transaction auditability.
- **§4.1–4.3:** Social-trust to cryptographic-trust transition and Heartstarter reserve enforcement.
- **§7:** Financial governance, valuation standards, conflict resolution, and early capture detection.
- **§14:** Inter-Currency Translation Layer, rate bands, notice and objection protocol, response latency, and risk monitoring.
- **Appendix M:** Inflation, fraud, rapid adoption, and other stress scenarios.

## Nested Economies Framework v3.1b

- **§2:** Local BAZ economies, cross-level interfaces, provider systems, and value translation.
- **§5:** Local/global decision rights, BAZ objections, and slow-variable constraints.
- **§7:** Dashboard expectations for LMCI, velocity, and care activity.
- **§8:** Community Weaver training, engagement, and validation role.

## Work in Liberation Framework v1.9

- **§2.4–2.5:** Provider finance, service validation, need broadcasting, capacity signals, and fluid project assembly.
- **§3–4:** FLP governance, Community Work App, Love Ledger, Green Job Score, and service tracking.
- **§11:** Public Trust Dashboard and external outcome indicators.
- **§13:** Community Weaver role.
- **§17:** Dispute resolution.

## Added by the harness

The following are audit constructions rather than source claims:

- the twelve synthetic latent-state prototypes;
- all numerical prototype values and noise levels;
- current, decomposed, and full observation views;
- nearest-prototype estimator;
- harm and intervention maps;
- benchmark thresholds and performance;
- interactive quiz and calibration scoring.

## v0.2 adversarial additions

The following are audit constructions rather than claims found in the supplied frameworks:

- cross-state mixture generator;
- genuine ambiguity midpoint corpus;
- Weaver optimism, survey chilling, ledger suppression, and Treasury smoothing profiles;
- actor-control field sets for strategic reporting;
- normalized attack-cost definition;
- observation-independence metadata fields;
- unresolved-margin sweep;
- sensor-group ablation protocol;
- all numerical attack magnitudes and adversarial benchmark thresholds.

They operationalize risks already identified in the parent observability audit: aggregation blindness, common-source dependence, false identifiability, strategic reporting, and the need to preserve an unresolved outcome. They should not be read as empirical estimates of actual BAZ behavior.


## v0.3 non-additive additions

The following remain audit constructions rather than source claims:

- the eight pairwise interaction specifications;
- bilinear interaction terms and their field shifts;
- additive and interaction-aware pair classifiers;
- the synthetic welfare vector and composite utility;
- all intervention transition functions;
- preferred and reverse intervention sequences;
- the demurrage metric–welfare divergence stress case;
- all numerical results and thresholds in the non-additive benchmark.

These operationalize the parent audit's question of whether multiple causal states and interventions remain separable. They do not establish real causal effects, action order, or welfare weights for an implemented Hearts economy.

import random
import tempfile
import unittest
from pathlib import Path

from aubi_velocity_harness.nonadditive import (
    INTERACTIONS,
    additive_interaction_prototype,
    interaction_residual,
    nonadditive_interaction_prototype,
    sample_interaction_case,
    simulate_sequence,
)
from aubi_velocity_harness.nonadditive_benchmark import run_nonadditive_audit


class NonAdditiveHarnessTests(unittest.TestCase):
    def test_interaction_term_is_nonzero_at_balanced_joint_state(self):
        for spec in INTERACTIONS:
            additive = additive_interaction_prototype(spec, left_weight=0.5)
            joint = nonadditive_interaction_prototype(spec, left_weight=0.5, strength=1.0)
            self.assertTrue(
                any(abs(joint[field] - additive[field]) > 1e-9 for field in spec.interaction_shifts)
            )

    def test_sampled_cases_have_positive_nonadditive_residual(self):
        rng = random.Random(11)
        for spec in INTERACTIONS:
            case = sample_interaction_case(spec, rng, noise_scale=0.0)
            self.assertGreater(interaction_residual(case), 0.05)

    def test_demurrage_can_improve_velocity_while_reducing_utility(self):
        rng = random.Random(17)
        for spec in INTERACTIONS:
            case = sample_interaction_case(spec, rng, noise_scale=0.0)
            result = simulate_sequence(case, ("increase_demurrage",))
            self.assertGreater(result.velocity_change, 0.0)
            self.assertLess(result.final_utility, result.initial_utility)

    def test_preferred_order_weakly_dominates_reverse(self):
        rng = random.Random(23)
        for spec in INTERACTIONS:
            case = sample_interaction_case(spec, rng, noise_scale=0.0)
            preferred = simulate_sequence(case, spec.preferred_sequence)
            reverse = simulate_sequence(case, spec.reverse_sequence)
            self.assertGreaterEqual(preferred.final_utility + 1e-9, reverse.final_utility)

    def test_nonadditive_audit_is_reproducible(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = run_nonadditive_audit(root / "a", replicates_per_interaction=15, seed=31)
            second = run_nonadditive_audit(root / "b", replicates_per_interaction=15, seed=31)
            self.assertEqual(first, second)
            self.assertEqual(
                (root / "a" / "nonadditive_results.json").read_bytes(),
                (root / "b" / "nonadditive_results.json").read_bytes(),
            )

    def test_interaction_aware_model_improves_over_additive(self):
        with tempfile.TemporaryDirectory() as directory:
            result = run_nonadditive_audit(
                Path(directory), replicates_per_interaction=40, seed=37
            )
            overall = result["overall"]
            self.assertGreater(
                overall["interaction_aware_pair_accuracy"],
                overall["additive_pair_accuracy"],
            )
            self.assertEqual(
                overall["demurrage_metric_welfare_divergence_rate"], 1.0
            )


if __name__ == "__main__":
    unittest.main()

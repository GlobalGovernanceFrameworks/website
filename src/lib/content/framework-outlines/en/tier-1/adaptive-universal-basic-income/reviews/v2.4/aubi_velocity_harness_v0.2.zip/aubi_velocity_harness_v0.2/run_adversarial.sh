#!/usr/bin/env bash
set -euo pipefail
python -m aubi_velocity_harness adversarial-audit --output adversarial_outputs "$@"

"""Benchmark policies and observation views over the twelve-state corpus."""

from __future__ import annotations

import csv
import random
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Mapping, MutableMapping, Sequence, Tuple

from .model import (
    Diagnosis,
    conservative_current_policy,
    current_demurrage_heuristic,
    current_provider_heuristic,
    intervention_is_acceptable,
    intervention_is_harmful,
    intervention_is_safe,
    nearest_prototype_diagnosis,
    sample_case,
    state_is_correct,
)
from .scenarios import SCENARIOS, Scenario


@dataclass
class Metrics:
    n: int = 0
    state_correct: int = 0
    intervention_correct: int = 0
    safe_action: int = 0
    harmful: int = 0
    unresolved: int = 0
    confidence_sum: float = 0.0
    brier_sum: float = 0.0

    def update(self, scenario: Scenario, diagnosis: Diagnosis) -> None:
        self.n += 1
        correct = state_is_correct(scenario, diagnosis)
        self.state_correct += int(correct)
        self.intervention_correct += int(intervention_is_acceptable(scenario, diagnosis.intervention))
        self.safe_action += int(intervention_is_safe(scenario, diagnosis.intervention))
        self.harmful += int(intervention_is_harmful(scenario, diagnosis.intervention))
        self.unresolved += int(diagnosis.unresolved)
        self.confidence_sum += diagnosis.confidence
        self.brier_sum += (diagnosis.confidence - float(correct)) ** 2

    def as_dict(self) -> Dict[str, float]:
        n = max(self.n, 1)
        return {
            "n": self.n,
            "state_accuracy": self.state_correct / n,
            "specific_intervention_accuracy": self.intervention_correct / n,
            "safe_action_rate": self.safe_action / n,
            "harmful_intervention_rate": self.harmful / n,
            "unresolved_rate": self.unresolved / n,
            "mean_confidence": self.confidence_sum / n,
            "confidence_brier": self.brier_sum / n,
        }


Policy = Callable[[Mapping[str, float]], Diagnosis]


def benchmark(
    replicates_per_state: int = 250,
    seed: int = 7,
    noise_scale: float = 1.0,
) -> Tuple[List[Dict[str, float]], Dict[str, Counter]]:
    rng = random.Random(seed)
    policies: Dict[str, Policy] = {
        "current_provider_heuristic": current_provider_heuristic,
        "current_demurrage_heuristic": current_demurrage_heuristic,
        "current_conservative": conservative_current_policy,
        "nearest_current": lambda obs: nearest_prototype_diagnosis(obs, "current"),
        "nearest_decomposed": lambda obs: nearest_prototype_diagnosis(obs, "decomposed"),
        "nearest_full": lambda obs: nearest_prototype_diagnosis(obs, "full"),
    }
    aggregate = {name: Metrics() for name in policies}
    confusions: Dict[str, Counter] = {name: Counter() for name in policies}

    for scenario in SCENARIOS:
        for _ in range(replicates_per_state):
            case = sample_case(scenario, rng, noise_scale=noise_scale)
            for name, policy in policies.items():
                diagnosis = policy(case.observations)
                aggregate[name].update(scenario, diagnosis)
                confusions[name][(scenario.name, diagnosis.predicted_state)] += 1

    rows = []
    for name, metrics in aggregate.items():
        row: Dict[str, float] = {"policy": name}
        row.update(metrics.as_dict())
        rows.append(row)
    return rows, confusions


def write_csv(rows: Sequence[Mapping[str, object]], path: Path) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def format_table(rows: Sequence[Mapping[str, object]]) -> str:
    columns = [
        "policy",
        "state_accuracy",
        "specific_intervention_accuracy",
        "safe_action_rate",
        "harmful_intervention_rate",
        "unresolved_rate",
        "mean_confidence",
    ]
    widths = {c: max(len(c), max(len(_fmt(r[c])) for r in rows)) for c in columns}
    header = "  ".join(c.ljust(widths[c]) for c in columns)
    sep = "  ".join("-" * widths[c] for c in columns)
    lines = [header, sep]
    for row in rows:
        lines.append("  ".join(_fmt(row[c]).ljust(widths[c]) for c in columns))
    return "\n".join(lines)


def _fmt(value: object) -> str:
    if isinstance(value, float):
        return f"{value:.3f}"
    return str(value)

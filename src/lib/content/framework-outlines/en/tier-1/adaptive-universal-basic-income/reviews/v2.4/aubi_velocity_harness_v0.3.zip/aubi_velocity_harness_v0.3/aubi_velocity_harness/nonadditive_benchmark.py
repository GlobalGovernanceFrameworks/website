"""Benchmark the non-additive interaction falsification gate."""

from __future__ import annotations

import csv
import json
import random
from collections import Counter
from pathlib import Path
from typing import Dict, List, Mapping

from .model import nearest_prototype_diagnosis
from .nonadditive import (
    INTERACTIONS,
    constituent_recall,
    interaction_residual,
    pair_diagnosis,
    pure_classifier_action,
    sample_interaction_case,
    simulate_sequence,
)


def _rate(count: int, total: int) -> float:
    return count / total if total else 0.0


def run_nonadditive_audit(
    output_dir: Path,
    replicates_per_interaction: int = 300,
    seed: int = 29,
    noise_scale: float = 1.0,
) -> Dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)

    static_rows: List[Dict[str, object]] = []
    dynamic_rows: List[Dict[str, object]] = []
    interaction_summaries: List[Dict[str, object]] = []

    aggregate = Counter()

    for spec in INTERACTIONS:
        local = Counter()
        residual_sum = 0.0
        preferred_gain_sum = 0.0
        reverse_gain_sum = 0.0
        myopic_gain_sum = 0.0
        demurrage_utility_change_sum = 0.0

        for replicate in range(replicates_per_interaction):
            case = sample_interaction_case(spec, rng, noise_scale=noise_scale)
            pure = nearest_prototype_diagnosis(case.observations, "full")
            forced_pure = nearest_prototype_diagnosis(
                case.observations, "full", unresolved_margin=0.0
            )
            additive = pair_diagnosis(case.observations, interaction_aware=False)
            aware = pair_diagnosis(case.observations, interaction_aware=True)

            recall = constituent_recall(pure, spec, k=2)
            false_singular = int(not pure.unresolved)
            additive_correct = int(additive.predicted_interaction == spec.name)
            aware_correct = int(aware.predicted_interaction == spec.name)
            residual = interaction_residual(case)

            preferred = simulate_sequence(case, spec.preferred_sequence)
            reverse = simulate_sequence(case, spec.reverse_sequence)
            myopic_action = pure_classifier_action(case)
            myopic = simulate_sequence(case, (myopic_action,))
            forced_myopic_action = forced_pure.intervention
            forced_myopic = simulate_sequence(case, (forced_myopic_action,))
            demurrage = simulate_sequence(case, ("increase_demurrage",))

            preferred_gain = preferred.final_utility - preferred.initial_utility
            reverse_gain = reverse.final_utility - reverse.initial_utility
            myopic_gain = myopic.final_utility - myopic.initial_utility
            forced_myopic_gain = (
                forced_myopic.final_utility - forced_myopic.initial_utility
            )
            demurrage_utility_change = demurrage.final_utility - demurrage.initial_utility

            path_dependent = int(abs(preferred.final_utility - reverse.final_utility) > 0.010)
            preferred_better = int(preferred.final_utility > reverse.final_utility + 1e-9)
            metric_welfare_divergence = int(
                demurrage.velocity_change > 0.05 and demurrage_utility_change < -0.005
            )
            myopic_regret = max(0.0, preferred.final_utility - myopic.final_utility)
            forced_myopic_regret = max(
                0.0, preferred.final_utility - forced_myopic.final_utility
            )

            local.update(
                {
                    "cases": 1,
                    "pure_false_singular": false_singular,
                    "cautious_unresolved": int(pure.unresolved),
                    "pure_both_constituents": int(recall == 1.0),
                    "additive_pair_correct": additive_correct,
                    "aware_pair_correct": aware_correct,
                    "path_dependent": path_dependent,
                    "preferred_better": preferred_better,
                    "metric_welfare_divergence": metric_welfare_divergence,
                    "myopic_action_unsafe": int(myopic_action in spec.unsafe_single_actions),
                    "myopic_negative_gain": int(myopic_gain < 0.0),
                    "forced_myopic_action_unsafe": int(
                        forced_myopic_action in spec.unsafe_single_actions
                    ),
                    "forced_myopic_negative_gain": int(forced_myopic_gain < 0.0),
                    "forced_myopic_material_regret": int(
                        forced_myopic_regret > 0.020
                    ),
                }
            )
            residual_sum += residual
            preferred_gain_sum += preferred_gain
            reverse_gain_sum += reverse_gain
            myopic_gain_sum += myopic_gain
            demurrage_utility_change_sum += demurrage_utility_change

            if replicate < 25:
                static_rows.append(
                    {
                        "interaction": spec.name,
                        "replicate": replicate,
                        "left_weight": case.left_weight,
                        "interaction_strength": case.interaction_strength,
                        "nonadditive_residual": residual,
                        "pure_prediction": pure.predicted_state,
                        "pure_unresolved": pure.unresolved,
                        "constituent_recall_at_2": recall,
                        "additive_pair_prediction": additive.predicted_interaction,
                        "interaction_aware_prediction": aware.predicted_interaction,
                    }
                )
                dynamic_rows.append(
                    {
                        "interaction": spec.name,
                        "replicate": replicate,
                        "preferred_sequence": " -> ".join(spec.preferred_sequence),
                        "reverse_sequence": " -> ".join(spec.reverse_sequence),
                        "preferred_gain": preferred_gain,
                        "reverse_gain": reverse_gain,
                        "myopic_action": myopic_action,
                        "myopic_gain": myopic_gain,
                        "myopic_regret": myopic_regret,
                        "forced_myopic_action": forced_myopic_action,
                        "forced_myopic_gain": forced_myopic_gain,
                        "forced_myopic_regret": forced_myopic_regret,
                        "demurrage_velocity_change": demurrage.velocity_change,
                        "demurrage_utility_change": demurrage_utility_change,
                        "metric_welfare_divergence": bool(metric_welfare_divergence),
                    }
                )

        n = local["cases"]
        summary = {
            "interaction": spec.name,
            "cases": n,
            "mean_nonadditive_residual": residual_sum / n,
            "pure_false_singular_rate": _rate(local["pure_false_singular"], n),
            "cautious_unresolved_rate": _rate(local["cautious_unresolved"], n),
            "pure_both_constituents_recalled_rate": _rate(local["pure_both_constituents"], n),
            "additive_pair_accuracy": _rate(local["additive_pair_correct"], n),
            "interaction_aware_pair_accuracy": _rate(local["aware_pair_correct"], n),
            "path_dependence_rate": _rate(local["path_dependent"], n),
            "preferred_order_better_rate": _rate(local["preferred_better"], n),
            "mean_preferred_utility_gain": preferred_gain_sum / n,
            "mean_reverse_utility_gain": reverse_gain_sum / n,
            "mean_myopic_utility_gain": myopic_gain_sum / n,
            "myopic_unsafe_action_rate": _rate(local["myopic_action_unsafe"], n),
            "myopic_negative_gain_rate": _rate(local["myopic_negative_gain"], n),
            "forced_myopic_unsafe_action_rate": _rate(
                local["forced_myopic_action_unsafe"], n
            ),
            "forced_myopic_negative_gain_rate": _rate(
                local["forced_myopic_negative_gain"], n
            ),
            "forced_myopic_material_regret_rate": _rate(
                local["forced_myopic_material_regret"], n
            ),
            "demurrage_metric_welfare_divergence_rate": _rate(local["metric_welfare_divergence"], n),
            "mean_demurrage_utility_change": demurrage_utility_change_sum / n,
        }
        interaction_summaries.append(summary)
        for key, value in local.items():
            aggregate[key] += value

    total = aggregate["cases"]
    overall = {
        "interactions": len(INTERACTIONS),
        "cases": total,
        "pure_false_singular_rate": _rate(aggregate["pure_false_singular"], total),
        "cautious_unresolved_rate": _rate(aggregate["cautious_unresolved"], total),
        "pure_both_constituents_recalled_rate": _rate(aggregate["pure_both_constituents"], total),
        "additive_pair_accuracy": _rate(aggregate["additive_pair_correct"], total),
        "interaction_aware_pair_accuracy": _rate(aggregate["aware_pair_correct"], total),
        "path_dependence_rate": _rate(aggregate["path_dependent"], total),
        "preferred_order_better_rate": _rate(aggregate["preferred_better"], total),
        "myopic_unsafe_action_rate": _rate(aggregate["myopic_action_unsafe"], total),
        "myopic_negative_gain_rate": _rate(aggregate["myopic_negative_gain"], total),
        "forced_myopic_unsafe_action_rate": _rate(
            aggregate["forced_myopic_action_unsafe"], total
        ),
        "forced_myopic_negative_gain_rate": _rate(
            aggregate["forced_myopic_negative_gain"], total
        ),
        "forced_myopic_material_regret_rate": _rate(
            aggregate["forced_myopic_material_regret"], total
        ),
        "demurrage_metric_welfare_divergence_rate": _rate(aggregate["metric_welfare_divergence"], total),
    }

    result = {
        "metadata": {
            "seed": seed,
            "replicates_per_interaction": replicates_per_interaction,
            "noise_scale": noise_scale,
            "synthetic": True,
            "interpretation": "Falsification audit of superposition and open-loop intervention assumptions; not an empirical estimate.",
        },
        "overall": overall,
        "interaction_summaries": interaction_summaries,
    }

    (output_dir / "nonadditive_results.json").write_text(
        json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
    )
    _write_csv(output_dir / "interaction_summary.csv", interaction_summaries)
    _write_csv(output_dir / "sample_static_cases.csv", static_rows)
    _write_csv(output_dir / "sample_dynamic_cases.csv", dynamic_rows)
    return result


def _write_csv(path: Path, rows: List[Mapping[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

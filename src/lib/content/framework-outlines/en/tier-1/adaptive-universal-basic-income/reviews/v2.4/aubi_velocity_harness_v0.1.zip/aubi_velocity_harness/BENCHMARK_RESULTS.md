# Benchmark results — seed 7, 250 replicates per state

The benchmark sampled 3,000 synthetic cases: 250 noisy realizations of each of the twelve hidden states.

| Policy / observation view | State accuracy | Specific intervention accuracy | Safe action rate | Harmful intervention rate | Unresolved rate |
|---|---:|---:|---:|---:|---:|
| Current provider heuristic | 8.3% | 8.3% | 8.3% | 58.3% | 0.0% |
| Current demurrage heuristic | 0.0% | 0.0% | 0.3% | 99.7% | 0.3% |
| Conservative current response | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, current view | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, decomposed view | 24.8% | 24.8% | 100.0% | 0.0% | 75.2% |
| Nearest prototype, full view | 99.5% | 99.5% | 100.0% | 0.0% | 0.5% |

## Interpretation

- The **current dashboard contains zero prototype separation by construction**. All twelve states have identical headline values, so a responsible evaluator records `cause unresolved`.
- Direct provider or demurrage responses are unsafe because they act on one possible cause as though it were identified.
- Decomposed financial telemetry identifies some states—especially concentration and unusual redemption—but leaves most cases unresolved.
- The full proposed sensor portfolio makes the twelve designed prototypes almost completely separable at the default noise level.
- This is stronger than the annex’s illustrative 80% threshold, but it reflects the deliberate construction of the synthetic corpus rather than validated empirical sensor performance.

These results demonstrate internal separability of the synthetic corpus. They do not validate the numerical prototypes, establish state frequencies, or prove real-world diagnostic performance.

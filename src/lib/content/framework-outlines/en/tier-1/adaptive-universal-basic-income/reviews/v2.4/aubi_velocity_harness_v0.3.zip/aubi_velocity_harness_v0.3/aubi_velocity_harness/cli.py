"""Command line interface for benchmark, inspection, and interactive quiz."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Dict, List, Mapping

from .benchmark import benchmark, format_table, write_csv
from .adversarial_benchmark import run_all
from .nonadditive_benchmark import run_nonadditive_audit
from .equivalence import all_pair_summary, nearest_pairs
from .model import (
    display_observations,
    intervention_is_acceptable,
    intervention_is_safe,
    intervention_label,
    nearest_prototype_diagnosis,
    sample_case,
)
from .scenarios import INTERVENTIONS, SCENARIOS
from .views import VIEWS


def cmd_benchmark(args: argparse.Namespace) -> int:
    rows, _ = benchmark(
        replicates_per_state=args.replicates,
        seed=args.seed,
        noise_scale=args.noise,
    )
    print(format_table(rows))
    if args.csv:
        path = Path(args.csv)
        write_csv(rows, path)
        print(f"\nWrote {path}")
    return 0


def cmd_equivalence(args: argparse.Namespace) -> int:
    summary = all_pair_summary()
    print("Prototype distance by observation view")
    for view, stats in summary.items():
        print(
            f"  {view:12s} min={stats['minimum']:.3f} "
            f"median={stats['median']:.3f} max={stats['maximum']:.3f}"
        )
    print(f"\nNearest pairs under '{args.view}' view")
    for a, b, distance in nearest_pairs(args.view, args.limit):
        print(f"  {distance:7.3f}  {a}  <->  {b}")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    scenario = next((s for s in SCENARIOS if s.id == args.scenario or s.name == args.scenario), None)
    if scenario is None:
        raise SystemExit(f"Unknown scenario {args.scenario!r}")
    rng = random.Random(args.seed)
    case = sample_case(scenario, rng, noise_scale=args.noise)
    print(f"{scenario.id}: {scenario.name}\n{scenario.description}\n")
    for field, value in display_observations(case.observations, args.view):
        print(f"{field:36s} {value:.4f}")
    diagnosis = nearest_prototype_diagnosis(case.observations, args.view)
    print("\nHarness diagnosis")
    print(f"  state:        {diagnosis.predicted_state}")
    print(f"  confidence:   {diagnosis.confidence:.3f}")
    print(f"  intervention: {intervention_label(diagnosis.intervention)}")
    print("  top hypotheses:")
    for name, probability in diagnosis.ranked_states[:4]:
        print(f"    {probability:.3f}  {name}")
    return 0


def _ask_choice(prompt: str, options: List[str]) -> int:
    while True:
        print(prompt)
        for i, option in enumerate(options, start=1):
            print(f"  {i:2d}. {option}")
        raw = input("> ").strip()
        try:
            choice = int(raw)
        except ValueError:
            print("Enter the option number.")
            continue
        if 1 <= choice <= len(options):
            return choice - 1
        print("Choice out of range.")


def cmd_quiz(args: argparse.Namespace) -> int:
    rng = random.Random(args.seed)
    selected = list(SCENARIOS)
    rng.shuffle(selected)
    selected = selected[: args.cases]
    state_names = [s.name for s in SCENARIOS] + ["cause_unresolved"]
    intervention_keys = [
        key
        for key in INTERVENTIONS
        if key not in {"increase_demurrage"}
    ]

    state_correct = 0
    intervention_correct = 0
    safe_actions = 0
    harmful = 0
    confidence_error = 0.0

    for index, scenario in enumerate(selected, start=1):
        case = sample_case(scenario, rng, noise_scale=args.noise)
        print("\n" + "=" * 76)
        print(f"Case {index}/{len(selected)} — observation view: {args.view}")
        print("=" * 76)
        for field, value in display_observations(case.observations, args.view):
            print(f"{field:36s} {value:.4f}")

        state_idx = _ask_choice("\nChoose the leading state:", state_names)
        selected_state = state_names[state_idx]
        intervention_idx = _ask_choice(
            "\nChoose the intervention:",
            [intervention_label(key) for key in intervention_keys],
        )
        selected_intervention = intervention_keys[intervention_idx]
        while True:
            raw = input("\nConfidence 0-100: ").strip()
            try:
                confidence = max(0.0, min(100.0, float(raw))) / 100.0
                break
            except ValueError:
                print("Enter a number from 0 to 100.")

        correct_state = selected_state == scenario.name
        correct_intervention = intervention_is_acceptable(scenario, selected_intervention)
        safe_action = intervention_is_safe(scenario, selected_intervention)
        is_harmful = selected_intervention in scenario.harmful_interventions
        state_correct += int(correct_state)
        intervention_correct += int(correct_intervention)
        safe_actions += int(safe_action)
        harmful += int(is_harmful)
        confidence_error += (confidence - float(correct_state)) ** 2

        print("\nReveal")
        print(f"  hidden state:       {scenario.name}")
        print(f"  description:        {scenario.description}")
        print(f"  primary response:   {intervention_label(scenario.primary_intervention)}")
        print(f"  state correct:      {'yes' if correct_state else 'no'}")
        print(f"  state-specific action: {'yes' if correct_intervention else 'no'}")
        print(f"  safe action:          {'yes' if safe_action else 'no'}")
        print(f"  intervention harm:  {'yes' if is_harmful else 'no'}")

    n = len(selected)
    print("\n" + "=" * 76)
    print("Quiz result")
    print("=" * 76)
    print(f"State accuracy:              {state_correct / n:.3f}")
    print(f"Specific intervention acc.:  {intervention_correct / n:.3f}")
    print(f"Safe action rate:            {safe_actions / n:.3f}")
    print(f"Harmful intervention rate:   {harmful / n:.3f}")
    print(f"Confidence Brier score:      {confidence_error / n:.3f}")
    return 0



def _print_rows(title: str, rows: List[Mapping[str, object]], columns: List[str]) -> None:
    print("\n" + title)
    if not rows:
        print("  (no rows)")
        return
    widths = {c: max(len(c), max(len(_format_cell(row.get(c))) for row in rows)) for c in columns}
    print("  ".join(c.ljust(widths[c]) for c in columns))
    print("  ".join("-" * widths[c] for c in columns))
    for row in rows:
        print("  ".join(_format_cell(row.get(c)).ljust(widths[c]) for c in columns))


def _format_cell(value: object) -> str:
    if isinstance(value, float):
        if value == float("inf"):
            return "inf"
        return f"{value:.3f}"
    return str(value)


def cmd_adversarial_audit(args: argparse.Namespace) -> int:
    output_dir = Path(args.output)
    results = run_all(
        output_dir=output_dir,
        mixture_replicates=args.mixture_replicates,
        failure_replicates=args.failure_replicates,
        ambiguity_replicates=args.ambiguity_replicates,
    )
    _print_rows(
        "Cross-state mixtures",
        results["mixtures"],
        [
            "policy",
            "unresolved_rate",
            "heterogeneity_detection_rate",
            "false_singular_rate",
            "harmful_to_any_component_rate",
        ],
    )
    _print_rows(
        "Ambiguity margin sweep",
        results["ambiguity_margin_sweep"],
        [
            "unresolved_margin",
            "ambiguous_correct_restraint_rate",
            "ambiguous_conflict_risk_rate",
            "pure_state_accuracy",
            "pure_unresolved_rate",
        ],
    )
    _print_rows(
        "Sensor-group ablation",
        results["sensor_group_ablation"],
        [
            "ablated_group",
            "state_accuracy",
            "unresolved_rate",
            "harmful_intervention_rate",
            "fields_ablated",
        ],
    )
    strategic = [r for r in results["strategic_reporting"] if r["success"]]
    strategic.sort(key=lambda r: r["normalized_cost"] )
    _print_rows(
        "Easiest successful strategic attacks",
        strategic[:12],
        [
            "actor",
            "source_state",
            "target_state",
            "normalized_cost",
            "alpha",
        ],
    )
    print(f"\nWrote adversarial audit outputs to {output_dir}")
    return 0



def cmd_nonadditive_audit(args: argparse.Namespace) -> int:
    output_dir = Path(args.output)
    results = run_nonadditive_audit(
        output_dir=output_dir,
        replicates_per_interaction=args.replicates,
        seed=args.seed,
        noise_scale=args.noise,
    )
    overall = results["overall"]
    print("Non-additive interaction falsification gate")
    for key, value in overall.items():
        if isinstance(value, float):
            print(f"  {key:44s} {value:.3f}")
        else:
            print(f"  {key:44s} {value}")
    _print_rows(
        "Interaction summaries",
        results["interaction_summaries"],
        [
            "interaction",
            "mean_nonadditive_residual",
            "additive_pair_accuracy",
            "interaction_aware_pair_accuracy",
            "path_dependence_rate",
            "preferred_order_better_rate",
            "demurrage_metric_welfare_divergence_rate",
        ],
    )
    print(f"\nWrote non-additive audit outputs to {output_dir}")
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aubi-velocity-harness",
        description="Executable twelve-state indistinguishable-state test for low Hearts velocity.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_bench = sub.add_parser("benchmark", help="Benchmark policies across all synthetic states")
    p_bench.add_argument("--replicates", type=int, default=250)
    p_bench.add_argument("--seed", type=int, default=7)
    p_bench.add_argument("--noise", type=float, default=1.0)
    p_bench.add_argument("--csv", type=str)
    p_bench.set_defaults(func=cmd_benchmark)

    p_eq = sub.add_parser("equivalence", help="Inspect prototype separability by observation view")
    p_eq.add_argument("--view", choices=sorted(VIEWS), default="current")
    p_eq.add_argument("--limit", type=int, default=12)
    p_eq.set_defaults(func=cmd_equivalence)

    p_show = sub.add_parser("show", help="Show a sampled case and harness diagnosis")
    p_show.add_argument("scenario", help="Scenario ID (S1-S12) or name")
    p_show.add_argument("--view", choices=sorted(VIEWS), default="full")
    p_show.add_argument("--seed", type=int, default=7)
    p_show.add_argument("--noise", type=float, default=1.0)
    p_show.set_defaults(func=cmd_show)

    p_quiz = sub.add_parser("quiz", help="Interactive human/model diagnostic evaluation")
    p_quiz.add_argument("--view", choices=sorted(VIEWS), default="current")
    p_quiz.add_argument("--cases", type=int, default=12)
    p_quiz.add_argument("--seed", type=int, default=7)
    p_quiz.add_argument("--noise", type=float, default=1.0)
    p_quiz.set_defaults(func=cmd_quiz)


    p_adv = sub.add_parser("adversarial-audit", help="Run mixture, correlated-failure, ambiguity, strategic-reporting, and sensor-ablation audits")
    p_adv.add_argument("--output", default="adversarial_outputs")
    p_adv.add_argument("--mixture-replicates", type=int, default=50)
    p_adv.add_argument("--failure-replicates", type=int, default=100)
    p_adv.add_argument("--ambiguity-replicates", type=int, default=100)
    p_adv.set_defaults(func=cmd_adversarial_audit)

    p_nonadd = sub.add_parser(
        "nonadditive-audit",
        help="Run non-additive state, policy-order, and intervention-feedback tests",
    )
    p_nonadd.add_argument("--output", default="nonadditive_outputs")
    p_nonadd.add_argument("--replicates", type=int, default=300)
    p_nonadd.add_argument("--seed", type=int, default=29)
    p_nonadd.add_argument("--noise", type=float, default=1.0)
    p_nonadd.set_defaults(func=cmd_nonadditive_audit)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

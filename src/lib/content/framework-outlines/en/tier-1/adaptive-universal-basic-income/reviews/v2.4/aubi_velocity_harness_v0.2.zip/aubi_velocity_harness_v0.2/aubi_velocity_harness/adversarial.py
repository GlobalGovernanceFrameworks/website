"""Adversarial corpus generators and reliability-aware policies.

This module audits the v0.1 twelve-state corpus against four challenges:
1. cross-state mixtures hidden by aggregation;
2. correlated observation-channel failures;
3. strategic reporting attacks;
4. genuinely ambiguous boundary cases.

All values remain synthetic. The goal is to test information architecture, not
claim empirical frequencies or calibrated intervention effects.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from .model import Case, Diagnosis, field_value, nearest_prototype_diagnosis, sample_case
from .scenarios import SCENARIOS, Scenario
from .views import FIELD_NOISE, FULL_FIELDS


SCENARIO_BY_NAME = {s.name: s for s in SCENARIOS}


@dataclass(frozen=True)
class MixedCase:
    left: Scenario
    right: Scenario
    left_weight: float
    aggregate: Mapping[str, float]
    subgroups: Tuple[Mapping[str, float], Mapping[str, float]]


@dataclass(frozen=True)
class AmbiguousCase:
    left: Scenario
    right: Scenario
    observations: Mapping[str, float]


@dataclass(frozen=True)
class AttackProfile:
    name: str
    description: str
    shifts: Mapping[str, float]


@dataclass(frozen=True)
class StrategicAttackResult:
    source_state: str
    target_state: str
    target_intervention: str
    actor: str
    success: bool
    alpha: float
    normalized_cost: float
    changed_fields: int
    resulting_state: str
    resulting_intervention: str


# Fields plausibly generated or mediated by the same institutional channel.
ACTOR_FIELDS: Dict[str, frozenset[str]] = {
    "provider_reporting": frozenset(
        {
            "effective_category_coverage",
            "provider_redundancy",
            "provider_capacity_utilization",
            "unmet_demand_rate",
            "median_wait_days",
            "geographic_access_score",
            "provider_satisfaction",
            "repeat_use_rate",
            "provider_ledger_match",
            "reported_provider_to_ledger_volume",
        }
    ),
    "participant_survey": frozenset(
        {
            "subgroup_use_gap",
            "provider_satisfaction",
            "hearts_trust_score",
            "material_sufficiency",
            "informal_substitution_rate",
            "informal_care_burden",
            "desired_formal_service_rate",
            "fiat_essential_burden",
        }
    ),
    "ledger_platform": frozenset(
        {
            "use_velocity_30d",
            "dormancy_90d_share",
            "recirculation_velocity",
            "redemption_rate",
            "active_user_share",
            "failed_transaction_rate",
            "offline_reconciliation_gap",
            "provider_ledger_match",
            "reported_provider_to_ledger_volume",
        }
    ),
    "treasury_governance": frozenset(
        {
            "reserve_ratio",
            "redemption_rate",
            "top10_balance_share",
            "median_balance_to_mean",
            "institutional_balance_share",
            "hearts_trust_score",
            "marginalized_outreach_reported",
            "seasonal_deviation_z",
        }
    ),
}
ACTOR_FIELDS["coalition"] = frozenset().union(*ACTOR_FIELDS.values())


ATTACK_PROFILES: Tuple[AttackProfile, ...] = (
    AttackProfile(
        name="weaver_optimism",
        description="A common local validation channel overstates coverage, quality, and access while understating unmet need.",
        shifts={
            "effective_category_coverage": 0.18,
            "provider_redundancy": 0.14,
            "geographic_access_score": 0.18,
            "provider_satisfaction": 0.20,
            "repeat_use_rate": 0.13,
            "unmet_demand_rate": -0.23,
            "median_wait_days": -5.0,
            "subgroup_use_gap": -0.16,
            "informal_care_burden": -0.12,
        },
    ),
    AttackProfile(
        name="survey_chilling",
        description="Fear, social desirability, or nonresponse makes participant reports look safer and more satisfied than reality.",
        shifts={
            "hearts_trust_score": 0.24,
            "provider_satisfaction": 0.16,
            "material_sufficiency": 0.23,
            "unmet_demand_rate": -0.18,
            "desired_formal_service_rate": -0.22,
            "informal_care_burden": -0.18,
            "subgroup_use_gap": -0.13,
        },
    ),
    AttackProfile(
        name="ledger_suppression",
        description="A shared transaction platform under-records circulation and participation.",
        shifts={
            "use_velocity_30d": -0.10,
            "recirculation_velocity": -0.11,
            "active_user_share": -0.10,
            "dormancy_90d_share": 0.12,
            "failed_transaction_rate": 0.16,
            "offline_reconciliation_gap": 0.22,
            "provider_ledger_match": -0.28,
            "reported_provider_to_ledger_volume": 0.42,
        },
    ),
    AttackProfile(
        name="treasury_smoothing",
        description="Aggregate reporting suppresses balance concentration and redemption stress.",
        shifts={
            "top10_balance_share": -0.24,
            "institutional_balance_share": -0.20,
            "median_balance_to_mean": 0.20,
            "redemption_rate": -0.16,
            "hearts_trust_score": 0.10,
        },
    ),
)


def _clip_field(field: str, value: float) -> float:
    if field == "seasonal_deviation_z":
        return value
    if field in {"enrolled_participants", "median_wait_days", "provider_category_count", "reported_provider_to_ledger_volume"}:
        return max(0.0, value)
    return max(0.0, min(1.0, value))


def blend_cases(
    left: Scenario,
    right: Scenario,
    left_weight: float,
    rng: random.Random,
    noise_scale: float = 1.0,
) -> MixedCase:
    if not 0.0 < left_weight < 1.0:
        raise ValueError("left_weight must be between zero and one")
    left_case = sample_case(left, rng, noise_scale=noise_scale)
    right_case = sample_case(right, rng, noise_scale=noise_scale)
    aggregate = {
        field: left_weight * left_case.observations[field]
        + (1.0 - left_weight) * right_case.observations[field]
        for field in left_case.observations
    }
    return MixedCase(
        left=left,
        right=right,
        left_weight=left_weight,
        aggregate=aggregate,
        subgroups=(left_case.observations, right_case.observations),
    )


def ambiguous_midpoint(
    left: Scenario,
    right: Scenario,
    rng: random.Random,
    noise_scale: float = 0.5,
) -> AmbiguousCase:
    # Unlike a mixture, the truth here is explicitly disjunctive: the same
    # observation could have arisen from either state. Resolution is incorrect.
    observations: Dict[str, float] = {}
    all_fields = set().union(*(set(c.prototype) for c in SCENARIOS))
    # Include default/audit fields by sampling both clean cases.
    left_case = sample_case(left, rng, noise_scale=noise_scale)
    right_case = sample_case(right, rng, noise_scale=noise_scale)
    all_fields |= set(left_case.observations)
    for field in all_fields:
        observations[field] = 0.5 * (
            left_case.observations[field] + right_case.observations[field]
        )
    return AmbiguousCase(left=left, right=right, observations=observations)


def apply_correlated_failure(
    observations: Mapping[str, float],
    profile: AttackProfile,
    strength: float = 1.0,
    concealed: bool = False,
) -> Dict[str, float]:
    attacked = dict(observations)
    for field, shift in profile.shifts.items():
        attacked[field] = _clip_field(field, attacked[field] + strength * shift)

    if not concealed:
        # The audit layer does not know the true state; it only sees evidence
        # that the observation process is unreliable or dependent.
        attacked["source_disagreement_score"] = max(attacked.get("source_disagreement_score", 0.1), 0.68)
        attacked["observer_independence_score"] = min(attacked.get("observer_independence_score", 0.9), 0.34)
        attacked["provenance_completeness"] = min(attacked.get("provenance_completeness", 0.95), 0.58)
        if profile.name == "survey_chilling":
            attacked["survey_nonresponse_rate"] = max(attacked.get("survey_nonresponse_rate", 0.15), 0.62)
        if profile.name == "weaver_optimism":
            attacked["weaver_overload_score"] = max(attacked.get("weaver_overload_score", 0.35), 0.91)
        if profile.name == "ledger_suppression":
            attacked["method_change_flag"] = 1.0
    else:
        # A concealed attack also manipulates the reliability metadata.
        attacked["source_disagreement_score"] = 0.08
        attacked["observer_independence_score"] = 0.92
        attacked["provenance_completeness"] = 0.97
        attacked["survey_nonresponse_rate"] = 0.12
        attacked["weaver_overload_score"] = 0.30
        attacked["method_change_flag"] = 0.0
        if profile.name == "ledger_suppression":
            attacked["failed_transaction_rate"] = min(attacked["failed_transaction_rate"], 0.04)
            attacked["offline_reconciliation_gap"] = min(attacked["offline_reconciliation_gap"], 0.03)
            attacked["provider_ledger_match"] = max(attacked["provider_ledger_match"], 0.97)
            attacked["technical_uptime_reported"] = 0.999
    return attacked


def observation_integrity_alert(observations: Mapping[str, float]) -> bool:
    return any(
        (
            observations.get("source_disagreement_score", 0.0) > 0.45,
            observations.get("observer_independence_score", 1.0) < 0.50,
            observations.get("provenance_completeness", 1.0) < 0.70,
            observations.get("survey_nonresponse_rate", 0.0) > 0.45,
            observations.get("weaver_overload_score", 0.0) > 0.85,
            observations.get("method_change_flag", 0.0) > 0.5,
        )
    )


def integrity_gated_diagnosis(
    observations: Mapping[str, float], unresolved_margin: float = 0.07
) -> Diagnosis:
    if observation_integrity_alert(observations):
        return Diagnosis(
            predicted_state="observation_integrity_unresolved",
            confidence=0.0,
            intervention="generic_diagnostic_review",
            ranked_states=tuple(),
            unresolved=True,
        )
    return nearest_prototype_diagnosis(
        observations, "full", unresolved_margin=unresolved_margin
    )


def stratified_mixture_diagnosis(mixed: MixedCase) -> Diagnosis:
    left = nearest_prototype_diagnosis(mixed.subgroups[0], "full")
    right = nearest_prototype_diagnosis(mixed.subgroups[1], "full")
    if left.unresolved or right.unresolved or left.predicted_state != right.predicted_state:
        ranked = tuple(
            (name, prob)
            for diagnosis in (left, right)
            for name, prob in diagnosis.ranked_states[:2]
        )
        return Diagnosis(
            predicted_state="mixed_or_heterogeneous",
            confidence=min(left.confidence, right.confidence),
            intervention="generic_diagnostic_review",
            ranked_states=ranked,
            unresolved=True,
        )
    return left


def normalized_attack_cost(
    before: Mapping[str, float], after: Mapping[str, float], fields: Iterable[str]
) -> float:
    terms = []
    for field in fields:
        scale = max(FIELD_NOISE.get(field, 0.03) * 2.5, 0.015)
        terms.append(((after[field] - before[field]) / scale) ** 2)
    return math.sqrt(sum(terms) / max(len(terms), 1))


def _interpolate_toward(
    source: Mapping[str, float],
    target: Scenario,
    fields: Iterable[str],
    alpha: float,
) -> Dict[str, float]:
    attacked = dict(source)
    for field in fields:
        target_value = field_value(target, field)
        attacked[field] = _clip_field(
            field, source[field] + alpha * (target_value - source[field])
        )
    return attacked


def find_minimum_targeted_attack(
    source: Scenario,
    target: Scenario,
    actor: str,
    step: float = 0.01,
) -> StrategicAttackResult:
    if actor not in ACTOR_FIELDS:
        raise ValueError(f"unknown actor {actor!r}")
    base = sample_case(source, random.Random(0), noise_scale=0.0).observations
    fields = ACTOR_FIELDS[actor] & FULL_FIELDS
    alpha = step
    while alpha <= 1.000001:
        attacked = _interpolate_toward(base, target, fields, alpha)
        diagnosis = nearest_prototype_diagnosis(attacked, "full")
        if (
            not diagnosis.unresolved
            and diagnosis.intervention == target.primary_intervention
        ):
            return StrategicAttackResult(
                source_state=source.name,
                target_state=target.name,
                target_intervention=target.primary_intervention,
                actor=actor,
                success=True,
                alpha=alpha,
                normalized_cost=normalized_attack_cost(base, attacked, fields),
                changed_fields=len(fields),
                resulting_state=diagnosis.predicted_state,
                resulting_intervention=diagnosis.intervention,
            )
        alpha += step
    diagnosis = nearest_prototype_diagnosis(base, "full")
    return StrategicAttackResult(
        source_state=source.name,
        target_state=target.name,
        target_intervention=target.primary_intervention,
        actor=actor,
        success=False,
        alpha=1.0,
        normalized_cost=float("inf"),
        changed_fields=len(fields),
        resulting_state=diagnosis.predicted_state,
        resulting_intervention=diagnosis.intervention,
    )


def harmful_target_states(source: Scenario) -> Tuple[Scenario, ...]:
    return tuple(
        target
        for target in SCENARIOS
        if target.primary_intervention in source.harmful_interventions
    )

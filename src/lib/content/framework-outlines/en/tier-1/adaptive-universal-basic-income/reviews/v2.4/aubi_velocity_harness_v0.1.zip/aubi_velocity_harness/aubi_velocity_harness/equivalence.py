"""Prototype-distance analysis for observation-level equivalence."""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

from .model import field_value
from .scenarios import SCENARIOS
from .views import FIELD_NOISE, VIEWS


def prototype_distance(a_name: str, b_name: str, view: str) -> float:
    a = next(s for s in SCENARIOS if s.name == a_name)
    b = next(s for s in SCENARIOS if s.name == b_name)
    total = 0.0
    used = 0
    for field in VIEWS[view]:
        scale = max(FIELD_NOISE.get(field, 0.03) * 2.5, 0.015)
        total += ((field_value(a, field) - field_value(b, field)) / scale) ** 2
        used += 1
    return math.sqrt(total / used)


def nearest_pairs(view: str, limit: int = 12) -> List[Tuple[str, str, float]]:
    pairs: List[Tuple[str, str, float]] = []
    for i, a in enumerate(SCENARIOS):
        for b in SCENARIOS[i + 1 :]:
            pairs.append((a.name, b.name, prototype_distance(a.name, b.name, view)))
    pairs.sort(key=lambda item: item[2])
    return pairs[:limit]


def all_pair_summary() -> Dict[str, Dict[str, float]]:
    result: Dict[str, Dict[str, float]] = {}
    for view in VIEWS:
        distances = []
        for i, a in enumerate(SCENARIOS):
            for b in SCENARIOS[i + 1 :]:
                distances.append(prototype_distance(a.name, b.name, view))
        result[view] = {
            "minimum": min(distances),
            "median": sorted(distances)[len(distances) // 2],
            "maximum": max(distances),
        }
    return result

"""Observation views used by the diagnostic and adversarial benchmarks."""

from __future__ import annotations

from typing import Dict, FrozenSet


CURRENT_FIELDS: FrozenSet[str] = frozenset(
    {
        "use_velocity_30d",
        "dormancy_90d_share",
        "provider_category_count",
        "reserve_ratio",
        "fraud_rate",
        "enrolled_participants",
        "technical_uptime_reported",
        "lmci_a_cycle_complete",
        "marginalized_outreach_reported",
    }
)

DECOMPOSED_FIELDS: FrozenSet[str] = CURRENT_FIELDS | frozenset(
    {
        "recirculation_velocity",
        "redemption_rate",
        "active_user_share",
        "top10_balance_share",
        "median_balance_to_mean",
        "institutional_balance_share",
        "failed_transaction_rate",
    }
)

FULL_FIELDS: FrozenSet[str] = DECOMPOSED_FIELDS | frozenset(
    {
        "effective_category_coverage",
        "provider_redundancy",
        "provider_capacity_utilization",
        "unmet_demand_rate",
        "median_wait_days",
        "geographic_access_score",
        "subgroup_use_gap",
        "provider_satisfaction",
        "repeat_use_rate",
        "essential_acceptance_rate",
        "fiat_essential_burden",
        "hearts_trust_score",
        "offline_reconciliation_gap",
        "provider_ledger_match",
        "reported_provider_to_ledger_volume",
        "seasonal_deviation_z",
        "material_sufficiency",
        "informal_substitution_rate",
        "informal_care_burden",
        "desired_formal_service_rate",
        "hearts_usable_budget_share",
        "assigned_hearts_share",
    }
)

# These fields do not diagnose the economic state directly. They diagnose the
# reliability and independence of the observation process itself.
AUDIT_FIELDS: FrozenSet[str] = FULL_FIELDS | frozenset(
    {
        "source_disagreement_score",
        "observer_independence_score",
        "provenance_completeness",
        "survey_nonresponse_rate",
        "weaver_overload_score",
        "method_change_flag",
    }
)

VIEWS: Dict[str, FrozenSet[str]] = {
    "current": CURRENT_FIELDS,
    "decomposed": DECOMPOSED_FIELDS,
    "full": FULL_FIELDS,
    "audit": AUDIT_FIELDS,
}

# Fields that are counts or binary indicators need smaller or special noise.
FIELD_NOISE = {
    "use_velocity_30d": 0.025,
    "dormancy_90d_share": 0.025,
    "provider_category_count": 0.0,
    "reserve_ratio": 0.008,
    "fraud_rate": 0.0008,
    "enrolled_participants": 8.0,
    "technical_uptime_reported": 0.0002,
    "lmci_a_cycle_complete": 0.0,
    "marginalized_outreach_reported": 0.0,
    "recirculation_velocity": 0.025,
    "redemption_rate": 0.03,
    "active_user_share": 0.03,
    "top10_balance_share": 0.035,
    "median_balance_to_mean": 0.03,
    "institutional_balance_share": 0.04,
    "effective_category_coverage": 0.035,
    "provider_redundancy": 0.04,
    "provider_capacity_utilization": 0.035,
    "unmet_demand_rate": 0.04,
    "median_wait_days": 1.0,
    "geographic_access_score": 0.04,
    "subgroup_use_gap": 0.035,
    "provider_satisfaction": 0.04,
    "repeat_use_rate": 0.04,
    "essential_acceptance_rate": 0.04,
    "fiat_essential_burden": 0.04,
    "hearts_trust_score": 0.04,
    "failed_transaction_rate": 0.02,
    "offline_reconciliation_gap": 0.025,
    "provider_ledger_match": 0.025,
    "reported_provider_to_ledger_volume": 0.08,
    "seasonal_deviation_z": 0.18,
    "material_sufficiency": 0.04,
    "informal_substitution_rate": 0.04,
    "informal_care_burden": 0.04,
    "desired_formal_service_rate": 0.04,
    "hearts_usable_budget_share": 0.025,
    "assigned_hearts_share": 0.0,
    "source_disagreement_score": 0.025,
    "observer_independence_score": 0.025,
    "provenance_completeness": 0.02,
    "survey_nonresponse_rate": 0.025,
    "weaver_overload_score": 0.025,
    "method_change_flag": 0.0,
}

# Default neutral values for fields not applicable to a scenario prototype.
FIELD_DEFAULTS = {
    "median_balance_to_mean": 0.55,
    "institutional_balance_share": 0.30,
    "reported_provider_to_ledger_volume": 1.0,
    "source_disagreement_score": 0.10,
    "observer_independence_score": 0.90,
    "provenance_completeness": 0.95,
    "survey_nonresponse_rate": 0.15,
    "weaver_overload_score": 0.35,
    "method_change_flag": 0.0,
}

from __future__ import annotations

import random
import unittest

from aubi_velocity_harness.benchmark import benchmark
from aubi_velocity_harness.equivalence import all_pair_summary
from aubi_velocity_harness.model import nearest_prototype_diagnosis, sample_case
from aubi_velocity_harness.scenarios import SCENARIOS


class HarnessTests(unittest.TestCase):
    def test_twelve_states(self) -> None:
        self.assertEqual(len(SCENARIOS), 12)
        self.assertEqual(len({s.name for s in SCENARIOS}), 12)

    def test_current_view_is_less_separable_than_full(self) -> None:
        summary = all_pair_summary()
        self.assertLess(summary["current"]["median"], summary["full"]["median"])
        self.assertEqual(summary["current"]["minimum"], 0.0)

    def test_full_view_recovers_clean_prototypes(self) -> None:
        rng = random.Random(2)
        correct = 0
        for scenario in SCENARIOS:
            case = sample_case(scenario, rng, noise_scale=0.0)
            diagnosis = nearest_prototype_diagnosis(case.observations, "full", unresolved_margin=0.0)
            correct += diagnosis.predicted_state == scenario.name
        self.assertEqual(correct, 12)

    def test_full_benchmark_improves_intervention_accuracy(self) -> None:
        rows, _ = benchmark(replicates_per_state=80, seed=3, noise_scale=0.8)
        by_name = {row["policy"]: row for row in rows}
        self.assertGreater(
            by_name["nearest_full"]["specific_intervention_accuracy"],
            by_name["current_provider_heuristic"]["specific_intervention_accuracy"],
        )
        self.assertLess(
            by_name["nearest_full"]["harmful_intervention_rate"],
            by_name["current_demurrage_heuristic"]["harmful_intervention_rate"],
        )


if __name__ == "__main__":
    unittest.main()

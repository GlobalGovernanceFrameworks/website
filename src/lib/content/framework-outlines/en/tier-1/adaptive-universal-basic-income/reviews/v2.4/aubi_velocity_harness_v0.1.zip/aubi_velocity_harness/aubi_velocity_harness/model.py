"""Sampling, transparent nearest-prototype diagnosis, and scoring."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

from .scenarios import INTERVENTIONS, SCENARIOS, Scenario
from .views import FIELD_DEFAULTS, FIELD_NOISE, VIEWS


@dataclass(frozen=True)
class Diagnosis:
    predicted_state: str
    confidence: float
    intervention: str
    ranked_states: Tuple[Tuple[str, float], ...]
    unresolved: bool = False


@dataclass(frozen=True)
class Case:
    scenario: Scenario
    observations: Mapping[str, float]


def _clip(field: str, value: float) -> float:
    if field == "seasonal_deviation_z":
        return value
    if field in {
        "enrolled_participants",
        "median_wait_days",
        "provider_category_count",
        "reported_provider_to_ledger_volume",
    }:
        return max(0.0, value)
    return min(1.0, max(0.0, value))


def field_value(scenario: Scenario, field: str) -> float:
    if field in scenario.prototype:
        return float(scenario.prototype[field])
    return float(FIELD_DEFAULTS.get(field, 0.5))


def sample_case(scenario: Scenario, rng: random.Random, noise_scale: float = 1.0) -> Case:
    observations: Dict[str, float] = {}
    all_fields = set().union(*VIEWS.values())
    for field in all_fields:
        mean = field_value(scenario, field)
        sd = FIELD_NOISE.get(field, 0.03) * noise_scale
        sampled = mean if sd == 0 else rng.gauss(mean, sd)
        observations[field] = _clip(field, sampled)
    return Case(scenario=scenario, observations=observations)


def _normalized_distance(
    observations: Mapping[str, float],
    scenario: Scenario,
    fields: Iterable[str],
) -> float:
    total = 0.0
    used = 0
    for field in fields:
        obs = observations[field]
        proto = field_value(scenario, field)
        scale = max(FIELD_NOISE.get(field, 0.03) * 2.5, 0.015)
        total += ((obs - proto) / scale) ** 2
        used += 1
    if used == 0:
        raise ValueError("No fields supplied to classifier")
    return math.sqrt(total / used)


def nearest_prototype_diagnosis(
    observations: Mapping[str, float],
    view: str,
    unresolved_margin: float = 0.07,
) -> Diagnosis:
    """Classify using only fields visible in the requested observation view.

    This deliberately simple method makes the information comparison legible.
    It does not claim to be an appropriate empirical estimator.
    """

    if view not in VIEWS:
        raise ValueError(f"Unknown view {view!r}; choose from {sorted(VIEWS)}")
    fields = VIEWS[view]
    distances = [(s.name, _normalized_distance(observations, s, fields)) for s in SCENARIOS]
    distances.sort(key=lambda item: (item[1], item[0]))

    # Convert distances into a probability-like ranking.
    weights = [math.exp(-d) for _, d in distances]
    total_weight = sum(weights)
    ranked = tuple((name, w / total_weight) for (name, _), w in zip(distances, weights))

    best_name, best_prob = ranked[0]
    second_prob = ranked[1][1]
    unresolved = (best_prob - second_prob) < unresolved_margin
    predicted = "cause_unresolved" if unresolved else best_name
    intervention = (
        "generic_diagnostic_review"
        if unresolved
        else next(s.primary_intervention for s in SCENARIOS if s.name == best_name)
    )
    return Diagnosis(
        predicted_state=predicted,
        confidence=best_prob,
        intervention=intervention,
        ranked_states=ranked,
        unresolved=unresolved,
    )


def current_provider_heuristic(observations: Mapping[str, float]) -> Diagnosis:
    """A deliberately naive formalization of the current Stage-3 interpretation."""
    low = observations["use_velocity_30d"] < 1.0 or observations["dormancy_90d_share"] > 0.35
    if low:
        return Diagnosis(
            predicted_state="provider_category_shortage",
            confidence=0.60,
            intervention="recruit_provider_categories",
            ranked_states=(("provider_category_shortage", 0.60),),
        )
    return Diagnosis(
        predicted_state="cause_unresolved",
        confidence=0.50,
        intervention="generic_diagnostic_review",
        ranked_states=(("cause_unresolved", 0.50),),
        unresolved=True,
    )


def current_demurrage_heuristic(observations: Mapping[str, float]) -> Diagnosis:
    """Alternative naive branch: treat dormancy as evidence for stronger demurrage."""
    if observations["dormancy_90d_share"] > 0.35:
        return Diagnosis(
            predicted_state="demurrage_failure",
            confidence=0.60,
            intervention="increase_demurrage",
            ranked_states=(("demurrage_failure", 0.60),),
        )
    return Diagnosis(
        predicted_state="cause_unresolved",
        confidence=0.50,
        intervention="generic_diagnostic_review",
        ranked_states=(("cause_unresolved", 0.50),),
        unresolved=True,
    )


def conservative_current_policy(observations: Mapping[str, float]) -> Diagnosis:
    return Diagnosis(
        predicted_state="cause_unresolved",
        confidence=1.0 / len(SCENARIOS),
        intervention="generic_diagnostic_review",
        ranked_states=tuple((s.name, 1.0 / len(SCENARIOS)) for s in SCENARIOS),
        unresolved=True,
    )


def intervention_is_acceptable(scenario: Scenario, intervention: str) -> bool:
    # Diagnostic review is safe, but it is not a resolved state-specific action.
    return intervention != "generic_diagnostic_review" and intervention in scenario.acceptable_interventions


def intervention_is_harmful(scenario: Scenario, intervention: str) -> bool:
    return intervention in scenario.harmful_interventions


def intervention_is_safe(scenario: Scenario, intervention: str) -> bool:
    # A diagnostic review is always a safe first response when the available
    # observation view cannot distinguish states. It is deliberately not
    # counted as a state-specific intervention.
    return intervention == "generic_diagnostic_review" or intervention_is_acceptable(scenario, intervention)


def state_is_correct(scenario: Scenario, diagnosis: Diagnosis) -> bool:
    return diagnosis.predicted_state == scenario.name


def display_observations(observations: Mapping[str, float], view: str) -> List[Tuple[str, float]]:
    return sorted((field, observations[field]) for field in VIEWS[view])


def intervention_label(key: str) -> str:
    return INTERVENTIONS.get(key, key)

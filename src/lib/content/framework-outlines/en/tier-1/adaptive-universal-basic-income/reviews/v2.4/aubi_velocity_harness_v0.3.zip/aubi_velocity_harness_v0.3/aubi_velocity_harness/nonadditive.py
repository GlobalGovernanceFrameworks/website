"""Non-additive state and intervention interaction stress tests.

This module extends the twelve-state corpus beyond convex mixtures. A joint
case starts from a weighted blend of two pure-state samples and adds an
interaction term that vanishes when either component is absent. The values are
synthetic audit constructions, not empirical estimates of Hearts economies.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from .model import Diagnosis, field_value, nearest_prototype_diagnosis, sample_case
from .scenarios import INTERVENTIONS, SCENARIOS, Scenario
from .views import FIELD_NOISE, FULL_FIELDS


SCENARIO_BY_NAME = {s.name: s for s in SCENARIOS}

# Audit-only interventions used by interaction cases.
INTERVENTIONS.setdefault(
    "support_informal_carers",
    "Provide respite and material support without monetizing informal care",
)
INTERVENTIONS.setdefault(
    "interaction_diagnostic_probe",
    "Run a bounded discriminatory probe before structural intervention",
)


@dataclass(frozen=True)
class InteractionSpec:
    id: str
    name: str
    left_state: str
    right_state: str
    description: str
    mechanism: str
    interaction_shifts: Mapping[str, float]
    preferred_sequence: Tuple[str, str]
    reverse_sequence: Tuple[str, str]
    unsafe_single_actions: frozenset[str]


@dataclass(frozen=True)
class InteractionCase:
    spec: InteractionSpec
    left_weight: float
    interaction_strength: float
    observations: Mapping[str, float]
    additive_counterfactual: Mapping[str, float]


@dataclass(frozen=True)
class PairDiagnosis:
    predicted_interaction: str
    confidence: float
    ranked: Tuple[Tuple[str, float], ...]
    unresolved: bool


@dataclass(frozen=True)
class TransitionResult:
    sequence: Tuple[str, ...]
    initial_utility: float
    final_utility: float
    velocity_change: float
    trust_change: float
    material_change: float
    observations: Mapping[str, float]


INTERACTIONS: Sequence[InteractionSpec] = (
    InteractionSpec(
        id="I1",
        name="trust_acceptance_trap",
        left_state="hearts_acceptance_gap",
        right_state="currency_governance_distrust",
        description="Low merchant acceptance and low trust reinforce one another: acceptance investment is under-used while failed use confirms distrust.",
        mechanism="Trust conditions uptake; failed or limited use of Hearts then feeds back into trust and redemption pressure.",
        interaction_shifts={
            "use_velocity_30d": -0.09,
            "recirculation_velocity": -0.10,
            "dormancy_90d_share": 0.08,
            "redemption_rate": 0.11,
            "failed_transaction_rate": 0.05,
            "essential_acceptance_rate": -0.05,
            "fiat_essential_burden": 0.08,
            "hearts_trust_score": -0.10,
            "material_sufficiency": -0.08,
        },
        preferred_sequence=("governance_trust_repair", "expand_acceptance_or_raise_fiat"),
        reverse_sequence=("expand_acceptance_or_raise_fiat", "governance_trust_repair"),
        unsafe_single_actions=frozenset({"increase_demurrage", "sufficiency_no_velocity_target"}),
    ),
    InteractionSpec(
        id="I2",
        name="ledger_concentration_distortion",
        left_state="balance_concentration",
        right_state="ledger_recording_failure",
        description="Under-recording is concentrated among small and offline wallets, so ledger failure inflates apparent concentration and corrupts targeting.",
        mechanism="Measurement error is distribution-dependent rather than independent noise.",
        interaction_shifts={
            "top10_balance_share": 0.16,
            "institutional_balance_share": 0.10,
            "median_balance_to_mean": -0.14,
            "offline_reconciliation_gap": 0.12,
            "provider_ledger_match": -0.14,
            "reported_provider_to_ledger_volume": 0.32,
            "subgroup_use_gap": 0.10,
        },
        preferred_sequence=("repair_ledger", "rebalance_concentrated_holdings"),
        reverse_sequence=("rebalance_concentrated_holdings", "repair_ledger"),
        unsafe_single_actions=frozenset({"increase_demurrage"}),
    ),
    InteractionSpec(
        id="I3",
        name="capacity_access_bottleneck",
        left_state="provider_capacity_shortage",
        right_state="geographic_temporal_access_mismatch",
        description="Additional central capacity does little for excluded groups and can raise aggregate utilisation while widening subgroup access gaps.",
        mechanism="Capacity is useful only conditional on access; aggregate utilisation conceals spatial bottlenecks.",
        interaction_shifts={
            "provider_capacity_utilization": 0.05,
            "unmet_demand_rate": 0.11,
            "median_wait_days": 3.5,
            "geographic_access_score": -0.09,
            "subgroup_use_gap": 0.16,
            "active_user_share": -0.06,
            "material_sufficiency": -0.06,
        },
        preferred_sequence=("improve_access", "expand_provider_capacity"),
        reverse_sequence=("expand_provider_capacity", "improve_access"),
        unsafe_single_actions=frozenset({"increase_demurrage", "seasonal_no_structural_change"}),
    ),
    InteractionSpec(
        id="I4",
        name="scarcity_quality_cascade",
        left_state="provider_category_shortage",
        right_state="provider_quality_relevance_failure",
        description="Scarcity protects low-quality providers from exit; rapid recruitment without quality repair reproduces the failure at larger scale.",
        mechanism="The effect of recruitment depends on the quality regime into which new providers enter.",
        interaction_shifts={
            "provider_capacity_utilization": 0.08,
            "unmet_demand_rate": 0.10,
            "provider_satisfaction": -0.14,
            "repeat_use_rate": -0.12,
            "hearts_trust_score": -0.07,
            "desired_formal_service_rate": -0.06,
        },
        preferred_sequence=("provider_quality_review", "recruit_provider_categories"),
        reverse_sequence=("recruit_provider_categories", "provider_quality_review"),
        unsafe_single_actions=frozenset({"increase_demurrage", "sufficiency_no_velocity_target"}),
    ),
    InteractionSpec(
        id="I5",
        name="seasonality_acceptance_mask",
        left_state="seasonal_cultural_rhythm",
        right_state="hearts_acceptance_gap",
        description="A seasonal lull suppresses attempted spending and reported unmet demand, temporarily hiding a structural acceptance gap.",
        mechanism="One cause changes the observability of the other rather than simply adding to it.",
        interaction_shifts={
            "unmet_demand_rate": -0.15,
            "desired_formal_service_rate": -0.13,
            "failed_transaction_rate": -0.03,
            "material_sufficiency": 0.07,
            "fiat_essential_burden": 0.07,
            "essential_acceptance_rate": -0.04,
            "seasonal_deviation_z": 0.55,
        },
        preferred_sequence=("expand_acceptance_or_raise_fiat", "seasonal_no_structural_change"),
        reverse_sequence=("seasonal_no_structural_change", "expand_acceptance_or_raise_fiat"),
        unsafe_single_actions=frozenset({"sufficiency_no_velocity_target", "increase_demurrage"}),
    ),
    InteractionSpec(
        id="I6",
        name="informal_care_overload",
        left_state="informal_gift_economy_substitution",
        right_state="geographic_temporal_access_mismatch",
        description="Formal access failure pushes demand into informal networks, preserving apparent sufficiency while overloading carers.",
        mechanism="Informal substitution changes sign: benign reciprocity becomes a hidden support burden when formal access is absent.",
        interaction_shifts={
            "informal_substitution_rate": 0.08,
            "informal_care_burden": 0.34,
            "material_sufficiency": 0.05,
            "desired_formal_service_rate": 0.20,
            "subgroup_use_gap": 0.13,
            "unmet_demand_rate": -0.06,
            "geographic_access_score": -0.06,
        },
        preferred_sequence=("improve_access", "support_informal_carers"),
        reverse_sequence=("support_informal_carers", "improve_access"),
        unsafe_single_actions=frozenset({"protect_informal_exchange", "sufficiency_no_velocity_target", "increase_demurrage"}),
    ),
    InteractionSpec(
        id="I7",
        name="ratio_distrust_feedback",
        left_state="fiat_hearts_composition_mismatch",
        right_state="currency_governance_distrust",
        description="An unusable Hearts share is interpreted as coercive, deepening distrust and accelerating redemption.",
        mechanism="Currency composition affects legitimacy; legitimacy then changes the behavioural effect of composition reform.",
        interaction_shifts={
            "hearts_usable_budget_share": -0.05,
            "fiat_essential_burden": 0.08,
            "hearts_trust_score": -0.12,
            "redemption_rate": 0.13,
            "dormancy_90d_share": 0.06,
            "material_sufficiency": -0.08,
        },
        preferred_sequence=("recalibrate_fiat_hearts_ratio", "governance_trust_repair"),
        reverse_sequence=("governance_trust_repair", "recalibrate_fiat_hearts_ratio"),
        unsafe_single_actions=frozenset({"increase_demurrage"}),
    ),
    InteractionSpec(
        id="I8",
        name="sufficiency_concentration_mask",
        left_state="benign_sufficiency_demand_saturation",
        right_state="balance_concentration",
        description="High average sufficiency masks a low-balance subgroup whose deprivation is hidden by concentrated dormant holdings.",
        mechanism="Aggregation makes a distributional failure resemble benign low demand.",
        interaction_shifts={
            "material_sufficiency": 0.05,
            "top10_balance_share": 0.14,
            "median_balance_to_mean": -0.14,
            "subgroup_use_gap": 0.18,
            "unmet_demand_rate": -0.05,
            "desired_formal_service_rate": -0.05,
        },
        preferred_sequence=("rebalance_concentrated_holdings", "sufficiency_no_velocity_target"),
        reverse_sequence=("sufficiency_no_velocity_target", "rebalance_concentrated_holdings"),
        unsafe_single_actions=frozenset({"sufficiency_no_velocity_target", "increase_demurrage"}),
    ),
)

INTERACTION_BY_NAME = {s.name: s for s in INTERACTIONS}


def _clip(field: str, value: float) -> float:
    if field == "seasonal_deviation_z":
        return value
    if field in {
        "enrolled_participants",
        "median_wait_days",
        "provider_category_count",
        "reported_provider_to_ledger_volume",
    }:
        return max(0.0, value)
    return max(0.0, min(1.0, value))


def _blend(
    left: Mapping[str, float], right: Mapping[str, float], left_weight: float
) -> Dict[str, float]:
    return {
        field: left_weight * left[field] + (1.0 - left_weight) * right[field]
        for field in left
    }


def interaction_activation(left_weight: float, strength: float) -> float:
    """Bilinear term: zero at either pure state and one at a 50/50 joint case."""
    return 4.0 * left_weight * (1.0 - left_weight) * strength


def sample_interaction_case(
    spec: InteractionSpec,
    rng: random.Random,
    noise_scale: float = 1.0,
    left_weight: float | None = None,
    interaction_strength: float | None = None,
) -> InteractionCase:
    left = SCENARIO_BY_NAME[spec.left_state]
    right = SCENARIO_BY_NAME[spec.right_state]
    weight = left_weight if left_weight is not None else rng.uniform(0.35, 0.65)
    strength = interaction_strength if interaction_strength is not None else rng.uniform(0.75, 1.25)
    left_case = sample_case(left, rng, noise_scale=noise_scale)
    right_case = sample_case(right, rng, noise_scale=noise_scale)
    additive = _blend(left_case.observations, right_case.observations, weight)
    observations = dict(additive)
    activation = interaction_activation(weight, strength)
    for field, shift in spec.interaction_shifts.items():
        observations[field] = _clip(field, observations[field] + activation * shift)
    return InteractionCase(
        spec=spec,
        left_weight=weight,
        interaction_strength=strength,
        observations=observations,
        additive_counterfactual=additive,
    )


def normalized_distance(
    observations: Mapping[str, float], prototype: Mapping[str, float], fields: Iterable[str]
) -> float:
    terms = []
    for field in fields:
        scale = max(FIELD_NOISE.get(field, 0.03) * 2.5, 0.015)
        terms.append(((observations[field] - prototype[field]) / scale) ** 2)
    return math.sqrt(sum(terms) / max(len(terms), 1))


def _clean_prototype(scenario: Scenario) -> Dict[str, float]:
    return {field: field_value(scenario, field) for field in FULL_FIELDS}


def additive_interaction_prototype(spec: InteractionSpec, left_weight: float = 0.5) -> Dict[str, float]:
    return _blend(
        _clean_prototype(SCENARIO_BY_NAME[spec.left_state]),
        _clean_prototype(SCENARIO_BY_NAME[spec.right_state]),
        left_weight,
    )


def nonadditive_interaction_prototype(
    spec: InteractionSpec, left_weight: float = 0.5, strength: float = 1.0
) -> Dict[str, float]:
    proto = additive_interaction_prototype(spec, left_weight)
    activation = interaction_activation(left_weight, strength)
    for field, shift in spec.interaction_shifts.items():
        proto[field] = _clip(field, proto[field] + activation * shift)
    return proto


def pair_diagnosis(
    observations: Mapping[str, float],
    interaction_aware: bool,
    unresolved_margin: float = 0.04,
) -> PairDiagnosis:
    distances = []
    for spec in INTERACTIONS:
        prototype = (
            nonadditive_interaction_prototype(spec)
            if interaction_aware
            else additive_interaction_prototype(spec)
        )
        distances.append((spec.name, normalized_distance(observations, prototype, FULL_FIELDS)))
    distances.sort(key=lambda item: (item[1], item[0]))
    weights = [math.exp(-d) for _, d in distances]
    total = sum(weights)
    ranked = tuple((name, weight / total) for (name, _), weight in zip(distances, weights))
    unresolved = ranked[0][1] - ranked[1][1] < unresolved_margin
    return PairDiagnosis(
        predicted_interaction="interaction_unresolved" if unresolved else ranked[0][0],
        confidence=ranked[0][1],
        ranked=ranked,
        unresolved=unresolved,
    )


def constituent_recall(diagnosis: Diagnosis, spec: InteractionSpec, k: int = 2) -> float:
    expected = {spec.left_state, spec.right_state}
    found = {name for name, _ in diagnosis.ranked_states[:k]}
    return len(expected & found) / 2.0


def interaction_residual(case: InteractionCase) -> float:
    return normalized_distance(case.observations, case.additive_counterfactual, FULL_FIELDS)


def outcome_vector(observations: Mapping[str, float]) -> Dict[str, float]:
    material = 0.65 * observations["material_sufficiency"] + 0.35 * (1.0 - observations["fiat_essential_burden"])
    access = (
        0.45 * observations["geographic_access_score"]
        + 0.30 * (1.0 - observations["unmet_demand_rate"])
        + 0.25 * (1.0 - observations["subgroup_use_gap"])
    )
    trust = observations["hearts_trust_score"]
    integrity = 0.55 * observations["provider_ledger_match"] + 0.45 * (1.0 - observations["offline_reconciliation_gap"])
    care = 1.0 - observations["informal_care_burden"]
    equity = 0.45 * (1.0 - observations["top10_balance_share"]) + 0.30 * observations["median_balance_to_mean"] + 0.25 * (1.0 - observations["subgroup_use_gap"])
    return {
        "material": _clip("material_sufficiency", material),
        "access": _clip("material_sufficiency", access),
        "trust": _clip("material_sufficiency", trust),
        "integrity": _clip("material_sufficiency", integrity),
        "care": _clip("material_sufficiency", care),
        "equity": _clip("material_sufficiency", equity),
    }


def utility(observations: Mapping[str, float]) -> float:
    outcomes = outcome_vector(observations)
    # A weighted mean plus a bottleneck penalty prevents a high average from
    # fully concealing one severely failed dimension.
    mean = (
        0.25 * outcomes["material"]
        + 0.20 * outcomes["access"]
        + 0.17 * outcomes["trust"]
        + 0.13 * outcomes["integrity"]
        + 0.12 * outcomes["care"]
        + 0.13 * outcomes["equity"]
    )
    return mean - 0.12 * (1.0 - min(outcomes.values()))


def _shift(obs: Dict[str, float], field: str, amount: float) -> None:
    obs[field] = _clip(field, obs[field] + amount)


def apply_intervention(
    observations: Mapping[str, float],
    action: str,
    history: Tuple[str, ...] = (),
    interaction_name: str | None = None,
) -> Dict[str, float]:
    """Synthetic one-step transition model with conditional action effects."""
    obs = dict(observations)

    if action == "governance_trust_repair":
        trust_gain = 0.27
        if interaction_name == "ratio_distrust_feedback" and "recalibrate_fiat_hearts_ratio" not in history:
            trust_gain = 0.12
        _shift(obs, "hearts_trust_score", trust_gain)
        _shift(obs, "redemption_rate", -0.09)
        _shift(obs, "dormancy_90d_share", -0.03)
        _shift(obs, "provider_satisfaction", 0.05)

    elif action == "expand_acceptance_or_raise_fiat":
        uptake = 1.0 if obs["hearts_trust_score"] >= 0.45 else 0.35
        _shift(obs, "essential_acceptance_rate", 0.28 * uptake)
        _shift(obs, "hearts_usable_budget_share", 0.18 * uptake)
        _shift(obs, "fiat_essential_burden", -0.23 * (0.55 + 0.45 * uptake))
        _shift(obs, "material_sufficiency", 0.16 * uptake)
        _shift(obs, "use_velocity_30d", 0.10 * uptake)
        _shift(obs, "failed_transaction_rate", -0.04 * uptake)

    elif action == "repair_ledger":
        _shift(obs, "offline_reconciliation_gap", -0.36)
        _shift(obs, "provider_ledger_match", 0.40)
        obs["reported_provider_to_ledger_volume"] = max(0.0, 1.02)
        # Repair reveals previously hidden small-wallet activity.
        _shift(obs, "top10_balance_share", -0.08)
        _shift(obs, "institutional_balance_share", -0.05)
        _shift(obs, "median_balance_to_mean", 0.07)

    elif action == "rebalance_concentrated_holdings":
        integrity = outcome_vector(obs)["integrity"]
        if interaction_name == "ledger_concentration_distortion" and "repair_ledger" not in history:
            # Targeting from corrupted records imposes costs without reliably
            # reaching the low-balance group.
            _shift(obs, "top10_balance_share", -0.05)
            _shift(obs, "median_balance_to_mean", -0.03)
            _shift(obs, "material_sufficiency", -0.05)
            _shift(obs, "hearts_trust_score", -0.07)
        else:
            _shift(obs, "top10_balance_share", -0.27)
            _shift(obs, "institutional_balance_share", -0.17)
            _shift(obs, "median_balance_to_mean", 0.18)
            _shift(obs, "subgroup_use_gap", -0.12)
            _shift(obs, "material_sufficiency", 0.07)

    elif action == "improve_access":
        _shift(obs, "geographic_access_score", 0.28)
        _shift(obs, "subgroup_use_gap", -0.21)
        _shift(obs, "unmet_demand_rate", -0.13)
        _shift(obs, "material_sufficiency", 0.08)
        _shift(obs, "active_user_share", 0.08)

    elif action == "expand_provider_capacity":
        access_ready = obs["geographic_access_score"] >= 0.55 or "improve_access" in history
        _shift(obs, "provider_capacity_utilization", -0.18)
        _shift(obs, "median_wait_days", -5.0 if access_ready else -1.5)
        _shift(obs, "unmet_demand_rate", -0.24 if access_ready else -0.07)
        if not access_ready:
            _shift(obs, "subgroup_use_gap", 0.07)
        else:
            _shift(obs, "material_sufficiency", 0.08)

    elif action == "provider_quality_review":
        _shift(obs, "provider_satisfaction", 0.29)
        _shift(obs, "repeat_use_rate", 0.24)
        _shift(obs, "hearts_trust_score", 0.08)
        _shift(obs, "provider_capacity_utilization", -0.05)

    elif action == "recruit_provider_categories":
        quality_ready = obs["provider_satisfaction"] >= 0.50 or "provider_quality_review" in history
        _shift(obs, "effective_category_coverage", 0.27)
        _shift(obs, "provider_redundancy", 0.22)
        _shift(obs, "unmet_demand_rate", -0.19 if quality_ready else -0.06)
        if not quality_ready:
            _shift(obs, "provider_satisfaction", -0.09)
            _shift(obs, "hearts_trust_score", -0.04)

    elif action == "support_informal_carers":
        access_ready = obs["geographic_access_score"] >= 0.55 or "improve_access" in history
        relief = 0.32 if access_ready else 0.16
        _shift(obs, "informal_care_burden", -relief)
        _shift(obs, "material_sufficiency", 0.09 if access_ready else 0.04)
        _shift(obs, "desired_formal_service_rate", -0.06 if access_ready else -0.02)

    elif action == "protect_informal_exchange":
        # Protection is beneficial when care is voluntary, but no substitute
        # for support when burden is high.
        if obs["informal_care_burden"] > 0.55:
            _shift(obs, "informal_care_burden", 0.04)
            _shift(obs, "material_sufficiency", -0.03)
        else:
            _shift(obs, "hearts_trust_score", 0.03)

    elif action == "recalibrate_fiat_hearts_ratio":
        _shift(obs, "assigned_hearts_share", -0.10)
        _shift(obs, "hearts_usable_budget_share", 0.12)
        _shift(obs, "fiat_essential_burden", -0.19)
        _shift(obs, "material_sufficiency", 0.14)
        _shift(obs, "hearts_trust_score", 0.10)
        _shift(obs, "redemption_rate", -0.10)

    elif action in {"seasonal_no_structural_change", "sufficiency_no_velocity_target"}:
        pass

    elif action == "increase_demurrage":
        # Headline metric improves while trust and welfare can deteriorate.
        _shift(obs, "use_velocity_30d", 0.18)
        _shift(obs, "recirculation_velocity", 0.10)
        _shift(obs, "dormancy_90d_share", -0.13)
        _shift(obs, "hearts_trust_score", -0.22)
        _shift(obs, "redemption_rate", 0.17)
        if obs["essential_acceptance_rate"] < 0.50 or obs["hearts_trust_score"] < 0.40:
            _shift(obs, "material_sufficiency", -0.08)
            _shift(obs, "fiat_essential_burden", 0.07)

    elif action in {"generic_diagnostic_review", "interaction_diagnostic_probe"}:
        pass

    else:
        raise ValueError(f"Unknown intervention {action!r}")

    return obs


def simulate_sequence(
    case: InteractionCase, sequence: Sequence[str]
) -> TransitionResult:
    initial = dict(case.observations)
    current = dict(initial)
    history: Tuple[str, ...] = tuple()
    for action in sequence:
        current = apply_intervention(
            current, action, history=history, interaction_name=case.spec.name
        )
        history = history + (action,)
    return TransitionResult(
        sequence=tuple(sequence),
        initial_utility=utility(initial),
        final_utility=utility(current),
        velocity_change=current["use_velocity_30d"] - initial["use_velocity_30d"],
        trust_change=current["hearts_trust_score"] - initial["hearts_trust_score"],
        material_change=current["material_sufficiency"] - initial["material_sufficiency"],
        observations=current,
    )


def pure_classifier_action(case: InteractionCase, unresolved_margin: float = 0.07) -> str:
    diagnosis = nearest_prototype_diagnosis(
        case.observations, "full", unresolved_margin=unresolved_margin
    )
    return diagnosis.intervention

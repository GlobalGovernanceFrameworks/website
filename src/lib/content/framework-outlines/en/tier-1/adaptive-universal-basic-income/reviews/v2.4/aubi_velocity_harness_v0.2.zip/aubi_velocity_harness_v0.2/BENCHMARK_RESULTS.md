# Benchmark results — v0.2, seed 7, 250 replicates per state

The clean benchmark sampled 3,000 synthetic pure-state cases: 250 noisy realizations of each of the twelve hidden states. Sampling is deterministic for a fixed seed.

| Policy / observation view | State accuracy | Specific intervention accuracy | Safe action rate | Harmful intervention rate | Unresolved rate |
|---|---:|---:|---:|---:|---:|
| Current provider heuristic | 8.3% | 8.3% | 8.3% | 58.3% | 0.0% |
| Current demurrage heuristic | 0.0% | 0.0% | 0.1% | 99.9% | 0.1% |
| Conservative current response | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, current view | 0.0% | 0.0% | 100.0% | 0.0% | 100.0% |
| Nearest prototype, decomposed view | 25.1% | 25.1% | 100.0% | 0.0% | 74.9% |
| Nearest prototype, full view | 99.3% | 99.3% | 100.0% | 0.0% | 0.7% |

## Interpretation

- The **current dashboard contains zero prototype separation by construction**. All twelve states have identical headline values, so a responsible evaluator records `cause unresolved`.
- Direct provider or demurrage responses are unsafe because they act on one possible cause as though it were identified.
- Decomposed financial telemetry identifies some states—especially concentration and unusual redemption—but leaves most cases unresolved.
- The full proposed sensor portfolio makes the twelve designed pure prototypes almost completely separable at the default noise level.
- The adversarial audit demonstrates that this clean result does **not** generalize to mixed states, correlated observation failures, or coordinated reporting attacks.

These results establish only internal separability of the pure synthetic corpus. They do not validate the numerical prototypes, state frequencies, observation channels, or real-world intervention effects.

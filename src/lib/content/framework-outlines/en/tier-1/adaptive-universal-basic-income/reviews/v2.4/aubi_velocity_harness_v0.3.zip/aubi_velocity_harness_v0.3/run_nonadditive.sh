#!/usr/bin/env bash
set -euo pipefail
python -m aubi_velocity_harness nonadditive-audit --output nonadditive_outputs "$@"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m aubi_velocity_harness equivalence --view current --limit 5
printf '\n'
python -m aubi_velocity_harness benchmark --replicates 250 --seed 7

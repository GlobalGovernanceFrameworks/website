# Non-Additive Interaction Falsification Gate v0.1

**Harness version:** 0.3  
**Parent artifacts:** AUBI Observability Audit v0.1; Low Hearts Velocity Indistinguishable-State Test v0.1; Adversarial Corpus Audit v0.2  
**Status:** Synthetic architectural falsification test  
**Empirical status:** None. All interaction functions, intervention effects, utilities, and numerical values are audit constructions.

## Executive result

The gate falsifies two stronger assumptions that could have been read into the earlier harness:

1. **Superposition:** a joint low-velocity condition can be represented adequately as a weighted average of two pure-state signatures;
2. **Open-loop separability:** once the active causes are identified, their interventions can be selected independently and applied in either order.

The first assumption fails selectively rather than universally. An additive pair model identified the correct constructed pair in 87.2% of cases, while a model supplied with the interaction signatures reached 99.8%. The entire large failure was concentrated in the ratio–distrust interaction, where the additive model abstained rather than identifying the pair.

The second assumption fails more strongly. Intervention order changed final utility in 73.9% of all cases. Two of the eight corpus cases are intentionally order-insensitive; among the six designed to contain policy-order dependence, the preferred order won in approximately 98.5% of simulations.

The cautious pure-state classifier remained protective: it returned **cause unresolved** in 85.8% of joint cases. When forced to select one pure-state intervention, however, the resulting single action left more than 0.02 synthetic utility on the table relative to the preferred two-step plan in 76.6% of cases and reduced utility outright in 11.7%.

Finally, the synthetic demurrage stress intervention increased the headline velocity measure while reducing the composite welfare utility in 100.0% of constructed cases. This is a test fixture demonstrating logical possibility, not an estimate of how often real demurrage would do so.

> **What survives:** richer observation and an unresolved option remain useful, but safe control requires an interaction model, intervention preconditions, policy-order testing, and post-action welfare checks. Identifying causes is not yet equivalent to knowing how to intervene.

## 1. Gate question

> When two low-velocity causes coexist, do their observations and intervention effects equal the weighted sum of their isolated effects?

The gate separates two forms of non-additivity:

- **state interaction:** one cause changes how another appears in the observation channel;
- **policy interaction:** one intervention changes the effectiveness, targeting, or legitimacy of another intervention.

A third concern follows:

- **observation feedback:** the intervention changes the very signal used to justify it, so apparent success may be measurement-channel success rather than welfare improvement.

## 2. Corpus

| ID | Interaction | Constituent states | Non-additive mechanism | Preferred sequence |
|---|---|---|---|---|
| I1 | trust_acceptance_trap | hearts_acceptance_gap + currency_governance_distrust | Trust conditions uptake; failed or limited use of Hearts then feeds back into trust and redemption pressure. | governance_trust_repair → expand_acceptance_or_raise_fiat |
| I2 | ledger_concentration_distortion | balance_concentration + ledger_recording_failure | Measurement error is distribution-dependent rather than independent noise. | repair_ledger → rebalance_concentrated_holdings |
| I3 | capacity_access_bottleneck | provider_capacity_shortage + geographic_temporal_access_mismatch | Capacity is useful only conditional on access; aggregate utilisation conceals spatial bottlenecks. | improve_access → expand_provider_capacity |
| I4 | scarcity_quality_cascade | provider_category_shortage + provider_quality_relevance_failure | The effect of recruitment depends on the quality regime into which new providers enter. | provider_quality_review → recruit_provider_categories |
| I5 | seasonality_acceptance_mask | seasonal_cultural_rhythm + hearts_acceptance_gap | One cause changes the observability of the other rather than simply adding to it. | expand_acceptance_or_raise_fiat → seasonal_no_structural_change |
| I6 | informal_care_overload | informal_gift_economy_substitution + geographic_temporal_access_mismatch | Informal substitution changes sign: benign reciprocity becomes a hidden support burden when formal access is absent. | improve_access → support_informal_carers |
| I7 | ratio_distrust_feedback | fiat_hearts_composition_mismatch + currency_governance_distrust | Currency composition affects legitimacy; legitimacy then changes the behavioural effect of composition reform. | recalibrate_fiat_hearts_ratio → governance_trust_repair |
| I8 | sufficiency_concentration_mask | benign_sufficiency_demand_saturation + balance_concentration | Aggregation makes a distributional failure resemble benign low demand. | rebalance_concentrated_holdings → sufficiency_no_velocity_target |

Each case begins with a noisy weighted blend of two pure-state observations. A bilinear interaction term is then added: it vanishes when either constituent is absent and is strongest near a balanced joint state. This makes the joint observation irreducible to the convex mixture used in v0.2.

## 3. Methods

### 3.1 Static diagnosis

The audit compares:

- the cautious pure-state nearest-prototype classifier from v0.2;
- a forced pure-state classifier with no unresolved margin;
- an additive pair classifier using 50/50 blends of constituent prototypes;
- an interaction-aware pair classifier supplied with the eight non-additive prototypes.

The interaction-aware classifier is not a discovery system. It is an oracle-like test of whether the observations become distinguishable once the correct interaction forms are already represented.

### 3.2 Dynamic intervention model

Each interaction defines two action orders. Synthetic transition functions make effects conditional on prior actions and current state. Examples:

- acceptance expansion has weak uptake while trust is very low;
- balance reallocation is mis-targeted before ledger repair;
- central capacity expansion has weak effects before access barriers are addressed;
- provider recruitment reproduces low quality unless quality governance changes first;
- support for informal carers is less durable while formal access failure remains;
- trust repair is partially undermined while an unusable currency composition remains unchanged.

Synthetic utility combines material security, access, trust, observation integrity, care sustainability, and distributional equity, with a penalty for a severely failed dimension.

### 3.3 Benchmark

- 8 interaction specifications;
- 300 noisy replicates per interaction;
- 2,400 cases total;
- fixed seed 29;
- deterministic and byte-reproducible outputs under the included test suite.

## 4. Overall results

| Measure | Result | Interpretation |
|---|---:|---|
| Cautious pure-state unresolved rate | 85.8% | The unresolved margin usually prevents a false singular diagnosis. |
| Pure classifier recalls both constituents in top two | 59.2% | Even rich sensors often fail to retain both active causes in the leading hypotheses. |
| Additive pair accuracy | 87.2% | Most known pairs remain recognizable without interaction terms, but not all. |
| Interaction-aware pair accuracy | 99.8% | Near-complete recovery is possible when the correct interaction library is supplied. |
| Path-dependence rate | 73.9% | Action order changes final synthetic welfare in most constructed cases. |
| Forced single-action material-regret rate | 76.6% | A singular response is commonly materially inferior to the staged plan. |
| Forced single-action negative-utility rate | 11.7% | Some forced singular responses make the constructed condition worse. |
| Demurrage metric–welfare divergence | 100.0% | Velocity can improve while the welfare objective deteriorates. |

## 5. Results by interaction

| Interaction | Additive pair | Interaction-aware | Path dependent | Preferred order wins | Forced single-action regret |
|---|---:|---:|---:|---:|---:|
| trust_acceptance_trap | 97.3% | 98.7% | 99.3% | 99.3% | 100.0% |
| ledger_concentration_distortion | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| capacity_access_bottleneck | 100.0% | 100.0% | 99.7% | 99.7% | 100.0% |
| scarcity_quality_cascade | 100.0% | 100.0% | 100.0% | 100.0% | 33.3% |
| seasonality_acceptance_mask | 100.0% | 100.0% | 0.0% | 0.0% | 52.3% |
| informal_care_overload | 100.0% | 100.0% | 92.0% | 92.0% | 100.0% |
| ratio_distrust_feedback | 0.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| sufficiency_concentration_mask | 100.0% | 100.0% | 0.0% | 0.0% | 27.3% |

### 5.1 Selective failure of superposition

The additive pair representation is not uniformly bad. It identifies seven interactions at 97.3–100% in this synthetic corpus. The decisive exception is **ratio_distrust_feedback**, where the additive model returns unresolved in all benchmark cases while the interaction-aware model identifies the pair in 100%.

The defensible conclusion is therefore not “all mixtures require nonlinear models.” It is:

> Additive approximation must be tested interaction by interaction; some joint conditions remain identifiable, while others create a new signature that is absent from either constituent and from their convex blend.

### 5.2 Stronger failure of policy separability

The preferred sequence outperforms the reverse sequence in the six cases designed to contain ordering effects. The two intentionally order-insensitive cases—seasonality_acceptance_mask and sufficiency_concentration_mask—serve as negative controls: the benchmark does not manufacture order effects where the transition rules contain none.

### 5.3 Metric improvement is not outcome improvement

The demurrage stress action directly raises use velocity and recirculation and lowers dormancy. It simultaneously reduces trust, increases redemption pressure, and can reduce material sufficiency when acceptance or legitimacy is weak. The resulting metric–welfare divergence occurs in all constructed interaction cases.

This does not establish that demurrage is harmful. It establishes that **velocity response cannot validate the intervention that caused the velocity response**.

## 6. Falsification verdict

### Claim A: joint states can be treated as convex mixtures

**Verdict: partially falsified.**

The approximation survives for most enumerated interactions as a recognition aid, but fails completely for one important feedback case and produces systematic non-additive residuals in all eight.

### Claim B: identify the causes, then apply their interventions independently

**Verdict: falsified within the constructed transition model.**

Intervention efficacy depends on preconditions and order. A list of active causes is insufficient to determine a safe plan.

### Claim C: improved velocity after intervention confirms correct diagnosis

**Verdict: falsified by construction.**

An intervention can mechanically improve the monitored signal while worsening the underlying welfare state.

### Claim D: unresolved is merely a temporary inconvenience

**Verdict: rejected.**

The unresolved state is a core safety mechanism. Removing it forces singular interventions that are commonly incomplete and sometimes harmful.

## 7. Architectural amendments

### 7.1 Joint-state register

The diagnostic should permit a State Estimate Record to contain:

- multiple simultaneously active causes;
- hypothesized interaction mechanisms;
- evidence for and against each interaction;
- subgroup-specific states;
- an explicit “interaction form unknown” status.

### 7.2 Intervention preconditions

Each structural intervention should specify conditions under which it is expected to work. Examples:

- expand acceptance only with an adequate trust and usability pathway;
- rebalance holdings only after transaction and identity records pass an integrity threshold;
- expand capacity only after mapping access and location constraints;
- recruit providers only under a functioning quality and charter regime.

### 7.3 Sequence plan

The decision record should distinguish:

- immediate reversible action;
- enabling intervention;
- dependent intervention;
- expected observation change after each step;
- stop, reverse, and escalation conditions.

### 7.4 Bounded diagnostic probes

When interaction structure is uncertain, the BAZ should prefer small, reversible probes that discriminate hypotheses—for example:

- reconcile one offline transaction sample before interpreting concentration;
- expand acceptance in one essential category before changing the regional currency ratio;
- add mobile provision in one excluded area before expanding central capacity;
- run an independent trust and privacy review before increasing circulation pressure.

### 7.5 Dual outcome monitoring

Every velocity intervention should be evaluated on at least two levels:

1. **mechanism response:** velocity, dormancy, redemption, or use;
2. **purpose response:** material sufficiency, access, trust, autonomy, care burden, and distribution.

A mechanism indicator must not certify itself.

### 7.6 Preserve pre-intervention evidence

Because interventions modify the observation channel, the system should retain immutable pre-intervention snapshots, method versions, and causal expectations. Otherwise the post-action state can erase evidence that the original diagnosis was wrong.

## 8. Proposed AUBI patch

> **Interaction and sequencing requirement.** When more than one plausible cause of low Hearts velocity is active, the responsible BAZ body must assess whether the causes interact such that their joint observations or intervention effects differ from the sum of their isolated effects. The State Estimate Record must identify intervention preconditions and, where order matters, publish a staged sequence with expected welfare and telemetry responses after each step. A change in velocity, dormancy, or redemption after intervention is not sufficient evidence that the intervention improved material security, access, trust, autonomy, care sustainability, or distributional equity. Where the interaction form is unresolved, only reversible diagnostic probes and protective measures are authorized.

## 9. Limitations

- The eight interaction forms were selected by the audit, not discovered from data.
- The interaction-aware classifier is given the correct hypothesis library.
- The transition functions encode the intended ordering effects; the benchmark demonstrates their implications rather than empirically validating them.
- The composite utility is normative and synthetic.
- Pairwise interactions do not cover three-way interactions, endogenous adaptation, strategic actors, or long-run institutional learning.
- The numerical rates should be read as regression-test properties of this corpus, not probabilities for actual BAZs.

## 10. Final conclusion

The previous audit showed that richer sensing does not guarantee safety when observations are mixed, corrupted, or strategically controlled. This gate adds a distinct result:

> **Even a correct diagnosis of the active causes may be insufficient, because causes change one another and interventions change both the state and the observation channel.**

The AUBI velocity architecture therefore needs more than a diagnostic classifier. It needs a small causal control protocol: joint-state hypotheses, intervention preconditions, sequencing, reversible probes, immutable evidence, and welfare-based stop conditions.

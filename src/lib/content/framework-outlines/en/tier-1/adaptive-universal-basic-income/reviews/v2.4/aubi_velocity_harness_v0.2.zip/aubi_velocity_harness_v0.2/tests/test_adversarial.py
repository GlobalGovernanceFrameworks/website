from __future__ import annotations

import random
import unittest

from aubi_velocity_harness.adversarial import (
    ATTACK_PROFILES,
    ambiguous_midpoint,
    apply_correlated_failure,
    blend_cases,
    integrity_gated_diagnosis,
    stratified_mixture_diagnosis,
)
from aubi_velocity_harness.adversarial_benchmark import (
    ambiguity_margin_sweep,
    mixture_benchmark,
)
from aubi_velocity_harness.model import nearest_prototype_diagnosis, sample_case
from aubi_velocity_harness.scenarios import SCENARIOS


class AdversarialHarnessTests(unittest.TestCase):
    def test_stratified_view_detects_two_distinct_subgroups(self) -> None:
        rng = random.Random(4)
        mixed = blend_cases(SCENARIOS[0], SCENARIOS[8], 0.5, rng, noise_scale=0.0)
        diagnosis = stratified_mixture_diagnosis(mixed)
        self.assertTrue(diagnosis.unresolved)
        self.assertEqual(diagnosis.predicted_state, "mixed_or_heterogeneous")

    def test_detectable_correlated_failure_triggers_integrity_gate(self) -> None:
        rng = random.Random(5)
        case = sample_case(SCENARIOS[0], rng, noise_scale=0.0)
        attacked = apply_correlated_failure(case.observations, ATTACK_PROFILES[0], concealed=False)
        diagnosis = integrity_gated_diagnosis(attacked)
        self.assertTrue(diagnosis.unresolved)
        self.assertEqual(diagnosis.intervention, "generic_diagnostic_review")

    def test_concealed_failure_does_not_trigger_metadata_gate(self) -> None:
        rng = random.Random(6)
        case = sample_case(SCENARIOS[0], rng, noise_scale=0.0)
        attacked = apply_correlated_failure(case.observations, ATTACK_PROFILES[0], concealed=True)
        diagnosis = integrity_gated_diagnosis(attacked)
        self.assertNotEqual(diagnosis.predicted_state, "observation_integrity_unresolved")

    def test_ambiguity_margin_has_restraint_accuracy_tradeoff(self) -> None:
        rows = ambiguity_margin_sweep(replicates_per_pair=10, seed=7)
        self.assertGreaterEqual(
            rows[-1]["ambiguous_correct_restraint_rate"],
            rows[0]["ambiguous_correct_restraint_rate"],
        )
        self.assertGreaterEqual(
            rows[-1]["pure_unresolved_rate"], rows[0]["pure_unresolved_rate"]
        )

    def test_mixture_benchmark_stratified_detects_more_heterogeneity(self) -> None:
        rows = mixture_benchmark(replicates_per_pair=5, seed=8, noise_scale=0.5)
        by_name = {row["policy"]: row for row in rows}
        self.assertGreater(
            by_name["stratified_full"]["heterogeneity_detection_rate"],
            by_name["aggregate_full"]["heterogeneity_detection_rate"],
        )


if __name__ == "__main__":
    unittest.main()

# Cross-Framework Protective Action Envelope v0.1

## A non-authoritative transport wrapper for compound action identity, route separation, responsibility acknowledgement, protected material, review, remedy, and closure

**Specification ID:** `CFPAE/0.1`  
**Status:** Draft for cluster adoption and implementation testing  
**Date:** 2026-08-01  
**Constitutional parent:** *Security, Coercion, and Protective Action Interface Specification v0.1 (`SCPA/0.1`)*  
**Record-inheritance parent:** *SCPA Record Inheritance and Conformance Clause v0.1 (`SCPA-RIC/0.1`)*  
**Related emergency interface:** *Emergency Cross-Domain Event Envelope v0.1 (`CDEE/0.1`)*

---

# Executive rule

> **The Cross-Framework Protective Action Envelope gives one compound protective action a stable shared identity without giving any institution shared jurisdiction, command, custody, or power.**

The Envelope is a transport wrapper, responsibility index, and lifecycle coordination object. It links independently constituted SCPA records, framework functions, jurisdictions, handoffs, custodians, notices, reviews, expiries, remedies, and closure duties. It is not `SCPA-45`, and it does not replace any `SCPA-01` through `SCPA-44` record.

> **This Envelope coordinates identity, routing, acknowledgement, custody, review, remedy, and closure. It does not establish facts, dangerousness, guilt, emergency, jurisdiction, legal standing, authority, command, investigation, compulsory process, custody, force, sanctions, removal, adjudication, or security-use permission.**

> **One compound action identity; many authorities; no residual power.**

---

# 1. Purpose

Protective and security cases often cross institutional boundaries. A peace practitioner may receive an imminent-danger disclosure; a community-safety function may continue survivor support; a separately constituted authority may undertake urgent protective action; a mobility authority may assess asylum and non-refoulement; Shield may coordinate victim protection or mutual legal assistance; Justice may review a warrant or detention; and an Aegis-converted asset may be proposed for a security-facing role that triggers reversion.

Constitutional separation is desirable, but separation fails operationally when participants:

1. create incompatible case identifiers;
2. assume that another institution accepted a responsibility;
3. transmit an entire care or mediation file when only minimum information is lawful;
4. treat protected information as investigation authority;
5. lose evidence, credential, asset, or data custody;
6. merge review clocks or allow one open process to prolong another;
7. close an operation while release, correction, property return, remedy, or data disposition remains pending;
8. treat a civilian asset offer as security authorization;
9. use an emergency event identifier as coercive authority; or
10. silently substitute later framework versions.

This Specification supplies a common envelope for those seams. It enables participants to:

- recognize that their records concern the same compound action;
- preserve local case, mission, event, subject, asset, and record identifiers;
- display each proposed, authorized, active, suspended, rejected, terminated, or remedial action route separately;
- identify the authority, law, jurisdiction, exact act, affected subjects, safeguards, review, expiry, challenge, termination, and remedy for each route;
- offer, receive, find deficient, partially accept, accept, share, reject, withdraw, return, or close a responsibility explicitly;
- preserve sender duties and protected non-transfer restrictions;
- track information, evidence, asset, credential, software, data, knowledge, and record custody separately from responsibility and command;
- link CDEE and ECRC records without merging emergency and security authority;
- track Aegis security-use reversion without treating reversion as authorization; and
- close only after all consequential routes and surviving duties are lawfully resolved.

# 2. Scope

The Envelope applies when two or more materially distinct functions, jurisdictions, frameworks, or legal routes coordinate around one protective or security-related situation, or when a single-framework matter is likely to require later handoff.

It may be used for:

- imminent-danger referrals involving Peace, Kintsugi, and a separate urgent-protection function;
- trafficking survivor support, asylum, victim protection, investigation, and non-refoulement;
- cross-border crime cooperation and mutual legal assistance;
- a case containing intelligence, investigation, compulsory process, custody, adjudication, and remedy records;
- cyber incidents requiring defensive action, evidence preservation, third-party disruption review, and service restoration;
- asset freezes involving innocent-party continuity, review, release, restitution, and compensation;
- humanitarian corridors involving negotiation, reception, screening, transport, territorial authority, and non-refoulement;
- converted capabilities proposed for border, police, detention, intelligence, cyber, sanctions, or armed use;
- compound cases spanning criminal, asylum, community-safety, peace, Indigenous, and emergency processes;
- false allegations, rejected referrals, failed handoffs, wrongful action, and correction;
- institutional succession or dissolution while services, claims, records, credentials, or assets remain open; and
- after-action review and unresolved-risk custody after powers terminate.

The Envelope may be used for non-coercive coordination at a lower conformance level. No lower conformance level authorizes a consequential action.

# 3. Controlling constitutional boundaries

The Envelope inherits and operationalizes the following rules:

1. **No valid authority record, no consequential action.** The Envelope never supplies `SCPA-01` or another required authority record.
2. **Protective purpose does not create protective jurisdiction.** Benevolent intent, urgency, vulnerability, community support, or technical capability cannot replace legal authority.
3. **Shared identity is not shared command.** A stable compound identifier does not merge institutions, jurisdictions, chains of command, professional duties, or liability.
4. **Transport is not authorization.** Packaging, signing, validating, encrypting, or delivering a record cannot increase its legal effect.
5. **Receipt is not acceptance.** Silence, technical ingestion, acknowledgement of delivery, or participation in a meeting does not transfer responsibility.
6. **Acceptance is function-specific.** A recipient accepts only the named function, scope, material, authority, safeguards, and clock.
7. **Sender duties survive transport.** Correction, source protection, care continuity, evidence preservation, notice, worker, survivor, child, Indigenous, and prior-act duties survive unless valid law and an accepted record explicitly reassign them.
8. **Information is not investigation authority.** `SCPA-09` or `SCPA-10` material cannot silently become `SCPA-11` or `SCPA-12`.
9. **Investigation is not compulsory process.** `SCPA-11` or `SCPA-12` cannot silently become `SCPA-13` through `SCPA-17`.
10. **Urgent protection is not custody or force.** `SCPA-18` cannot silently become `SCPA-19` through `SCPA-25`.
11. **Security allegation is not mobility consequence.** Protected or secret information cannot itself authorize detention, exclusion, extradition, deportation, removal, or denial of protection.
12. **Reversion is not security authorization.** `SCPA-44` suspends civilian assurances but does not authorize the proposed use.
13. **An open envelope does not preserve power.** Every authority, credential, restriction, surveillance measure, restraint, detention, freeze, or access route expires under its own law and clock.
14. **Unknown jurisdiction remains unauthorized.** The Envelope may record contested or unassigned responsibility; it cannot fill the gap.
15. **No universal case ledger.** Public indexing is layered and purpose-limited; protected sources, survivors, children, medical records, Indigenous-restricted knowledge, intelligence, evidence, and operational details remain protected.
16. **No silent version substitution.** Every engagement, route, record specialization, and interface pins the exact tested version.

# 4. Relationship to SCPA records and the inheritance clause

The Envelope is not `SCPA-45`. It is a containing package governed by `SCPA-RIC/0.1` Clause 7.

- Every contained or linked SCPA record retains its canonical identifier, 27-field header, action class, exact act, authority, legal source, jurisdiction, access class, review clock, expiry, challenge, termination, disposition, remedy, and correction history.
- The Envelope may contain, import, extend, or reference domain specializations only when their inheritance relationship is explicit.
- A single form or user interface may display several records, but it may not merge their authority, status, review, closure, access, or remedy.
- A route may depend on several records. The Envelope shall identify every dependency and block the affected consequential action when one required record is missing, expired, incompatible, or protected from use.
- A record may appear in several envelopes only when the relationship and purpose are recorded. Duplication does not create multiple authorities or permit incompatible use.
- Record correction, withdrawal, supersession, expiry, or termination shall propagate as a notice to every envelope that references the record without rewriting historical states.

# 5. Common record header inheritance

Every record reference carried in the Envelope shall expose or inherit the following fields at the appropriate access layer:

| # | Field | Minimum meaning |
|---:|---|---|
| 1 | `record_id` | Canonical SCPA identifier. |
| 2 | `record_instance_id` | Unique instance identifier. |
| 3 | `record_version` | Record or specialization version. |
| 4 | `status` | Lifecycle state. |
| 5 | `created_at_and_effective_at` | Creation and effective timestamps. |
| 6 | `created_by_and_role` | Creator and functional role. |
| 7 | `competent_authority` | Authority competent for the exact act. |
| 8 | `legal_source_and_version` | Exact constituting legal source. |
| 9 | `jurisdiction` | Territorial, personal, subject-matter, temporal, and cross-border basis. |
| 10 | `cluster_event_id_or_case_mission_identifier` | Shared identity without shared command. |
| 11 | `action_class_and_exact_act` | SCPA class and precise act. |
| 12 | `affected_subjects` | Protected references to affected persons, assets, systems, places, or institutions. |
| 13 | `linked_records` | Authority, review, termination, remedy, and other record links. |
| 14 | `source_and_reliability_limits` | Provenance, uncertainty, contest, and reliability limits. |
| 15 | `prohibited_inferences` | Inferences the record cannot support. |
| 16 | `rights_and_safeguards` | Rights, accessibility, protected-status, labour, survivor, child, and Indigenous safeguards. |
| 17 | `access_class` | SCPA access class and stronger lawful restrictions. |
| 18 | `notice_status` | Notice state, reasons, limits, and review. |
| 19 | `review_authority_and_review_due_at` | Review authority and clock. |
| 20 | `expires_at_or_non_expiry_basis` | Expiry or valid non-expiry basis. |
| 21 | `challenge_route` | Complaint, appeal, counsel, representative, or urgent challenge. |
| 22 | `termination_trigger` | Condition ending, suspending, narrowing, or reclassifying the action. |
| 23 | `data_disposition_rule` | Retention, correction, deletion, sealing, transfer, return, or protected custody. |
| 24 | `remedy_route` | Release, correction, restitution, compensation, property return, public correction, or institutional remedy. |
| 25 | `supersedes_and_superseded_by` | Immutable predecessor and successor links. |
| 26 | `integrity_digest` | Integrity digest that proves neither truth nor authority. |
| 27 | `public_summary_or_protection_reason` | Public or claimant-accessible account, or lawful protection reason. |

The Envelope may cache selected fields for routing, but the canonical record remains controlling. A cache shall identify its source version and last verification time. An envelope cache cannot revive an expired or superseded record.

# 6. Compound action identity

## 6.1 Immutable protective-action cluster identifier

Every Envelope has one immutable `protective_action_cluster_id`. The identifier binds related routes, handoffs, records, custodians, reviews, remedies, and closure duties to one administrative topology. It must not encode a person’s identity, protected location, allegation, offence, migration status, dangerousness score, origin hypothesis, responsible institution, or legal conclusion.

## 6.2 Versioned envelope identifier

`envelope_id` identifies one serialized state of the Envelope. Corrections and updates create a new envelope version or instance while preserving the immutable `protective_action_cluster_id` and correction history.

## 6.3 Local identifiers

Participants retain local:

- case identifiers;
- incident or event identifiers;
- mission identifiers;
- court, warrant, detention, asylum, or appeal identifiers;
- subject and survivor-protected references;
- asset, system, account, credential, and facility identifiers; and
- SCPA and domain record instance identifiers.

Local identifiers are linked; they are not replaced or made authoritative outside the issuing system.

## 6.4 Optional CDEE linkage

Where the matter is also an emergency or catastrophic-risk event, the Envelope may link a `cluster_event_id` and `CDEE/0.1` envelope. The two identities remain distinct:

- CDEE coordinates event identity, emergency-domain engagement, emergency responsibility, and ECRC lifecycle;
- CFPAE coordinates SCPA action routes, function-specific acceptance, protected material, review, remedy, and closure.

Neither identifier creates the other’s authority. The future Emergency–Security Dual-Interface Bridge shall define any stronger cross-link.

# 7. Topology

The Envelope may record parent, child, split, merge, duplicate, related, sequential, concurrent, and dependency relationships.

## 7.1 Parent and child envelopes

A parent may coordinate several separable action clusters. Child envelopes retain independent authorities, access controls, clocks, remedies, and closure states.

## 7.2 Split

A split is required when materially different territories, authorities, protected populations, action classes, access regimes, or review clocks cannot remain safely administered in one envelope. The split shall preserve the source identity and state which routes, records, duties, and custodial items moved or remained.

## 7.3 Merge

A merge may consolidate duplicate administrative envelopes. It shall preserve every former identifier, route state, correction, rejected handoff, protected restriction, and remedy. Merge does not establish common facts, guilt, causation, liability, or authority.

## 7.4 Related but distinct matters

Matters may share a person, organization, event, asset, territory, evidence item, or risk without becoming the same action cluster. Possible duplicates shall be linked rather than silently collapsed.

# 8. Registrar and envelope steward

## 8.1 Registrar

The registrar creates the first `protective_action_cluster_id`. Registration may be performed by an adopted record office, host authority, court registry, protected referral service, mutual-assistance network, mobility authority, community-safety function, Peace node, Shield secretariat, or other authorized administrative function.

Registration creates no substantive power and does not validate the allegations or records supplied.

## 8.2 Envelope steward

The steward may:

- preserve identity and topology;
- route offers, notices, corrections, expiry alerts, and closure requests;
- maintain a current responsibility and custody index;
- track response deadlines;
- verify schema and compatibility metadata;
- provide protected access according to recorded classes; and
- produce a non-authoritative public or claimant-accessible summary.

The steward may not:

- determine dangerousness, guilt, credibility, legal status, or factual truth;
- classify intelligence or open an investigation;
- issue a warrant or order;
- command an operation or converted asset;
- decide custody, force, sanctions, asylum, removal, or adjudication;
- override protected non-transfer;
- treat silence as acceptance;
- extend a power, record, or deadline; or
- become residual owner of an unaccepted responsibility.

The steward shall have a named successor or failover process. Loss of the steward does not transfer authority to another participant.

# 9. Core field groups

A conforming Envelope contains at least:

1. schema and compatibility metadata;
2. immutable compound identity and versioned envelope identity;
3. topology and local identifier links;
4. registrar and steward;
5. framework engagements and exact versions;
6. action-route registry;
7. authority and jurisdiction references;
8. responsibility assignments;
9. handoff records;
10. SCPA and domain record bundle index;
11. protected information, evidence, asset, credential, software, and data custody map;
12. affected-person notice, challenge, counsel, interpretation, and representation map;
13. survivor, child, disability, Indigenous, worker, and other safeguard profiles;
14. command, technical command, professional authority, custody, and stop-work map where applicable;
15. review, expiry, termination, correction, remedy, and disposition clocks;
16. public-information and correction ownership;
17. optional emergency/CDEE links;
18. optional Aegis reversion links;
19. closure state and unresolved duties;
20. correction and supersession history; and
21. integrity metadata and non-authority statement.

# 10. Framework engagement registry

Every participating or notified framework is recorded with:

- framework identifier, version, and source hash;
- engagement state: `notified`, `assessing`, `active`, `supporting`, `suspended`, `declined`, `terminated`, or `event_specific_not_applicable`;
- exact function offered or performed;
- local case or mission identifier;
- responsible function and contact route;
- legal or non-coercive basis;
- accepted records and protected restrictions;
- review and closure owner; and
- compatibility status.

Framework engagement does not imply acceptance of a handoff or authority over another route.

# 11. Action-route registry

Each materially distinct proposed, authorized, active, suspended, rejected, terminated, or remedial act shall have one route entry.

A route entry shall state:

- `route_id`;
- SCPA class and exact act;
- proposed, awaiting authority, authorized, active, suspended, rejected, terminated, remedial, or closed state;
- responsible framework function;
- competent authority and legal source;
- jurisdiction;
- affected subjects using protected references;
- required SCPA records;
- current record instances and validity;
- dependencies and prohibited transitions;
- access class;
- notice and challenge status;
- review and expiry clocks;
- termination trigger;
- remedy and disposition requirements; and
- route-specific closure state.

## 11.1 Route independence

An open route does not keep another route open. A pending investigation does not prolong urgent protection, custody, surveillance, asset restraint, or security-use reversion. An unresolved risk does not extend authority.

## 11.2 Composite operations

An operational mission may involve several routes—for example voluntary support, urgent protection, transport, screening, detention, evidence preservation, and asylum. Each route remains independently classified and authorized. A single mission charter cannot legalize the package.

## 11.3 Prohibited transitions

The Envelope shall block or flag at least:

- `SCPA-09/10` to `SCPA-11/12` without investigation authority;
- `SCPA-11/12` to `SCPA-13`–`17` without compulsory-process authority;
- `SCPA-18` to `SCPA-19`–`25` without custody, force, equipment, and command records;
- `SCPA-26` to `SCPA-27` without third-party cyber authority;
- `SCPA-17` preservation or restraint to `SCPA-28` forfeiture, sanctions, or exclusion without separate authority;
- `SCPA-29` cooperation to any operational power without host and action-specific authority;
- `SCPA-30` security allegation to detention, exclusion, transfer, or removal without the required mobility, review, challenge, and non-refoulement records;
- `SCPA-34` restoration or rehabilitation to guilt, detention, surveillance, or immigration consequence;
- `SCPA-44` reversion to security authorization; and
- any record or route to continued use after expiry or termination.

# 12. Authority and jurisdiction map

The Envelope shall index, but not decide:

- the exact authority source for each route;
- territorial, personal, subject-matter, temporal, and cross-border jurisdiction;
- host, sending, receiving, Indigenous, professional, judicial, and asset-control authorities;
- contested, concurrent, limited, or unassigned jurisdiction;
- standing and affected-party status;
- applicable law and conflict rules;
- independent authorization and review functions; and
- authority-return destination.

Unknown or contested jurisdiction is displayed as unresolved. It is not assigned to the steward or the most capable participant.

# 13. Responsibility assignment table

Responsibility is assigned by function, not by broad labels such as “lead agency,” “security owner,” or “case owner.” Functions may include:

- care continuity;
- survivor advocacy;
- minimum imminent-danger referral;
- urgent protection;
- medical care;
- asylum and non-refoulement;
- identity reconstruction;
- victim protection;
- intelligence source protection;
- investigation;
- compulsory process;
- evidence custody;
- custody welfare and release;
- cyber defence and restoration;
- asset custody and innocent-party continuity;
- adjudication and appeal;
- public communication and correction;
- worker and operator safety;
- data disposition;
- compensation and remedy; and
- programme or institutional closure.

Every assignment shall identify the function, responsible body, legal or non-coercive basis, state, scope, retained duties, review, expiry, and closure condition.

## 13.1 Concurrent responsibility

Two or more bodies may hold concurrent responsibilities where their functions remain distinct. Concurrent responsibility does not create shared command, pooled authority, or collective liability by default.

## 13.2 Contested or unassigned responsibility

The Envelope records disagreement and escalation routes. It does not allocate the function. Essential protection and service continuity shall not be abandoned merely because coercive jurisdiction is unresolved; only lawfully non-coercive or separately authorized interim acts may proceed.

# 14. Handoff protocol

Every handoff uses one canonical state:

- `offered`;
- `received_not_assessed`;
- `deficient`;
- `partially_accepted`;
- `accepted`;
- `concurrent_responsibility`;
- `rejected`;
- `withdrawn`;
- `returned`; or
- `closed`.

A handoff records:

- sender and recipient functions;
- exact offered function and requested outcome;
- exact SCPA and domain records or material offered;
- legal basis and purpose;
- minimum-necessary rationale;
- access classes and protected non-transfer restrictions;
- affected-person notice and challenge status;
- deadline and acknowledgement;
- accepted, rejected, deficient, or protected-withheld scope;
- retained sender duties;
- recipient duties;
- custody changes or non-transfer access;
- review and expiry clocks;
- correction and return routes;
- termination and closure conditions; and
- remedy for wrongful or incomplete transfer.

## 14.1 Silence is never acceptance

No technical receipt, meeting attendance, automatic system import, or elapsed deadline changes the handoff to accepted. Sender duties remain.

## 14.2 Partial acceptance

A recipient may accept care continuity but reject evidence custody; accept victim protection but reject investigation; accept a mutual-assistance request only for voluntary interviews; or accept transport while rejecting screening, guarded custody, or intelligence functions.

## 14.3 Protected non-transfer

Where material cannot lawfully transfer, the handoff may use:

- non-identifying notice;
- aggregate or redacted attestation;
- purpose-limited query;
- protected reviewer access;
- sender-retained custody;
- a substitute challenge mechanism; or
- refusal.

Urgency does not create disclosure authority.

# 15. SCPA record bundle index

The Envelope may contain or reference any of the following records while preserving their separate legal identity:

| Canonical ID | Canonical title | Function |
|---|---|---|
| `SCPA-01` | Protective or Coercive Action Authority Provenance Record | cross-cutting |
| `SCPA-02` | Standing, Jurisdiction, and Territorial Basis Map | cross-cutting |
| `SCPA-03` | Action Classification and Procedural Route Record | cross-cutting |
| `SCPA-04` | Individualized Factual Basis and Attribution Record | cross-cutting |
| `SCPA-05` | Prohibited Inference and Automated-Use Record | cross-cutting |
| `SCPA-06` | Necessity, Proportionality, and Alternatives Record | cross-cutting |
| `SCPA-07` | Rights, Accessibility, and Protected-Status Safeguards Record | cross-cutting |
| `SCPA-08` | Notice, Reasons, Counsel, Interpretation, and Challenge Record | cross-cutting |
| `SCPA-09` | Protected Information or Source Intake Record | B |
| `SCPA-10` | Intelligence Purpose, Minimization, and Dissemination Record | B |
| `SCPA-11` | Investigation Opening and Mandate Record | C |
| `SCPA-12` | Investigation Method, Scope, and Minimization Record | C |
| `SCPA-13` | Compulsory Process Application Record | E |
| `SCPA-14` | Search, Entry, Inspection, or Access Authorization Record | E |
| `SCPA-15` | Disclosure, Production, Preservation, or Interception Order Record | E |
| `SCPA-16` | Evidence Seizure, Copying, and Chain-of-Custody Record | E |
| `SCPA-17` | Asset Preservation, Freeze, Restraint, or Seizure Record | E |
| `SCPA-18` | Urgent Protective Action Record | D |
| `SCPA-19` | Arrest or Physical Restraint Record | F |
| `SCPA-20` | Custody or Detention Authority and Welfare Record | F |
| `SCPA-21` | Release, Bail, Supervision, or Less-Restrictive Alternative Record | F |
| `SCPA-22` | Transfer, Extradition, Removal, or Return Authority Record | F/K |
| `SCPA-23` | Use-of-Force Incident and Necessity Record | F |
| `SCPA-24` | Weapons, Restraint Device, and Special Equipment Authorization Record | F |
| `SCPA-25` | Mission Command, Technical Command, Custody, and Stop-Work Record | F |
| `SCPA-26` | Defensive Cyber Action Record | G |
| `SCPA-27` | Third-Party Cyber Access, Disruption, or Counter-Operation Record | G |
| `SCPA-28` | Financial Coercion, Sanction, Freeze, Forfeiture, or Exclusion Record | H |
| `SCPA-29` | Cross-Border Cooperation and Mutual Legal Assistance Record | cross-border |
| `SCPA-30` | Asylum, Protection, Non-Refoulement, and Security-Allegation Record | K |
| `SCPA-31` | Independent Authorization, Adjudication, or Review Record | I |
| `SCPA-32` | Appeal, Complaint, Urgent Challenge, and Interim Relief Record | I |
| `SCPA-33` | Remedy, Restitution, Property Return, and Compensation Record | I |
| `SCPA-34` | Restorative, Rehabilitation, Correctional, or Reintegration Consent and Suitability Record | J |
| `SCPA-35` | Security Data Disposition, Correction, Expungement, and Use-Limitation Record | closure |
| `SCPA-36` | Action Termination, Authority Return, and Unresolved-Risk Custody Record | closure |
| `SCPA-37` | Identity, Credential, and Service-Access Function Separation Record | protected functions |
| `SCPA-38` | Child, Dependent Person, Guardianship, and Best-Interests Record | protected persons |
| `SCPA-39` | Indigenous Territory, Authority, Knowledge, and Affected-Nation Interface Record | protected persons |
| `SCPA-40` | Survivor Safety, Confidentiality, and Process Choice Record | protected persons |
| `SCPA-41` | Worker, Operator, Responder, and Whistleblower Protection Record | protected persons |
| `SCPA-42` | Public Communication, Classification, Correction, and Non-Propaganda Record | communication |
| `SCPA-43` | Security Institution Transfer, Succession, or Dissolution Continuity Plan | continuity |
| `SCPA-44` | Coercive-Power Non-Activation and Security-Use Reversion Register | non-activation |

For every record reference, the Envelope shall state:

- canonical identifier and instance identifier;
- domain specialization and inheritance relationship;
- source framework and version;
- current lifecycle state;
- authority and jurisdiction status;
- action route or routes served;
- access class;
- validity, expiry, supersession, and correction status;
- protected non-transfer restrictions;
- review and challenge links; and
- closure dependencies.

# 16. Custody and material map

Responsibility, command, ownership, possession, access, and custody are distinct.

The Envelope shall separately map custody for:

- confidential source information;
- mediation and care records;
- survivor and child material;
- asylum and identity records;
- medical and disability information;
- Indigenous-restricted knowledge;
- intelligence reports;
- physical and digital evidence;
- seized property and restrained assets;
- devices, systems, accounts, logs, and credentials;
- converted assets, software, remote-access paths, and classified interfaces;
- court, review, appeal, and remedy records; and
- public communication and correction material.

Each item identifies:

- item reference and type;
- current owner, possessor, custodian, controller, and key holder where relevant;
- source and collection basis;
- purpose and permitted uses;
- access class and access list;
- onward-transfer restrictions;
- integrity and chain-of-custody status;
- correction and contest status;
- retention or disposition rule;
- return or destruction destination; and
- remedy for misuse, loss, or wrongful retention.

A change in functional responsibility does not automatically change custody. Custody transfer does not transfer adjudication, command, ownership, or legal responsibility.

# 17. Affected-person interface

For each affected person or protected group, the Envelope shall record, at the appropriate access layer:

- protected reference;
- capacity and representation needs;
- notice status and reasons for any lawful limitation;
- counsel, advocate, guardian, interpreter, disability support, or Indigenous representative;
- challenge, complaint, appeal, interim relief, and urgent review routes;
- service and care continuity;
- contact and safety restrictions;
- information the person may access or correct;
- remedies and compensation routes; and
- route-specific outcomes.

One institution’s notice does not satisfy another route’s notice duty unless valid law and the accepted record expressly provide equivalent notice.

# 18. Safeguard profiles

The Envelope shall make visible, without merging authority, applicable safeguards for:

- survivors and trafficked persons;
- children and dependent persons;
- persons with disabilities or in acute distress;
- asylum seekers, refugees, stateless persons, and persons at risk of refoulement;
- Indigenous nations, territories, knowledge, and affected peoples;
- journalists, lawyers, mediators, health workers, spiritual advisers, and protected sources;
- workers, operators, responders, whistleblowers, and safe-refusal claimants;
- innocent owners, employees, depositors, patients, creditors, and essential-service users; and
- persons affected by secrecy, watchlisting, mistaken identity, or automated systems.

Safeguards remain route-specific and cumulative. The Envelope shall apply the stronger lawful protection where two rules conflict.

# 19. Command, custody, force, and stop-work map

Where an operation involves personnel, assets, custody, force, weapons, special equipment, cyber access, or converted capabilities, the Envelope shall separately identify:

1. host or territorial mission authority;
2. operational mission direction;
3. immediate safety and technical command;
4. professional authority;
5. custody authority and welfare responsibility;
6. force and weapons authority;
7. data and cyber administration;
8. owner and custodian rights;
9. worker or operator stop-work authority;
10. Aegis conversion-integrity or reversion responsibility; and
11. independent review and claims authority.

A broad “lead” field is non-conforming if it obscures these distinctions.

# 20. Review, expiry, termination, and remedy calendar

The Envelope shall maintain one calendar entry per independent authority or duty. It shall not collapse clocks.

Calendar entries may include:

- intelligence retention review;
- investigation mandate review;
- warrant or compulsory-order expiry;
- urgent protective-action review;
- custody and detention review;
- force-incident review;
- cyber isolation or disruption expiry;
- asset restraint and sanctions review;
- asylum interim relief and non-refoulement review;
- appeal deadlines;
- Aegis reversion and requalification review;
- public correction deadlines;
- service continuity and worker protection review;
- property, credential, asset, and authority return;
- data disposition;
- restitution and compensation; and
- institutional succession or dissolution.

An open investigation, asylum claim, public controversy, unresolved threat, or envelope cannot renew another power.

# 21. Public information and correction

The Envelope may identify a public-information coordinator, but not a truth authority.

Public layers shall distinguish:

- allegation from established fact;
- source report from intelligence assessment;
- technical attribution from legal attribution;
- administrative linkage from causation;
- emergency status from security authority;
- proposed action from authorized action;
- accepted responsibility from mere notification;
- active power from expired or terminated power; and
- unresolved risk from lawful authority.

Every public or claimant-accessible summary shall identify correction ownership and avoid exposing protected identities, locations, sources, knowledge, methods, or evidence.

# 22. Emergency and CDEE linkage

When the same situation is governed by both emergency and SCPA interfaces:

- `protective_action_cluster_id` and CDEE `cluster_event_id` are linked, not merged;
- emergency declarations and powers remain in ECRC records;
- SCPA authorities remain in SCPA records;
- event status does not determine power status;
- a CDEE handoff does not substitute for an SCPA handoff;
- an SCPA route does not declare or renew an emergency;
- review, expiry, termination, restoration, disposition, and remedy clocks remain separately visible; and
- an Aegis asset may be bounded by both emergency converted-capability rules and SCPA security-use reversion.

Until the Emergency–Security Dual-Interface Bridge is adopted, any ambiguous cross-link fails closed for the affected consequential action.

# 23. Aegis security-use reversion linkage

When an Aegis or equivalent converted capability is requested for a security-facing use, the Envelope shall link a current `SCPA-44` register and record:

- the requested act and SCPA class;
- the smallest separable capability unit;
- former and residual military, intelligence, police, border, detention, cyber, targeting, weapons, sanctions, and remote-access functions;
- civilian-status suspension;
- technical and organizational segregation;
- operator, owner, host, technical, and legal authorities;
- worker notice, pay continuity, and safe refusal;
- public markings and mission representation;
- security authority status outside Aegis;
- data and credential boundaries;
- reversion, requalification, or permanent decommissioning state; and
- claims, correction, and remedy.

The Envelope shall reject any route that treats reversion, asset readiness, ownership, emergency demand, public markings, or former military use as security authorization.

# 24. Corrections, supersession, merge, and split

Every correction preserves:

- the previous envelope and record state;
- correcting actor and authority;
- reason and evidence basis;
- affected routes, handoffs, custody items, notices, public statements, clocks, and remedies;
- propagation status to recipients and affected persons; and
- whether action must pause, narrow, reverse, or remain terminated.

A correction cannot silently delete a rejected handoff, failed authority claim, wrongful action, expired power, protected restriction, dissent, or compensation duty.

# 25. Closure and reopening

## 25.1 Route closure

A route may close only when its action has terminated or been rejected, authority has returned, required notice and challenge have been provided, material and property have reached lawful custody or disposition, and surviving remedy duties are assigned.

## 25.2 Envelope closure

The Envelope may enter `closed` only when:

- every action route is closed, transferred through accepted responsibility, or recorded as unresolved under a lawful non-authority custody arrangement;
- every handoff is closed, returned, withdrawn, rejected, or accepted with completed duties;
- expired powers, credentials, restrictions, access routes, and security-use permissions are terminated;
- custody, property, assets, software, credentials, and data are returned, transferred, sealed, corrected, deleted, or otherwise lawfully disposed;
- affected-person notice, challenge, release, reunification, service continuity, and representation duties are complete or assigned;
- correction, restitution, compensation, and institutional remedies are complete or assigned;
- public correction ownership remains identifiable;
- worker and operator duties are complete;
- unresolved risks are recorded without extending authority; and
- the closure verifier is independent of any contested consequential act where required.

`operationally_complete` is not `closed`.

## 25.3 Reopening

Reopening an Envelope restores coordination only. It does not reactivate an expired authority, warrant, custody, force, sanctions, removal, cyber, intelligence, or security-use permission. New or renewed powers require new or validly renewed SCPA records.

# 26. Access, privacy, security, and integrity

The Envelope uses SCPA access classes:

- `SCPA-PUBLIC`;
- `SCPA-AFFECTED`;
- `SCPA-REVIEW`;
- `SCPA-OPERATIONAL`; and
- `SCPA-PROTECTED`.

An envelope-level label cannot weaken an item’s inherited class. Systems shall support field-, item-, route-, and recipient-level restrictions where necessary.

Integrity mechanisms may include signatures, hashes, append-only history, access logs, secure transport, and offline records. They prove neither truth, legal validity, authority, informed consent, nor lawful use.

Implementations shall provide low-tech and offline routes. Mandatory blockchain, biometrics, centralized identity, universal cloud hosting, or one global case registry is prohibited.

# 27. Validation rules

A CFPAE document is invalid for consequential routing when:

- `schema_version` is absent or incompatible;
- the non-authority statement is absent or altered to imply power;
- `protective_action_cluster_id` is missing or changes without a recorded merge or split;
- a route lacks class, exact act, authority status, jurisdiction status, required records, review, expiry, termination, or remedy;
- the Envelope or steward is listed as competent authority or operational commander;
- an accepted handoff lacks recipient acknowledgement and accepted scope;
- silence or timeout is treated as acceptance;
- one record or route silently activates another;
- an access class is weakened;
- protected non-transfer is overridden by urgency or convenience;
- one clock extends another;
- a closed Envelope retains an active or suspended consequential route, unresolved authority return, pending release, pending remedy, or pending disposition;
- Aegis reversion is treated as authorization;
- CDEE linkage is treated as an emergency or security power; or
- an untested framework version is substituted.

# 28. Failure handling

## 28.1 No steward available

Participants retain local records and the stable cluster identity, continue lawful service and protection duties, and nominate a replacement through an adopted process. No participant gains substantive authority.

## 28.2 Conflicting compound identifiers

Link as possible duplicates. Compare topology, routes, records, and affected subjects under protected conditions. Merge administratively or preserve both. Do not delete history.

## 28.3 Receiver does not respond

The handoff remains `offered` or `received_not_assessed`. Sender duties continue. Escalation follows the relevant legal, service, court, or mutual-assistance route. No recipient is auto-assigned.

## 28.4 Recipient accepts only part

Record `partially_accepted`, accepted function, rejected or deficient scope, withheld protected material, retained sender duties, custody, notice, clocks, and closure.

## 28.5 Jurisdiction unresolved

Record contested or unassigned status. Lawful voluntary service or narrowly authorized urgent protection may continue; investigation, compulsory process, custody, force, sanctions, removal, or other consequential action does not proceed without authority.

## 28.6 Protected material cannot transfer

Use minimum notice, aggregate attestation, protected review, purpose-limited query, sender-retained custody, or refusal. Do not create a disclosure exception through envelope use.

## 28.7 Version conflict

Continue only with the last tested compatible version where lawful, record the conflict, and block affected consequential routes until compatibility is resolved.

## 28.8 Essential protection would be stranded

A failed coercive handoff does not terminate independently lawful shelter, healthcare, legal aid, interpretation, disability support, survivor advocacy, child protection, non-refoulement, or other essential service. The Envelope identifies the service-continuity owner.

# 29. Prohibited uses

The Envelope shall not be used to:

- create a universal security, risk, credibility, migration, or social-cohesion score;
- compile a universal watchlist or target registry;
- turn mediation, care, health, spiritual, survivor, child, asylum, or Indigenous records into intelligence by default;
- infer guilt, dangerousness, consent, causation, or liability from association in one envelope;
- create joint command or a “lead authority” with residual powers;
- bypass a warrant, court, territorial authority, non-refoulement, survivor choice, or protected-source rule;
- treat framework engagement as acceptance;
- compel participation or disclosure;
- hide contested facts or rejected responsibilities in a consensus field;
- extend power through an open case or unresolved risk;
- permit self-financing enforcement from restrained assets;
- authorize detention, force, cyber disruption, sanctions, deportation, extradition, or security use;
- disguise military, intelligence, police, border, or detention use as civilian Aegis support;
- erase failed, wrongful, expired, rejected, or corrected actions;
- prevent an affected person from accessing challenge or remedy; or
- infer compatibility from a later version number.

# 30. Minimum adoption clause

A participating framework, authority, compact, court, service network, or operational manual may adopt this Specification using substantially the following clause:

> **Cross-Framework Protective Action Envelope adoption.** For any compound protective, security, mobility, community-safety, peace, cyber, financial-coercion, justice, or converted-capability matter, records governed by this instrument shall use the Cross-Framework Protective Action Envelope v0.1 (`CFPAE/0.1`) or a tested compatible successor. The Envelope supplies stable compound identity, action-route separation, exact framework and record references, function-specific responsibility acknowledgement, canonical handoff states, protected material and custody indexing, affected-person interfaces, independent review and expiry calendars, security-use reversion links, remedy, and verified closure. It creates no authority, jurisdiction, command, investigation, compulsory process, custody, force, cyber power, financial coercion, mobility consequence, adjudication, emergency, or security-use permission. Every consequential act remains governed by its own valid SCPA records. Silence is not acceptance. Shared identity is not shared command. Reversion is not authorization. An open Envelope does not keep power alive.**

# 31. Conformance levels

| Level | Requirement |
|---|---|
| **CFPAE-L0 — Correlation** | Stable compound identity, schema version, topology, local identifiers, and non-authority statement. Suitable only for non-consequential correlation. |
| **CFPAE-L1 — Protected coordination** | L0 plus framework engagements, action routes, responsibility assignments, handoff states, record index, custody map, affected-person interface, and review calendar. |
| **CFPAE-L2 — Consequential routing** | L1 plus complete valid SCPA dependencies, authority and jurisdiction references, access inheritance, protected non-transfer, notice and challenge, independent clocks, termination, remedy, disposition, and exact compatibility manifest. |
| **CFPAE-L3 — Closure verified** | L2 plus closed or validly transferred routes, completed handoffs, authority and credential return, custody and data disposition, correction, remedy, worker duties, unresolved-risk custody without residual power, and independent closure verification. |

No implementation may present L0 or L1 as sufficient authorization for consequential action.

# 32. Required implementation tests

A conforming implementation shall test at least:

1. Peace sends a minimum imminent-danger referral while retaining mediation confidentiality.
2. Kintsugi accepts care continuity but not evidence custody or investigation responsibility.
3. A separate urgent-protection authority accepts only `SCPA-18` and does not receive the full care record.
4. Shield accepts victim-protection coordination but rejects investigation until `SCPA-11` exists.
5. Migration accepts asylum and non-refoulement functions while rejecting an unsupported security allegation.
6. A trafficking survivor refuses prosecution but retains shelter, legal aid, and immigration protection.
7. An accepted handoff records recipient acknowledgement and exact scope.
8. A silent recipient remains unassigned and sender duties continue.
9. A partially accepted handoff identifies rejected material, retained duties, and service continuity.
10. Two bodies hold concurrent but non-command responsibilities.
11. `SCPA-09/10` material is blocked from becoming an investigation without `SCPA-11/12`.
12. An investigation is blocked from search or disclosure without `SCPA-13` through `SCPA-16` as applicable.
13. Urgent protection is blocked from becoming custody or force without `SCPA-19` through `SCPA-25` as applicable.
14. Defensive cyber isolation is blocked from third-party disruption without `SCPA-27`.
15. Asset restraint is blocked from forfeiture, sanctions, or programme funding without separate authority.
16. A security allegation in asylum proceedings preserves notice-substance or equivalent challenge, interim relief, and non-refoulement.
17. A reception facility that blocks exit is reclassified as custody.
18. An Indigenous authority prohibits transfer of knowledge, evidence, location, or identity data.
19. A child receives services without biometric enrolment and without immigration detention.
20. An Aegis-converted asset requested for border surveillance enters `SCPA-44`; civilian status is suspended but use remains unauthorized.
21. An inseparable remote-access subsystem causes whole-capability reversion.
22. A disaster case links CDEE and CFPAE identities without merging emergency and security powers.
23. One route expires while another remains open; the expired route cannot continue.
24. A wrongfully detained or watchlisted person receives release, correction, expungement, property return, compensation, and public correction.
25. A protected source later seeks correction and deletion after a cross-framework referral.
26. A public statement is corrected without exposing the protected source or survivor.
27. A framework version conflict blocks the affected consequential route.
28. The envelope steward disappears without creating residual authority.
29. A programme dissolves while services, assets, records, credentials, workers, and claims remain open.
30. An Envelope closes only after authority return, handoff closure, data disposition, correction, remedy, and unresolved-risk custody are verified.

A blocked action counts as a fail-closed pass only if the block is visible, reviewable, does not transfer authority silently, and does not strand an affected person without independently lawful protection or essential service.

# 33. Amendment and compatibility

A successor requires published compatibility analysis. Breaking changes include:

- changing the meaning or mutability of `protective_action_cluster_id`;
- allowing shared identity to imply authority, jurisdiction, command, or liability;
- adding a residual “lead authority” field;
- treating receipt, technical ingestion, or silence as acceptance;
- removing partial acceptance or concurrent responsibility;
- weakening the 27-field header, access classes, protected non-transfer, notice, challenge, review, expiry, termination, remedy, or disposition;
- collapsing action routes or SCPA records;
- allowing an open Envelope to renew a power;
- treating CDEE linkage as authority;
- treating Aegis reversion as authorization;
- removing correction or immutable history; or
- weakening the non-authority statement.

Implementations fail closed when compatibility is unresolved. They may continue using the last tested compatible version where lawful while recording the unresolved substitution.

---

# Appendix A — Machine-readable files

- `cross-framework-protective-action-envelope-v0.1.schema.json` — normative JSON Schema, Draft 2020-12.
- `cross-framework-protective-action-envelope-v0.1-example.json` — illustrative, redacted compound survivor-protection, asylum, urgent-protection, Shield, Peace, Kintsugi, and Aegis-reversion envelope.
- `cross-framework-protective-action-envelope-v0.1-manifest.json` — source and artifact compatibility manifest.

The example is not an operational record and intentionally uses fictional authorities and protected references.

# Appendix B — Source manifest

This Specification was built against the exact local bytes below. A later or similarly titled document is not substituted automatically.

| Source ID | Filename | SHA-256 | Bytes | Lines | Role |
|---|---|---|---:|---:|---|
| `SCPA/0.1` | `security-coercion-protective-action-interface-specification-v0.1.md` | `b8f1dd0f676044542a23184f52200e50b106a798545c7c57119ded2c439b6299` | 127,876 | 1,452 | normative constitutional parent |
| `SCPA-RIC/0.1` | `scpa-record-inheritance-conformance-clause-v0.1.md` | `0c5d6083716969ee499afc5027a812f7153410babdd4a8e6f464270f8534c917` | 44,119 | 655 | normative record inheritance parent |
| `SCPA-HIT/0.1` | `security-coercion-cluster-harmonization-interface-test-v0.1.md` | `51f722add984d88be283a34f153d8e63e49e678c441d790620e44df1b6054d0f` | 32,098 | 312 | problem statement and test basis |
| `Shield/2.0` | `shield-protocol-v2.0.md` | `4fca33e9ab55574b3255fc36c0a5e81dedd5f2ef6db5f0df3f5887308fbc2b62` | 73,910 | 1,607 | cluster framework |
| `Kintsugi/2.2` | `kintsugi-protocol-v2.2.md` | `35f06e1449df25c5077c6b7c7b9d6c23f39c499df3d78007951778e91d96c973` | 63,734 | 1,250 | cluster framework |
| `Migration/1.1` | `migration-human-mobility-v1.1.md` | `caaf8181b8c519b8df7b87b2d53458b39ffaef6cb33899f7453a56780a8c326d` | 64,591 | 1,062 | cluster framework |
| `Peace/1.8` | `peace-conflict-resolution-framework-v1.8.md` | `66fbd6d7d89895e85dcdf7a9c1db9a37bec47557660dd7a08fd5dc75f48de98c` | 77,361 | 1,142 | cluster framework |
| `Aegis/1.3.3` | `aegis-protocol-v1.3.3.md` | `ca2391eca1a48c526ef63e3760a003e29bca94bf44814b6addd6723a0741788c` | 147,718 | 2,026 | cluster framework |
| `CDEE/0.1` | `emergency-cross-domain-event-envelope-v0.1.md` | `68ee2c48383199e4b91b365ea21e35d5a729f0a72854472acf6f8ae103f0c192` | 35,827 | 599 | related emergency-envelope precedent and optional interface |
| `ECRCI/0.1` | `emergency-catastrophic-risk-continuity-interface-specification-v0.1.md` | `c673742b1317c7169d4b8226118478c990e9a3d05084b2dc5ac9ad2f1971163c` | 81,100 | 2,136 | related emergency constitutional interface |
| `ECRC/0.1` | `emergency-cluster-record-profile-v0.1.md` | `19f35a53c151182ff6bf2760f7da67b9696fbf0048dfef27af9748de36b94dc9` | 82,601 | 1,334 | related emergency record profile |

# Appendix C — Compact field checklist

- [ ] `schema_version` and exact compatibility manifest;
- [ ] immutable `protective_action_cluster_id`;
- [ ] versioned `envelope_id`;
- [ ] exact non-authority statement;
- [ ] topology and local identifiers;
- [ ] registrar and bounded steward;
- [ ] exact framework versions and hashes;
- [ ] one entry per action route;
- [ ] authority, legal source, jurisdiction, exact act, and required SCPA records per route;
- [ ] prohibited transitions;
- [ ] function-level responsibility assignments;
- [ ] canonical handoff states and explicit acknowledgement;
- [ ] sender-retained duties;
- [ ] SCPA record bundle with inheritance relationships;
- [ ] protected information, evidence, asset, credential, software, and data custody;
- [ ] affected-person notice, counsel, interpretation, representation, challenge, and remedy;
- [ ] survivor, child, disability, migration, Indigenous, worker, source, and innocent-party safeguards;
- [ ] command, custody, force, equipment, cyber, and stop-work separation where applicable;
- [ ] independent review, expiry, termination, correction, remedy, and disposition clocks;
- [ ] public-information and correction owner;
- [ ] optional CDEE/ECRC links without authority merger;
- [ ] optional `SCPA-44` reversion links without authorization;
- [ ] route-specific closure;
- [ ] envelope closure verification; and
- [ ] immutable correction, split, merge, and supersession history.

# Appendix D — Interface sequence

```text
protected or ordinary intake
        │
        ▼
register protective_action_cluster_id ───► preserve local case, mission, event, and record IDs
        │
        ▼
classify every proposed act into separate SCPA routes
        │
        ▼
link exact authority, law, jurisdiction, safeguards, clocks, challenge, and remedy
        │
        ├────► voluntary service / care continuity
        │
        ├────► explicit handoff offer / deficiency / partial acceptance / acceptance / rejection
        │
        └────► concurrent responsibilities without shared command
        │
        ▼
track protected material, evidence, assets, credentials, software, data, and custody
        │
        ▼
track notice, counsel, affected-person access, review, expiry, and public correction
        │
        ├────► optional CDEE event link; emergency authority remains separate
        │
        └────► optional Aegis reversion; security authorization remains separate
        │
        ▼
terminate each power independently
        │
        ▼
return authority, persons, property, assets, credentials; dispose data; complete correction and remedy
        │
        ▼
close routes, then verify envelope closure or retain unresolved risk without residual power
```

# Appendix E — Responsibility-state reference

| Responsibility state | Meaning | Authority effect |
|---|---|---|
| `unassigned` | No competent function has accepted the responsibility. | None; consequential action fails closed. |
| `offered` | Sender requested recipient assessment. | None. |
| `assessing` | Recipient is reviewing competence, authority, scope, and safeguards. | None. |
| `partially_accepted` | Recipient accepted only named functions or material. | Only the independently authorized accepted scope. |
| `accepted` | Recipient acknowledged the named function and duties. | No more than the recipient’s independent authority. |
| `concurrent` | Distinct bodies hold distinct or overlapping duties. | No joint command or pooled power. |
| `declined` | Recipient rejected the function or lacks authority. | None; sender duties survive. |
| `suspended` | Responsibility is temporarily paused under law or safety rule. | No continued action beyond valid residual duties. |
| `returned` | Responsibility or material returned to sender or lawful custodian. | No residual recipient authority. |
| `closed` | Function and surviving duties are complete or lawfully reassigned. | None. |

# Appendix F — Closing principle

> **One compound action identity; separate lawful routes; explicit acceptance; protected custody; independent clocks; complete remedy; no residual power.**

# Peace–Kintsugi–Shield Protected Referral and Urgent Protection Addendum v0.1

## Protected disclosures, person-led process choice, minimum-necessary referral, independent urgent authority, care continuity, and complete remedy

**Document Type:** Security-and-coercion cluster three-framework harmonization addendum  
**Status:** Normative interoperability specification — draft for implementation testing  
**Version:** 0.1  
**Date:** August 2026  
**Profile Identifier:** `PKS-PRUP/0.1`  
**Authority Effect:** None

---

## Executive rule

> **A peacebuilder, mediator, Safety Weaver, survivor advocate, sanctuary worker, or Shield coordinator may recognize danger, support choice, protect confidentiality, offer a referral, and preserve care. None may create urgent-protection, investigation, search, custody, force, intelligence, or enforcement authority merely because the danger is grave or a voluntary process has failed.**

> **Protected disclosure is not intelligence. Referral is not acceptance. Acceptance is not authority. `SCPA-18` is not investigation, custody, or force. Care does not depend on cooperation.**

This Addendum coordinates **Peace and Conflict Resolution Framework v1.8**, **Kintsugi Protocol v2.2**, and **Shield Protocol v2.0** through SCPA v0.1, the SCPA Record Inheritance and Conformance Clause v0.1, and the Cross-Framework Protective Action Envelope v0.1.

It creates no offence, intelligence power, investigation, compulsory disclosure, entry, search, seizure, arrest, detention, force, weapons, border, migration, sanctions, prosecution, adjudication, emergency, or armed-protection authority.

> **No valid authority record, no consequential security or coercive action.**

---

# 1. Purpose

The Addendum provides a common operational grammar for situations in which confidential peacebuilding or community-care information indicates a possible need for urgent protection, including:

- a participant in mediation, dialogue, ceasefire support, reconciliation, restorative work, sanctuary, accompaniment, or survivor support reports a specific threat;
- intimate-partner violence, stalking, coercive control, trafficking, organized exploitation, abduction risk, retaliatory violence, or credible threats cross local or national boundaries;
- a child or dependent person may face imminent grave harm;
- a person wants safety planning or shelter but does not want police contact or investigation;
- a Peace or Kintsugi worker is subject to a narrow mandatory-reporting or immediate-danger exception;
- Shield may provide victim protection or cross-border coordination without opening or commanding an investigation;
- an external competent authority may need to consider a temporary `SCPA-18` urgent protective action;
- the same facts could later support investigation, compulsory process, evidence use, custody, or adjudication, each requiring its own route; or
- an emergency event also exists and must be linked through CDEE/ESDIB without merging authority.

The purpose is not to turn Peace into intelligence, Kintsugi into police, Shield into a universal urgent-response service, or a support referral into a coercive pathway. It is to preserve confidential and person-led care while making the narrow transition to separately lawful protection explicit and reviewable.

# 2. Controlling instruments and exact versions

This Addendum is compatible only with the following exact instruments:

| Instrument | Version | File | SHA-256 |
|---|---:|---|---|
| Peace and Conflict Resolution Framework | 1.8 | `peace-conflict-resolution-framework-v1.8.md` | `66fbd6d7d89895e85dcdf7a9c1db9a37bec47557660dd7a08fd5dc75f48de98c` |
| Kintsugi Protocol | 2.2 | `kintsugi-protocol-v2.2.md` | `35f06e1449df25c5077c6b7c7b9d6c23f39c499df3d78007951778e91d96c973` |
| Shield Protocol | 2.0 | `shield-protocol-v2.0.md` | `4fca33e9ab55574b3255fc36c0a5e81dedd5f2ef6db5f0df3f5887308fbc2b62` |
| Security, Coercion, and Protective Action Interface Specification | 0.1 | `security-coercion-protective-action-interface-specification-v0.1.md` | `b8f1dd0f676044542a23184f52200e50b106a798545c7c57119ded2c439b6299` |
| SCPA Record Inheritance and Conformance Clause | 0.1 | `scpa-record-inheritance-conformance-clause-v0.1.md` | `0c5d6083716969ee499afc5027a812f7153410babdd4a8e6f464270f8534c917` |
| Cross-Framework Protective Action Envelope | 0.1 | `cross-framework-protective-action-envelope-v0.1.md` | `c1d591c665dfd3b9c9f30dd61943a38556905c6f1a2128a64220e054149dfb05` |
| Emergency–Security Dual-Interface Bridge | 0.1 | `emergency-security-dual-interface-bridge-v0.1.md` | `6332dba2fe2d01347f5c2432a1af002e0902aa8bba80c7b533bd50ee89cebf30` |
| Security-and-Coercion Cluster Harmonization Interface Test | 0.1 | `security-coercion-cluster-harmonization-interface-test-v0.1.md` | `51f722add984d88be283a34f153d8e63e49e678c441d790620e44df1b6054d0f` |

Later versions are not substituted automatically. A material change to confidentiality, survivor sovereignty, urgent-protection authority, investigation, source handling, custody, force, review, remedy, data disposition, or institutional responsibility fails closed until compatibility is tested and recorded.

# 3. Non-authority and non-merger clause

This Addendum does not:

- define immediate danger, abuse, trafficking, organized crime, criminal liability, child-protection grounds, mental incapacity, dangerousness, or another legal category;
- authorize a Peace or Kintsugi body to activate police, security, intelligence, detention, force, search, or investigation;
- authorize Shield to determine protection need, compel disclosure, command local responders, or turn a victim-protection request into a criminal operation;
- convert mediation impasse, restorative-process failure, withdrawal, refusal, silence, distress, spiritual disclosure, trauma response, cultural conflict, or community concern into an adverse security inference;
- make a protected Peace or Kintsugi record intelligence or evidence merely because it is transmitted, authenticated, summarized, or placed in a CFPAE envelope;
- permit a support provider to recruit sources, collect evidence covertly, preserve a scene, search a device, restrain a person, guard transport, or block exit without separate authority;
- make an urgent referral binding on a recipient;
- permit a recipient to collect more information than the accepted function requires;
- create shared command, pooled custody, merged databases, universal case files, or residual jurisdiction; or
- allow urgency, benevolent purpose, safeguarding language, donor requirements, organizational policy, or a supermajority vote to replace law.

# 4. Relationship to SCPA, RIC, CFPAE, and ESDIB

Every implementation shall conform to SCPA v0.1 and `SCPA-RIC/0.1`. Each materially distinct act retains its canonical SCPA identity, full common header, authority, jurisdiction, access class, review and expiry clocks, challenge, termination, correction, remedy, and data-disposition duties.

Where more than one framework or authority is engaged, the case shall use a conformant CFPAE `protective_action_cluster_id`. This Addendum creates a linked **Protected Referral and Urgent Protection Packet** (`PRUP Packet`), not a replacement Envelope and not `SCPA-45`.

Where an emergency also exists, ESDIB v0.1 and the applicable CDEE/ECRC records remain separate. Emergency urgency may explain timing or context; it cannot satisfy an SCPA authority requirement, prolong a protective action, or suspend confidentiality, custody review, challenge, remedy, or data disposition.

# 5. Stable identity and packet topology

Each Packet shall contain:

- `prup_coordination_id` — stable three-framework identifier;
- `protective_action_cluster_id` — CFPAE identity;
- optional CDEE `cluster_event_id` and ESDIB bridge identifier;
- local Peace process, Kintsugi service, Shield support, urgent-authority, and investigation identifiers;
- linked canonical SCPA record instances;
- affected-person protected references;
- referral decisions and handoff states;
- function responsibility, custody, access, review, correction, remedy, and closure indices.

The Packet identifier shall not encode a person’s name, diagnosis, allegation, immigration status, religion, political identity, protected location, or outcome.

# 6. Functional roles and prohibited conversion

## 6.1 Peace functions

Peace may, within a valid voluntary mandate:

- receive a disclosure;
- clarify immediate safety concerns without conducting an interrogation;
- support process choice, safe communication, and separate-track design;
- offer a consultation-only, protected-support, or urgent-protection referral;
- retain or close the peace process independently of other routes; and
- correct information it originated.

Peace may not investigate, recruit a source, collect evidence covertly, test credibility for law enforcement, direct surveillance, nominate a target, command protection personnel, or use mediation failure as a security predicate.

## 6.2 Kintsugi functions

Kintsugi may:

- provide unarmed de-escalation, sanctuary, accompaniment, survivor advocacy, accessibility, material support, and safety planning;
- help the person understand options and communicate choices;
- continue care after a referral is declined, withdrawn, rejected, or separated from an investigation; and
- document service, safety, confidentiality, and remedy duties.

Kintsugi may not create or activate arrest, search, restraint, custody, force, weapons, investigation, prosecution, or tribunal authority. Crisis Sanctuary, accompaniment, transport, or separation remains voluntary unless a separately competent authority lawfully creates another status.

## 6.3 Shield functions

Shield may:

- coordinate victim, witness, source, and whistleblower protection;
- route a lawful cooperation request;
- help identify cross-border protection partners;
- preserve bounded information and source restrictions;
- support safe relocation by consent; and
- correct or withdraw information it originated.

Shield may not become a global police, intelligence, border, detention, force, sanctions, or command authority by accepting a PRUP Packet.

## 6.4 External competent authorities

Urgent protection, investigation, compulsory process, custody, force, adjudication, and other consequential acts remain with authorities separately constituted under applicable law. The Packet records their acceptance and SCPA records; it does not constitute them.

# 7. Four referral outcomes

Every concern shall support at least four possible outcomes:

| Outcome | Meaning | Permitted transfer | Prohibited inference |
|---|---|---|---|
| `consultation_only` | Originator seeks expert advice without transferring operational responsibility or identifying information unless necessary and lawful. | Abstracted or minimized facts; protected consultation record. | That the consulted body has accepted a case or may contact the person. |
| `protected_support_referral` | The person chooses a care, shelter, advocacy, accompaniment, or victim-protection service. | Minimum service and safe-contact information. | That the person consents to police, investigation, testimony, data matching, or surveillance. |
| `urgent_protective_referral` | Specific individualized facts may satisfy a separate authority’s `SCPA-18` threshold. | Minimum facts necessary to assess and, if accepted, perform the exact temporary protective act. | That the referral itself authorizes action or establishes search, custody, force, or investigation. |
| `no_referral` | The person declines, facts are insufficient, disclosure is unlawful, or support can continue without transfer. | Internal safety and service records only. | That no referral means no danger, no credibility, no future support, or institutional closure. |

A narrowly applicable mandatory-reporting or court-order route shall be documented under PKS-12. It does not create a fifth broad outcome or permit disclosure beyond the exact lawful requirement.

# 8. Immediate-danger threshold and assessment

## 8.1 Specificity and proximity

An urgent referral should identify specific, individualized, and temporally relevant facts suggesting a grave risk such as death, serious bodily injury, abduction, trafficking control, retaliatory violence, disappearance, or comparable harm. The record shall distinguish:

- direct observation;
- the affected person’s report;
- third-party report;
- corroborated fact;
- analytical inference;
- uncertainty and alternative explanations;
- timing and foreseeable window of harm;
- persons, locations, communications, or assets needing protection.

## 8.2 No certainty requirement and no adverse inference

The originator need not prove criminal liability before offering urgent protection. Equally, a concern does not prove guilt, identity, dangerousness, credibility, or a need for search, restraint, detention, force, weapons, or investigation.

## 8.3 Least-disclosive assessment

The originator should first consider whether the risk can be reduced through voluntary safety planning, change of contact, accessible shelter, accompaniment, transport chosen by the person, child/dependent safeguards, schedule change, digital safety, or another non-coercive measure. This does not require delaying a lawful urgent referral when delay would create grave imminent risk.

# 9. Consent, process choice, and disclosure exceptions

## 9.1 Person-led choice

Where legally and practically possible, the affected person chooses whether to:

- receive information only;
- remain in the Peace or Kintsugi process;
- use a Crisis Sanctuary or other service;
- authorize a protected support referral;
- authorize an urgent protective referral;
- permit contact by Shield or an external authority;
- accept safe relocation or accompaniment;
- speak with an investigator;
- provide evidence or testimony; or
- withdraw from any voluntary route.

Consent shall be informed, specific, understandable, accessible, and revisable. Consent to protection does not imply consent to investigation, evidence use, publicity, biometric processing, device access, location tracking, or immigration action.

## 9.2 Coercive control and power imbalance

Choice shall be assessed in light of threats, detention, dependency, housing, income, immigration status, disability, child custody, organizational hierarchy, armed presence, and fear of retaliation. An apparent agreement obtained through coercive control is not treated as voluntary.

## 9.3 Disclosure without full consent

A disclosure without full consent requires PKS-12 and an exact legal basis, threshold, competent decision-maker, scope, necessity, notice or reason for delayed notice, review, challenge, and remedy. General safeguarding policy, professional anxiety, donor rules, reputational risk, or a broad claim of public interest is insufficient.

# 10. Minimum-necessary referral package

PKS-11 shall identify:

- the requested function and exact act;
- the recipient authority or service;
- the facts necessary for that function;
- the source type and reliability limits;
- what protected material is withheld;
- consent state or legal exception;
- safe contact and location restrictions;
- child, disability, medical, language, and cultural safeguards;
- urgency and expiry;
- prohibited uses and onward transfer;
- retained sender duties;
- correction and withdrawal route;
- expected receipt and decision time.

The complete mediation file, survivor narrative, therapeutic notes, spiritual disclosures, restorative communications, service history, or family network shall not be transferred merely because they may be relevant in a broad sense.

# 11. Handoff and recipient acceptance

A referral shall use the canonical handoff states:

`offered`, `received_not_assessed`, `deficient`, `partially_accepted`, `accepted`, `concurrent_responsibility`, `rejected`, `withdrawn`, `returned`, or `closed`.

Receipt is not acceptance. Silence is never acceptance. Technical ingestion is not legal acceptance. The recipient shall record:

- the function accepted;
- material accepted and rejected;
- authority and jurisdiction;
- action class;
- deficiencies and requested clarification;
- protected handling and onward-use limits;
- independent review and expiry;
- sender duties that remain;
- person notice and challenge;
- closure and return conditions.

Partial acceptance shall not enlarge the accepted scope. The sender continues care, confidentiality, correction, and other duties unless a valid accepted record expressly reallocates a named duty.

# 12. Independent urgent protective action

A recipient may act urgently only through a separately valid `SCPA-18` record. PKS-14 shall identify:

- competent authority and legal source;
- jurisdiction;
- individualized facts;
- exact temporary act;
- alternatives considered;
- necessity and proportionality;
- affected persons and protected statuses;
- notice or reason for delayed notice;
- duration and automatic expiry;
- prompt independent review;
- command and worker safety;
- termination and remedy.

`SCPA-18` may support a temporary separation, rescue, evacuation, protective shelter offer, emergency network isolation on controlled systems, or another action within valid law. It does not authorize investigation, search, arrest, detention, force, weapons, sanctions, border action, or continuing supervision.

# 13. Entry, search, evidence, custody, and force firewalls

## 13.1 Compulsory process

Entry, search, inspection, copying, preservation, disclosure, interception, seizure, or asset restraint requires the applicable `SCPA-13` through `SCPA-17` record. Consent shall be specific and free; consent to support or entry for care does not authorize evidence collection or unrelated inspection.

## 13.2 Investigation

A referral does not open an investigation. A competent authority must create `SCPA-11` and `SCPA-12`, identify the legal issue or offence, jurisdiction, scope, methods, minimization, care firewall, protected material, review, and closure.

## 13.3 Custody and force

Blocking exit, coercive transport, guarded custody, physical restraint, chemical restraint, confiscating mobility aids, force, weapons, or special equipment requires the applicable `SCPA-19` through `SCPA-24` records. Labels such as protective, wellness, safe house, accompaniment, escort, reception, stabilization, or emergency do not change the legal character of the act.

## 13.4 Command

PKS-17 shall separate mission command, clinical or safeguarding judgment, technical control, information custody, property control, and worker supervision. Peace, Kintsugi, or Shield coordination does not create unified command.

# 14. Care continuity and non-retaliation

Kintsugi care and Peace support shall not be reduced because a person:

- declines or withdraws a referral;
- refuses police or Shield contact;
- declines an interview, testimony, confrontation, mediation, restorative process, or relocation;
- questions the risk assessment;
- requests correction or access;
- leaves a Sanctuary or support programme; or
- pursues an independent legal or complaint route.

Continued support may change only for a legitimate service reason independently documented, with safe transition and appeal where applicable. The person shall not be threatened with withdrawal of shelter, healthcare, income, immigration assistance, family contact, or community standing to obtain cooperation.

# 15. Protected Peace, Kintsugi, and source information

Protected classes include:

- mediation and caucus communications;
- ceasefire, good-offices, and negotiation material;
- survivor narratives and process choices;
- restorative and accountability communications;
- child and dependent-person information;
- medical, mental-health, disability, and accessibility information;
- spiritual, religious, and Indigenous-restricted disclosures;
- safe locations and contact methods;
- source, witness, worker, and family-risk information;
- legal privilege and protected advice.

Technical receipt does not authorize use. Access class does not establish truth or admissibility. A recipient shall not infer permission for investigation, intelligence, prosecution, immigration action, public release, training data, profiling, or unrelated safeguarding from the existence of a packet.

# 16. Shield protection without investigation

Shield may accept victim, witness, source, or cross-border safety coordination while rejecting or deferring investigation. The accepted scope may include:

- protected contact among competent services;
- safe relocation options chosen by the person;
- cross-border service continuity;
- warning a competent authority of a bounded danger;
- source and witness risk mitigation;
- correction and withdrawal propagation;
- secure transfer of lawfully accepted material.

Shield acceptance does not create police, intelligence, detention, border, extradition, sanctions, or force authority. A request to investigate, compel, seize, arrest, detain, transfer, or sanction follows a separate SCPA route.

# 17. Children and dependent persons

A child or dependent-person case shall provide:

- independent representation or advocacy;
- best-interests assessment with stated uncertainty;
- evolving capacity and supported decision-making;
- accessible communication;
- family and caregiver risk assessment;
- protection from retaliation and exploitation;
- education, health, disability, and cultural continuity;
- prompt review of any separation or placement;
- complaint, access, correction, and remedy.

A safeguarding referral does not automatically establish family separation, institutional placement, detention, criminal culpability, or disclosure of the complete family or peace-process file.

# 18. Cross-border, migration, and emergency interfaces

Where protection may affect asylum, identity, reception, detention, extradition, deportation, return, or non-refoulement, Migration v1.1 and any applicable Shield–Migration addendum govern those consequences. This Addendum cannot supply migration or border authority.

Where an emergency exists, ESDIB links emergency and security records while preserving separate authorities and clocks. A CDEE event or emergency declaration does not activate the urgent, investigative, custody, or force route in this Packet.

# 19. Technology, communications, and automated systems

Digital systems may support secure communication, access logging, translation, scheduling, record completeness, and deadline alerts. They shall not determine:

- credibility or truth;
- dangerousness or imminence;
- consent or capacity;
- whether to disclose protected material;
- whether `SCPA-18` is legally satisfied;
- whether investigation, custody, force, or child separation should occur;
- whether a person is entitled to care or remedy.

No facial, emotion, voice-stress, behavioural, social-network, spiritual, developmental, or predictive-policing system may be used as a coercive predicate. Offline and low-tech routes shall remain available.

# 20. Notice, access, challenge, and protected substitutes

The affected person shall receive, in accessible form where lawful:

- the existence and purpose of the Packet;
- functions engaged and excluded;
- material offered and accepted in understandable substance;
- authority, jurisdiction, action class, duration, and review;
- confidentiality limits and delayed-notice reasons;
- access, correction, advocate/counsel, complaint, and remedy routes.

Where direct disclosure would create a specific grave risk, an independent body shall review the limitation and provide an effective substitute, such as a gist, protected advocate, special counsel, redacted record, or equivalent challenge mechanism. Secret general powers and unreviewable secret evidence are non-conforming.

# 21. Review clocks, expiry, and renewal

Each referral, disclosure, urgent action, investigation, custody, secrecy limitation, data use, and protection arrangement retains its own clock. An open Peace process, Kintsugi care relationship, Shield protection file, investigation, emergency, or CFPAE Envelope does not renew another act.

Where one act depends on more than one valid basis, the earlier expiry controls. Renewal requires the competent authority, updated facts, necessity, proportionality, alternatives, affected-person safeguards, and independent review. Administrative delay cannot preserve an expired restriction.

# 22. Correction, withdrawal, and downstream repair

A source or originator may qualify, correct, or withdraw information. Each recipient shall:

- acknowledge the update;
- stop prohibited or expired use;
- correct operational and analytical records;
- identify derivative decisions, watchlists, alerts, referrals, or publications;
- notify affected persons where lawful;
- reopen or stay decisions materially affected;
- preserve a protected audit trail without preserving operational use;
- record completion and remedy.

A correction does not disappear merely because an investigation, peace process, or protection route remains open.

# 23. Complaints, remedy, and institutional accountability

Independent routes shall address:

- coerced or misleading consent;
- unauthorized disclosure or use;
- retaliation;
- denial or conditioning of care;
- failure to act on an accepted urgent duty;
- wrongful entry, search, restraint, custody, force, or investigation;
- inaccessible process;
- failure to correct or close;
- worker retaliation;
- institutional circumvention.

Available outcomes may include immediate safety measures, service restoration, correction, deletion or sealing, return of property, apology where appropriate, restitution, compensation, discipline referral, suspension of an interface, public findings, and systemic reform. Restorative dialogue may supplement but cannot replace enforceable remedy.

# 24. Worker rights and role integrity

Workers may refuse tasks outside their authority, training, safety envelope, or ethical duties without retaliation. Implementations shall protect pay, benefits, housing, immigration status, professional standing, whistleblowing, counselling, legal support, and substitute staffing.

A worker shall not be required to:

- disclose a complete protected file when a narrower record is lawful;
- enter an armed or otherwise unsafe scene without appropriate authority and protection;
- perform custody, force, intelligence, investigation, or evidence work under a care title;
- misrepresent a protective action as voluntary;
- conceal a breach or wrongful act.

# 25. Termination, authority return, data disposition, and closure

Operational completion is not legal closure. The Packet may become `closed` only after:

- all handoffs are accepted, rejected, returned, withdrawn, or closed;
- every consequential act has terminated or detached to an independently lawful route;
- credentials, command, custody, property, and access are returned or lawfully reassigned;
- care and service continuity are secured;
- affected-person notice, access, and correction are complete or lawfully deferred;
- complaints, remedy, restitution, and compensation are resolved or assigned to an accepted continuing record;
- data are deleted, returned, sealed, archived, or retained under a stated lawful basis;
- unresolved risk is recorded without residual power.

Reopening coordination does not reactivate expired urgent protection, investigation, compulsory process, custody, force, secrecy, or data-use authority.

# 26. Canonical PRUP records

| Record | Title | Trigger | Function | Prohibited inference | Default access | Lead function |
|---|---|---|---|---|---|---|
| `PKS-01` | Profile, compatibility, and authority-effect record | package creation or version change | Records exact instruments, hashes, profile, authority effect, and fail-closed compatibility state. | That compatibility creates jurisdiction or approves a consequential act. | SCPA-PUBLIC | Joint conformance function |
| `PKS-02` | Protective-action cluster and local-case identity record | first cross-framework engagement | Links CFPAE identity, local Peace/Kintsugi/Shield references, optional CDEE/ESDIB identity, and affected-person protected reference. | That shared identity creates shared command, custody, purpose, or data access. | SCPA-REVIEW | Envelope administrator |
| `PKS-03` | Function, role, and non-conversion record | each participating function | Defines each function, legal basis, accepted scope, excluded scope, and prohibited role conversion. | That a mediator, Weaver, advocate, Secretariat, or support worker becomes investigator, police, intelligence, or adjudicator. | SCPA-PUBLIC | Each constituting authority |
| `PKS-04` | Protected source and confidentiality intake record | receipt of mediation, care, survivor, spiritual, child, medical, or source-sensitive information | Records origin, confidentiality promise and limits, purpose, source risk, reliability limits, and prohibited uses. | That protected receipt establishes truth, admissibility, investigation authority, or permission for onward transfer. | SCPA-PROTECTED | Originating Peace or Kintsugi function |
| `PKS-05` | Immediate-danger concern record | specific concern of imminent death, serious bodily harm, abduction, trafficking control, or comparable grave harm | Separates observed facts, reported facts, inference, uncertainty, timing, affected persons, and foreseeable harm. | That concern proves guilt, dangerousness, identity, or need for custody, force, search, or investigation. | SCPA-PROTECTED | Originating support function |
| `PKS-06` | Person-led process choice and consent record | before voluntary support or referral where consent is possible | Records choices among consultation only, support referral, urgent referral, no referral, safe contact, advocacy, and investigation contact. | That consent to protection is consent to investigation, testimony, evidence transfer, publicity, or immigration action. | SCPA-AFFECTED | Independent advocate or authorized support worker |
| `PKS-07` | Child, dependent-person, and capacity safeguard record | affected child, dependent adult, impaired communication, or contested capacity | Records best interests, evolving capacity, independent representation, communication support, family and placement risk, and lawful safeguarding duties. | That child status permits automatic family separation, detention, disclosure, or substitution of institutional preference for the person’s rights. | SCPA-PROTECTED | Competent child/dependent safeguard authority |
| `PKS-08` | Accessibility, interpretation, and safe-communication record | communication, sensory, cognitive, language, disability, or technology need | Specifies interpretation, supported decision-making, non-digital route, safe device/contact method, and communication risk. | That silence, distress, non-standard communication, or inability to use a platform equals refusal, consent, unreliability, or dangerousness. | SCPA-AFFECTED | Service provider |
| `PKS-09` | Safety plan, protected location, and contact protocol | protective support or relocation planning | Defines safe contacts, location handling, schedule, dependants, medication, mobility aids, digital safety, transport, and contingency actions. | That a safety plan authorizes surveillance, tracking, guarded custody, restriction of movement, or covert collection. | SCPA-PROTECTED | Kintsugi advocate or competent protection provider |
| `PKS-10` | Care and peace-support continuity record | referral, refusal, withdrawal, investigation decision, or authority transition | Protects continued shelter, healthcare, accompaniment, mediation choice, legal aid, income, accessibility, and family contact. | That support may be conditioned on reporting, cooperation, testimony, prosecution, reconciliation, or compliance with a preferred safety pathway. | SCPA-AFFECTED | Kintsugi and Peace service leads |
| `PKS-11` | Minimum-necessary referral offer record | originator proposes transfer to another function | Lists exact facts offered, withheld protected material, purpose, recipient, requested function, consent or legal exception, expiry, and onward restrictions. | That an offer activates the recipient, transfers responsibility, or authorizes collection of the complete mediation or care file. | SCPA-PROTECTED | Originator |
| `PKS-12` | Disclosure exception and legal-basis record | disclosure without full consent, mandatory reporting, court order, or immediate-danger exception | Identifies exact law, threshold, competent decision-maker, necessity, scope, advance notice or reason for delay, and challenge. | That organizational policy, donor condition, safeguarding rhetoric, or general public interest creates disclosure authority. | SCPA-REVIEW | Competent disclosure decision-maker |
| `PKS-13` | Recipient receipt, deficiency, and acceptance record | recipient receives a referral | Uses canonical handoff states, identifies accepted function and material, deficiencies, rejected scope, retained sender duties, and response time. | That receipt, technical ingestion, acknowledgement, or silence equals acceptance or authority. | SCPA-REVIEW | Recipient authority |
| `PKS-14` | Urgent protective action record | recipient proposes immediate temporary protection | Implements SCPA-18 with individualized facts, exact act, least-restrictive alternatives, authority, jurisdiction, duration, notice, prompt review, stop conditions, and remedy. | That urgency authorizes investigation, entry, search, arrest, detention, force, weapons, border action, or continuing supervision. | SCPA-REVIEW | Separately competent urgent-protection authority |
| `PKS-15` | Entry, search, disclosure, and preservation separation record | protective response may involve premises, devices, records, communications, or evidence | Identifies whether SCPA-13 through SCPA-17 is required and blocks the act until separately authorized. | That safety, rescue, consent to shelter, or SCPA-18 supplies compulsory-process authority. | SCPA-REVIEW | Competent judicial or compulsory-process authority |
| `PKS-16` | Restraint, custody, transport, and force boundary record | movement is blocked, transport is guarded, physical control is proposed, or force is used | Classifies confinement and force honestly and links SCPA-19 through SCPA-24 as applicable. | That “protective,” “wellness,” “safe house,” “reception,” “escort,” or “stabilization” labels remove custody and force safeguards. | SCPA-REVIEW | Competent custody/force authority |
| `PKS-17` | Mission command, technical command, custody, and stop-work record | multi-function or multi-agency protective operation | Separates host command, technical control, clinical authority, information custody, worker supervision, safe refusal, and stop-work. | That coordination, co-location, funding, equipment support, or urgency creates unified command. | SCPA-OPERATIONAL | Host competent authority |
| `PKS-18` | Investigation opening and referral firewall record | facts may justify criminal or other investigation | Requires an independent SCPA-11 opening decision, scope, offence/legal issue, jurisdiction, and separation from Peace/Kintsugi support. | That mediation impasse, support referral, victim status, allegation, or protective action automatically opens an investigation. | SCPA-REVIEW | Competent investigative authority |
| `PKS-19` | Evidence acquisition, custody, and admissibility separation record | material may be offered for evidentiary use | Records voluntary or compulsory basis, chain of custody, transformations, exculpatory context, confidentiality limits, disclosure, challenge, and return. | That a protected statement, safety note, authenticated file, or referral summary is automatically evidence or admissible. | SCPA-PROTECTED | Competent evidence custodian |
| `PKS-20` | Shield victim protection and cross-border coordination record | transnational threat, relocation, witness, trafficking, organized exploitation, or cross-border safety need | Defines Shield’s accepted non-coercive support, jurisdictional partners, protected contact, service continuity, and excluded investigative or enforcement acts. | That Shield coordination creates police, border, intelligence, detention, extradition, sanctions, or command authority. | SCPA-PROTECTED | Shield victim-protection function |
| `PKS-21` | Retaliation, source, witness, and participant protection record | credible risk from disclosure, participation, refusal, testimony, or withdrawal | Records retaliation vectors, source exposure, safe contact, employment/housing/immigration risks, dependants, and mitigation. | That protection requires secrecy from the affected person, confinement, compelled relocation, or cooperation. | SCPA-PROTECTED | Protection provider |
| `PKS-22` | Confidentiality breach and unauthorized-use incident record | misdelivery, over-disclosure, repurposing, leak, access violation, or retaliation | Records scope, affected systems/persons, containment, notice, correction, deletion, safety response, accountability, and compensation route. | That a breach may be hidden to protect institutional reputation or an ongoing process. | SCPA-REVIEW | Independent incident reviewer |
| `PKS-23` | Notice, access, explanation, and challenge record | consequential use, delayed notice, protected limitation, or person request | Provides understandable notice, accessible access, lawful redaction, protected substitute, counsel/advocacy, answer rights, review, and appeal. | That confidentiality or security labeling eliminates effective challenge or affected-person access. | SCPA-AFFECTED | Competent review authority |
| `PKS-24` | Independent review, expiry, and renewal record | each time-limited referral, protection, restriction, data use, or secrecy measure | Maintains separate clocks, reviewer, renewal threshold, evidence update, earlier-expiry rule, and automatic stop. | That an open peace process, care relationship, investigation, threat, or CFPAE envelope renews another power. | SCPA-REVIEW | Independent reviewer |
| `PKS-25` | Correction, qualification, withdrawal, and downstream propagation record | fact changes, source retracts, identity error, overstatement, changed risk, or unlawful use | Records correction, confidence change, withdrawal, recipients, derivative decisions, watchlists, notices, and completion proof. | That preserving a historical audit trail permits continued operational use of corrected or withdrawn material. | SCPA-REVIEW | Originator plus each recipient |
| `PKS-26` | Complaint, remedy, restitution, and compensation record | alleged coercion, disclosure, retaliation, denial of care, wrongful action, or procedural failure | Provides independent complaint, interim protection, restoration, correction, apology where appropriate, restitution, compensation, discipline referral, and systemic remedy. | That internal learning, restorative dialogue, or service improvement substitutes for enforceable remedy. | SCPA-AFFECTED | Independent remedy body |
| `PKS-27` | Worker safety, role integrity, refusal, and anti-retaliation record | worker asked to exceed role, disclose improperly, enter danger, or support coercive action | Protects safe refusal, pay, benefits, professional status, immigration status, whistleblowing, supervision, and substitute staffing. | That mission urgency, survivor need, professional duty, or contract waives worker rights or role boundaries. | SCPA-REVIEW | Employer and independent labour safeguard |
| `PKS-28` | Termination, authority return, and service handback record | route or operation ends, expires, is rejected, or transfers | Records termination, credential/authority return, command end, property and access handback, continuing care, unresolved duties, and public correction. | That operational completion closes legal authority or ends care obligations. | SCPA-REVIEW | Each authority and envelope administrator |
| `PKS-29` | Data disposition, archive, and closure record | purpose ends, record expires, request closes, or programme dissolves | Specifies retention, deletion, sealing, protected archive, return, access revocation, machine-learning exclusion, and closure evidence. | That archive equals indefinite use permission or that one framework may retain another’s complete file for convenience. | SCPA-REVIEW | Data fiduciary and independent reviewer |
| `PKS-30` | Unresolved risk without residual power record | risk remains after powers, routes, or services expire | Records remaining risk, non-coercive monitoring options, renewed-support offer, ordinary-law routes, and prohibited residual actions. | That unresolved danger preserves surveillance, custody, secrecy, restrictions, investigation, command, or any expired authority. | SCPA-REVIEW | Envelope administrator and affected functions |

# 27. Complete SCPA inheritance crosswalk

| Canonical record | Relationship | PRUP record(s) | Conformance note |
|---|---|---|---|
| `SCPA-01` | imports | PKS-01; PKS-03 | Authority provenance remains with each separately competent actor. |
| `SCPA-02` | extends | PKS-02; PKS-03 | Jurisdiction and identity are linked without shared jurisdiction. |
| `SCPA-03` | extends | PKS-03; PKS-14; PKS-18 | Action class and exact act are stated for referral, protection, and investigation. |
| `SCPA-04` | extends | PKS-05; PKS-14; PKS-18 | Individualized facts remain distinct from protected narratives and inference. |
| `SCPA-05` | extends | PKS-04; PKS-05 | Prohibited inference is recorded at intake and danger assessment. |
| `SCPA-06` | contains | PKS-07; PKS-08; PKS-10; PKS-21 | Rights and protected-status safeguards remain explicit. |
| `SCPA-07` | contains | PKS-24; PKS-28 | Review, expiry, termination, and authority return remain separate. |
| `SCPA-08` | extends | PKS-23 | Notice and challenge are adapted for protected support information. |
| `SCPA-09` | extends | PKS-04; PKS-11; PKS-21 | Protected information intake and source protection. |
| `SCPA-10` | extends | PKS-04; PKS-05; PKS-25 | Reliability, dissemination, correction, and use limits. |
| `SCPA-11` | imports | PKS-18 | Investigation requires an independent opening record. |
| `SCPA-12` | extends | PKS-18 | Method, scope, minimization, and care firewall. |
| `SCPA-13` | imports | PKS-15 | Entry or search remains separately authorized. |
| `SCPA-14` | imports | PKS-15 | Inspection and copying remain separate compulsory acts. |
| `SCPA-15` | imports | PKS-15 | Disclosure, production, preservation, or interception requires separate authority. |
| `SCPA-16` | extends | PKS-19 | Evidence seizure/custody retains source and survivor protections. |
| `SCPA-17` | imports | PKS-15; PKS-19 | Asset restraint is outside ordinary mandate and cannot arise from referral. |
| `SCPA-18` | extends | PKS-05; PKS-14 | Urgent protection is individualized and least restrictive. |
| `SCPA-19` | imports | PKS-16 | Arrest or physical restraint cannot be implied by SCPA-18. |
| `SCPA-20` | imports | PKS-16 | Custody/detention remains separate and honestly classified. |
| `SCPA-21` | contains | PKS-10; PKS-16 | Release and less-restrictive alternatives protect care continuity. |
| `SCPA-22` | imports | PKS-16; PKS-20 | Transfer/removal is outside the referral and support mandate. |
| `SCPA-23` | imports | PKS-16 | Force requires a separate incident and necessity record. |
| `SCPA-24` | imports | PKS-16 | Weapons, restraints, and special equipment require separate authority. |
| `SCPA-25` | extends | PKS-17; PKS-27 | Command, custody, technical control, and stop-work are separated. |
| `SCPA-26` | imports | PKS-15 | Defensive cyber action is outside ordinary referral unless separately constituted. |
| `SCPA-27` | imports | PKS-15 | Third-party cyber disruption cannot be inferred from protection need. |
| `SCPA-28` | imports | PKS-15 | Financial restraint/freeze requires independent authority. |
| `SCPA-29` | contains | PKS-13; PKS-20 | Cooperation request and acceptance remain bounded. |
| `SCPA-30` | extends | PKS-04; PKS-05; PKS-23 | Security allegations require source limits, challenge, and no automatic consequence. |
| `SCPA-31` | contains | PKS-14; PKS-18; PKS-24 | Independent authorization/review does not merge action routes. |
| `SCPA-32` | imports | PKS-16; PKS-23 | Adjudication is outside the addendum and remains independently reviewable. |
| `SCPA-33` | extends | PKS-26 | Remedy and compensation cover referral, disclosure, care, and protection failures. |
| `SCPA-34` | extends | PKS-06; PKS-10 | Restorative/rehabilitative participation remains voluntary and separate. |
| `SCPA-35` | extends | PKS-22; PKS-25; PKS-29 | Data correction, expungement, and use limitation propagate downstream. |
| `SCPA-36` | extends | PKS-28; PKS-30 | Termination and unresolved risk do not preserve power. |
| `SCPA-37` | contains | PKS-06; PKS-10; PKS-20 | Survivor sovereignty and unconditional service access. |
| `SCPA-38` | contains | PKS-07; PKS-08 | Child, dependent-person, disability, and accessibility protections. |
| `SCPA-39` | imports | PKS-03; PKS-04 | Indigenous authority and protected knowledge remain with competent holders. |
| `SCPA-40` | extends | PKS-06; PKS-10 | Process choice cannot become compelled cooperation. |
| `SCPA-41` | contains | PKS-20; PKS-21 | Witness and source protection remain non-carceral and voluntary. |
| `SCPA-42` | contains | PKS-27 | Worker duties, safe refusal, and anti-retaliation. |
| `SCPA-43` | imports | PKS-28; PKS-29 | Programme closure, handback, and service continuity. |
| `SCPA-44` | imports | PKS-03; PKS-17 | Aegis/security-use reversion remains applicable if converted capability is introduced. |

# 28. Handoff types

Implementations shall support at least:

1. `peace_to_kintsugi_support`;
2. `peace_to_urgent_authority`;
3. `kintsugi_to_urgent_authority`;
4. `peace_to_shield_protection`;
5. `kintsugi_to_shield_protection`;
6. `shield_to_local_protection_service`;
7. `support_to_investigation_offer`;
8. `investigation_to_support_continuity_notice`;
9. `correction_to_all_recipients`;
10. `termination_and_authority_return`.

Each handoff shall identify the canonical state, records, purpose, accepted scope, rejected scope, access, custody, retained duties, onward restrictions, review clock, correction, return, and closure.

# 29. Constitutional readiness gates

| Gate | Name | Pass criterion |
|---|---|---|
| G01 | Exact compatibility | All controlling versions and hashes match the manifest. |
| G02 | Authority effect none | The addendum and packet create no power or jurisdiction. |
| G03 | Stable identity | One CFPAE identity links separate local and SCPA records. |
| G04 | Role separation | Peace, Kintsugi, Shield, and external authorities have explicit excluded functions. |
| G05 | Four referral outcomes | Consultation only, protected support referral, urgent protective referral, and no referral are representable. |
| G06 | Consent and legal exception | Consent state or exact lawful disclosure exception is recorded. |
| G07 | Minimum necessary | Offered information is limited to the accepted protective function. |
| G08 | Protected source | Mediation, survivor, child, medical, spiritual, and care material retains restrictions. |
| G09 | Receipt not acceptance | Canonical handoff states and retained duties are used. |
| G10 | Independent SCPA-18 | Urgent action has its own competent authority and record. |
| G11 | No escalation by failure | Mediation impasse or restorative-process failure creates no security route. |
| G12 | Care continuity | Support continues after refusal, withdrawal, rejection, or no investigation. |
| G13 | Investigation firewall | SCPA-11/12 are separately opened and scoped. |
| G14 | Compulsory-process firewall | SCPA-13 through SCPA-17 cannot be inferred from protection. |
| G15 | Custody/force firewall | SCPA-19 through SCPA-25 are separately classified and authorized. |
| G16 | No protective euphemism | Blocked exit, guarded transport, or physical control is treated as custody/restraint. |
| G17 | Affected-person challenge | Notice, access, protected substitute, advocacy, and remedy exist. |
| G18 | Child/dependent safeguards | Best interests and independent representation do not erase rights. |
| G19 | Accessibility | Interpretation and supported decision-making are operational. |
| G20 | Retaliation protection | Source, participant, worker, and dependant risks are managed. |
| G21 | Independent clocks | Each route has its own expiry and review; earlier expiry controls shared acts. |
| G22 | Correction propagation | Corrections and withdrawals reach all recipients and derivative systems. |
| G23 | Complete closure | Authority return, care continuity, remedy, and data disposition precede closure. |
| G24 | Unresolved risk without power | Open risk cannot preserve expired security or coercive authority. |

# 30. Compound implementation test suite

At minimum, adopting implementations shall test:

1. A mediator hears a vague rumour of violence; the case remains consultation-only and no identifying referral is made.
2. A participant reports a specific threat but declines disclosure; Peace and Kintsugi create a safety plan without investigation or police contact.
3. A participant consents to a Kintsugi shelter referral but not a Shield referral; only service information moves.
4. A credible imminent abduction risk triggers an offered SCPA-18 referral; receipt alone produces no action.
5. The urgent-protection authority accepts only temporary separation and rejects device search; SCPA-13/15 remain unopened.
6. A safe house locks an exit for operational convenience; the system reclassifies the situation as custody and blocks it absent SCPA-20.
7. Guarded transport is proposed as accompaniment; PKS-16 identifies restraint/custody implications and requires separate authority.
8. A Safety Weaver requests a physical intervention; Kintsugi cannot activate or command it.
9. A mediator’s notes are requested for intelligence analysis; PKS-04/11 block transfer absent independent authority and lawful exception.
10. Shield receives a protected danger summary and accepts victim protection but rejects investigation; care and safety continue.
11. Shield opens a transnational protection route while the person refuses prosecution; support remains unconditional.
12. An investigative authority later opens SCPA-11 using independently obtained facts; the mediation file is not imported wholesale.
13. A court orders narrow disclosure; PKS-12 records scope, notice, challenge, and withheld privileged material.
14. Mandatory child safeguarding law applies; disclosure is minimum necessary and does not automatically separate the child from family.
15. A child communicates nonverbally; accessibility support prevents silence from being treated as consent or unreliability.
16. A survivor withdraws from an interview after one session; future cooperation ends but shelter and legal aid remain.
17. A protected location is accidentally disclosed; PKS-22 opens containment, notice, relocation support, correction, and remedy.
18. A false identity match enters a recipient system; PKS-25 propagates correction to all downstream records and decisions.
19. A peace process ends while urgent protection continues under ordinary law; records detach without extending Peace authority.
20. Urgent protection expires while a criminal investigation remains open; the investigation does not preserve protective restrictions.
21. An investigation remains open while Kintsugi care ends by the person’s choice; data and authority close separately.
22. A worker refuses to disclose a complete survivor file; PKS-27 protects employment and professional standing.
23. A worker is asked to enter an armed scene; safe refusal and substitute staffing activate.
24. A religious or spiritual disclosure indicates self-harm risk; the route records uncertainty and uses the least intrusive lawful support.
25. Mediation failure in a labour dispute is misdescribed as escalation risk; no Shield or SCPA-18 route opens without individualized facts.
26. A person is both alleged aggressor and trafficking survivor; support, protection, investigation, and adjudication statuses remain separate.
27. A cross-border exploiter threatens a witness’s family; Shield coordinates protection without acquiring border, detention, or sanctions power.
28. An emergency event coexists with the referral; ESDIB links the event without merging emergency and SCPA clocks.
29. An Aegis-converted vehicle is proposed for guarded transport; SCPA-44 reversion triggers and civilian status cannot authorize custody.
30. All operations end but correction and compensation remain pending; the packet cannot close until remedy and data disposition are complete.

# 31. Conformance levels

- **PRUP-L0 — Reference:** cites the Addendum but does not implement canonical identity, records, or handoffs.
- **PRUP-L1 — Structural:** implements the profile, 30 PRUP records, SCPA crosswalk, access classes, and handoff states.
- **PRUP-L2 — Operational:** validates packets, deadlines, protected custody, role separation, correction, and closure across at least Peace, Kintsugi, Shield, and one independently competent urgent authority.
- **PRUP-L3 — Adversarial:** passes the 30 compound tests, independent legal/privacy/accessibility review, worker exercises, breach simulation, correction propagation, and remedy testing.

Binding cross-framework referral should not proceed below PRUP-L2. Any custody, force, search, investigation, or other consequential route additionally requires the independent law and SCPA records for that act.

# 32. Adoption clause

An adopting framework shall state:

> This framework adopts `PKS-PRUP/0.1`, `SCPA/0.1`, `SCPA-RIC/0.1`, and `CFPAE/0.1` for protected Peace–Kintsugi–Shield referral and urgent-protection coordination. Adoption creates no new authority. Protected receipt is not intelligence or evidence; referral is not acceptance; acceptance transfers only the named function; urgent protection requires a separately valid `SCPA-18`; and investigation, compulsory process, custody, force, and enforcement require their own lawful records. Care and peace support remain available regardless of voluntary investigative cooperation.

# 33. Failure boundaries

The Addendum fails closed where:

- exact compatibility is unknown;
- the person or protected source cannot be represented safely;
- confidentiality or disclosure authority is unresolved;
- the requested function or recipient is unclear;
- minimum-necessary information cannot be separated from prohibited material;
- the recipient has not accepted responsibility;
- `SCPA-18` authority, jurisdiction, exact act, clock, or review is missing;
- search, restraint, custody, force, investigation, evidence, migration, or other higher-class action is plausible but unclassified;
- care continuity would be conditioned on cooperation;
- notice, challenge, correction, remedy, or data disposition is absent;
- role, command, custody, or worker safety is ambiguous.

Where immediate inaction would itself create grave imminent risk, only a separately valid and least-restrictive `SCPA-18` action may proceed within its own threshold and clock. It does not cure missing authority for another action class.

# 34. Release statement

This Addendum resolves the Peace–Kintsugi–Shield protected-referral interface at the specification level. It is suitable for controlled adoption, prototype packet implementation, tabletop exercises, training, and jurisdiction-specific legal adaptation. It is not itself a source of police, intelligence, child-protection, custody, force, investigation, or other public power.

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path
from datetime import date

OUT = Path('/mnt/data')
MAIN = OUT / 'scpa-record-inheritance-conformance-clause-v0.1.md'
REGISTRY = OUT / 'scpa-record-inheritance-conformance-clause-v0.1.json'
VALIDATION = OUT / 'scpa-record-inheritance-conformance-clause-v0.1-validation.txt'
CHECKSUMS = OUT / 'scpa-record-inheritance-conformance-clause-v0.1-checksums.txt'
ZIP = OUT / 'scpa-record-inheritance-conformance-clause-v0.1.zip'

sources = {
    'SCPA/0.1': OUT / 'security-coercion-protective-action-interface-specification-v0.1.md',
    'SCHIT/0.1': OUT / 'security-coercion-cluster-harmonization-interface-test-v0.1.md',
    'Shield/2.0': OUT / 'shield-protocol-v2.0.md',
    'Kintsugi/2.2': OUT / 'kintsugi-protocol-v2.2.md',
    'Migration/1.1': OUT / 'migration-human-mobility-v1.1.md',
    'Peace/1.8': OUT / 'peace-conflict-resolution-framework-v1.8.md',
    'Aegis/1.3.3': OUT / 'aegis-protocol-v1.3.3.md',
    'ECRC-RIC/0.1 precedent': OUT / 'emergency-record-inheritance-clause-v0.1.md',
}

for label, path in sources.items():
    if not path.exists():
        raise FileNotFoundError(f'Missing source {label}: {path}')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

source_manifest = [
    {
        'source_id': label,
        'filename': path.name,
        'sha256': sha256(path),
        'size_bytes': path.stat().st_size,
    }
    for label, path in sources.items()
]

# Parse canonical records from SCPA itself to avoid transcription drift.
scpa_text = sources['SCPA/0.1'].read_text(encoding='utf-8')
record_matches = re.findall(r'^## (SCPA-\d{2}) — (.+)$', scpa_text, flags=re.M)
if len(record_matches) != 44:
    raise RuntimeError(f'Expected 44 SCPA records, found {len(record_matches)}')

record_catalogue = [{'canonical_id': rid, 'canonical_title': title.strip()} for rid, title in record_matches]

# Action class assignment follows the SCPA catalogue topology.
def action_class_for(n: int) -> str:
    if 1 <= n <= 8:
        return 'cross-cutting authority and safeguards'
    if 9 <= n <= 10:
        return 'B — observation, warning, and protected intelligence'
    if 11 <= n <= 12:
        return 'C — investigation'
    if 13 <= n <= 17:
        return 'E — compulsory legal process'
    if n == 18:
        return 'D — urgent protective action'
    if 19 <= n <= 25:
        return 'F — custody and physical force'
    if 26 <= n <= 27:
        return 'G — cyber intervention'
    if n == 28:
        return 'H — financial coercion'
    if n == 29:
        return 'cross-border cooperation and mutual legal assistance'
    if n == 30:
        return 'K — mobility, identity, and territorial action'
    if 31 <= n <= 33:
        return 'I — adjudication and remedy'
    if n == 34:
        return 'J — restoration, rehabilitation, and reintegration'
    if n in (35, 36):
        return 'cross-cutting closure and authority return'
    if 37 <= n <= 42:
        return 'cross-cutting protected persons, functions, and communication'
    if n in (43, 44):
        return 'cross-cutting institutional continuity and non-activation'
    raise ValueError(n)

for rec in record_catalogue:
    rec['action_class'] = action_class_for(int(rec['canonical_id'].split('-')[1]))

header_fields = [
    {'name': 'record_id', 'meaning': 'Canonical SCPA identifier; immutable across domain specializations.'},
    {'name': 'record_instance_id', 'meaning': 'Globally or jurisdictionally unique identifier for this record instance.'},
    {'name': 'record_version', 'meaning': 'Version of the record instance or domain specialization.'},
    {'name': 'status', 'meaning': 'Current record lifecycle state.'},
    {'name': 'created_at_and_effective_at', 'meaning': 'Creation and legal or operational effective timestamps.'},
    {'name': 'created_by_and_role', 'meaning': 'Creating actor and the function in which the actor acted.'},
    {'name': 'competent_authority', 'meaning': 'Authority legally competent for the exact action or decision.'},
    {'name': 'legal_source_and_version', 'meaning': 'Exact constituting law, order, mandate, agreement, or other valid source.'},
    {'name': 'jurisdiction', 'meaning': 'Territorial, personal, subject-matter, temporal, and cross-border basis.'},
    {'name': 'cluster_event_id_or_case_mission_identifier', 'meaning': 'Shared identity where applicable; creates no shared command.'},
    {'name': 'action_class_and_exact_act', 'meaning': 'SCPA class and precise proposed, authorized, performed, or reviewed act.'},
    {'name': 'affected_subjects', 'meaning': 'Persons, groups, assets, systems, places, or institutions using protected identifiers where required.'},
    {'name': 'linked_records', 'meaning': 'Canonical and domain record links, including authority, review, termination, and remedy dependencies.'},
    {'name': 'source_and_reliability_limits', 'meaning': 'Source provenance, uncertainty, contest, and reliability limits.'},
    {'name': 'prohibited_inferences', 'meaning': 'Inferences the record cannot lawfully support.'},
    {'name': 'rights_and_safeguards', 'meaning': 'Applicable rights, accessibility, protected status, labour, survivor, child, and Indigenous safeguards.'},
    {'name': 'access_class', 'meaning': 'SCPA access class and any lawful domain-specific strengthening.'},
    {'name': 'notice_status', 'meaning': 'Notice delivered, delayed, limited, waived by law, or pending, with reasons and review.'},
    {'name': 'review_authority_and_review_due_at', 'meaning': 'Independent or competent review function and clock.'},
    {'name': 'expires_at_or_non_expiry_basis', 'meaning': 'Expiry timestamp or separately valid basis for non-expiring status.'},
    {'name': 'challenge_route', 'meaning': 'Complaint, appeal, urgent challenge, counsel, representative, or review route.'},
    {'name': 'termination_trigger', 'meaning': 'Condition that ends, suspends, narrows, or reclassifies the authority or action.'},
    {'name': 'data_disposition_rule', 'meaning': 'Retention, correction, deletion, sealing, transfer, return, or protected custody rule.'},
    {'name': 'remedy_route', 'meaning': 'Restitution, compensation, release, correction, property return, public correction, or institutional remedy.'},
    {'name': 'supersedes_and_superseded_by', 'meaning': 'Immutable predecessor and successor links.'},
    {'name': 'integrity_digest', 'meaning': 'Technical integrity digest where appropriate; does not prove truth, validity, or authority.'},
    {'name': 'public_summary_or_protection_reason', 'meaning': 'Public or claimant-accessible account, or lawful reason for protected status.'},
]

relationships = {
    'implements': 'One domain record satisfies the canonical purpose and all applicable canonical minimum fields.',
    'extends': 'The domain record includes the complete canonical record plus additional domain-specific fields or safeguards.',
    'splits': 'Two or more domain records jointly satisfy one canonical record; components, field allocation, assembly, and closure are declared.',
    'contains': 'One domain package carries two or more canonical records as separately identifiable subrecords with distinct authorities, legal effects, states, access controls, review clocks, and closure.',
    'imports': 'The canonical SCPA record is used directly without domain renaming.',
    'not_applicable': 'A competent function makes an action- or case-specific determination that the canonical trigger cannot arise or has not arisen, with reasons and review conditions.',
}

access_classes = {
    'SCPA-PUBLIC': 'Public constitutional, legal, statistical, and non-sensitive action information.',
    'SCPA-AFFECTED': 'Available to the affected person or authorized representative, subject only to lawful and reviewable redaction.',
    'SCPA-REVIEW': 'Available to competent independent reviewers, courts, auditors, counsel, and equivalent oversight under protected conditions.',
    'SCPA-OPERATIONAL': 'Purpose-limited operational access with role, time, purpose, logging, onward-transfer, and review controls.',
    'SCPA-PROTECTED': 'Source-identifying, survivor, child, medical, Indigenous-restricted, privileged, classified, or high-risk material subject to heightened law and non-transfer rules.',
}

canonical_states = [
    'draft', 'submitted', 'authorized', 'partially_authorized', 'rejected', 'active',
    'suspended', 'expired', 'terminated', 'under_review', 'corrected', 'superseded', 'archived'
]
closure_states = ['handoff_pending', 'authority_return_pending', 'remedy_pending', 'data_disposition_pending', 'closed']
handoff_states = ['offered', 'received_not_assessed', 'deficient', 'partially_accepted', 'accepted', 'concurrent_responsibility', 'rejected', 'withdrawn', 'returned', 'closed']

mapping_fields = [
    'canonical_id', 'canonical_title', 'action_class', 'domain_record', 'relationship',
    'applicability_trigger', 'responsible_function', 'competent_authority_source',
    'default_access_class', 'required_links', 'handoff_and_recipient', 'review_clock',
    'closure_condition', 'current_gap'
]

implementation_tests = [
    'A domain record is renamed but its canonical identifier remains traceable.',
    'An unmapped triggered record is imported directly rather than omitted.',
    'A not-applicable determination is rejected when it merely states that a field is inconvenient or unknown.',
    'A split implementation fails when one required component or field allocation is missing.',
    'A containing package preserves separate identities for intelligence intake, investigation, compulsory process, custody, adjudication, and remedy.',
    'A combined user interface cannot merge authorities or review clocks.',
    'Receipt of a referral does not become acceptance or authorization.',
    'Partial acceptance identifies the accepted function, rejected material, retained sender duties, and unresolved safeguards.',
    'Concurrent responsibility does not create joint command or erase separate legal bases.',
    'Protected source restrictions survive transfer and block incompatible onward use.',
    'A lower-access domain label cannot weaken the inherited SCPA access class.',
    'An affected person receives an effective public or claimant-accessible account unless a lawful reviewed exception applies.',
    'An expired or terminated authority cannot remain active because the operational case remains open.',
    'Operational completion does not close remedy, data disposition, property return, release, or authority-return duties.',
    'A correction preserves the prior version, reason, actor, time, and replacement link.',
    'A later SCPA or framework version is not substituted without a recorded compatibility test.',
    'A record or dashboard cannot activate a coercive power that lacks its own authority provenance.',
    'Automated validation may flag completeness but cannot decide legal authority, credibility, guilt, necessity, Indigenous consent, or use of force.',
    'A cross-framework case identifier coordinates topology but does not create shared command or jurisdiction.',
    'An incompatible or unresolved record blocks only the affected consequential action where safe, without creating residual authority elsewhere.',
    'SCPA-09/10 material does not silently become SCPA-11 investigation authority.',
    'SCPA-11/12 investigation material does not silently become SCPA-13 through SCPA-17 compulsory process.',
    'SCPA-18 urgent protection does not silently become SCPA-19 through SCPA-25 custody or force.',
    'SCPA-30 mobility and protection proceedings preserve challenge and non-refoulement despite protected security allegations.',
    'SCPA-44 reversion suspends civilian assurances but does not authorize the proposed security use.',
]

source_table = '\n'.join(
    f"| `{s['source_id']}` | `{s['filename']}` | `{s['sha256']}` | {s['size_bytes']:,} |"
    for s in source_manifest
)

record_rows = '\n'.join(
    f"| `{r['canonical_id']}` | {r['canonical_title']} | {r['action_class']} |"
    for r in record_catalogue
)

header_rows = '\n'.join(
    f"| {i} | `{f['name']}` | {f['meaning']} |" for i, f in enumerate(header_fields, 1)
)

relationship_rows = '\n'.join(f"| `{k}` | {v} |" for k, v in relationships.items())
access_rows = '\n'.join(f"| `{k}` | {v} |" for k, v in access_classes.items())
mapping_rows = '\n'.join(f"| `{field}` | Required domain-specific entry |" for field in mapping_fields)
test_rows = '\n'.join(f"{i}. {t}" for i, t in enumerate(implementation_tests, 1))

md = f'''# SCPA Record Inheritance and Conformance Clause v0.1

## Insertion-ready common clause for security-, protection-, mobility-, peace-, community-safety-, cyber-, financial-, justice-, and converted-capability frameworks

**Clause ID:** `SCPA-RIC/0.1`  
**Depends on:** Security, Coercion, and Protective Action Interface Specification v0.1 (`SCPA/0.1`)  
**Responds to:** Security-and-Coercion Cluster Harmonization and Compound Interface Test v0.1 (`SCHIT/0.1`)  
**Status:** Draft for controlled common adoption  
**Date:** August 1, 2026

> **A domain record may specialize an SCPA record. It may not erase the canonical identity, combine distinct powers, weaken inherited safeguards, or convert information into authority.**

> **No valid authority record, no consequential security or coercive action.**

---

# Executive summary

The five revised security-and-coercion cluster frameworks now bound their own powers, but they do not yet inherit the common SCPA record architecture through one uniform clause. That gap is operational rather than ideological: each framework can safely refuse an action, but independently implemented systems may disagree about record identity, status, access, acceptance, review, closure, and responsibility.

This clause resolves that gap. It defines how a framework may `implement`, `extend`, `split`, `contain`, `import`, or determine the case-specific non-applicability of any of the forty-four SCPA records. It preserves the twenty-seven-field common header, SCPA access classes, handoff states, review clocks, correction history, version pins, termination duties, remedy, data disposition, and fail-closed behavior.

The clause does not create `SCPA-45`, a cluster case authority, a shared intelligence service, a joint police body, a border authority, a tribunal, a command structure, or a general power to act. It is a type and conformance layer. A shared record identity coordinates traceability; it does not create jurisdiction, admissibility, liability, command, or coercive effect.

This document is written for insertion substantially unchanged into Shield Protocol v2.0, Kintsugi Protocol v2.2, Migration and Human Mobility v1.1, Peace and Conflict Resolution Framework v1.8, Aegis Protocol v1.3.3, and later conforming frameworks. Adoption requires a controlled patch, a complete `SCPA-01`–`SCPA-44` crosswalk, exact version pins, and a compatibility manifest.

---

# 1. Purpose, scope, and legal character

## 1.1 Purpose

The purpose of `SCPA-RIC/0.1` is to make the canonical SCPA record architecture explicit and interoperable across independently governed frameworks without centralizing their authority.

It provides:

1. one canonical identity system for all forty-four SCPA records;
2. one inheritance vocabulary for domain specializations;
3. one twenty-seven-field minimum header;
4. one access-class vocabulary;
5. one handoff state model;
6. one minimum lifecycle and closure model;
7. one correction and supersession rule;
8. one version-pinning and compatibility rule;
9. one complete conformance crosswalk format; and
10. one fail-closed rule for unmapped, expired, incompatible, or unresolved records.

## 1.2 Scope

This clause applies whenever a conforming framework creates, receives, uses, displays, transmits, specializes, combines, reviews, corrects, closes, archives, or relies upon a record whose function falls within `SCPA-01` through `SCPA-44`.

It applies to human-readable instruments, paper forms, case-management systems, APIs, registries, dashboards, protected annexes, judicial or administrative files, encrypted exchanges, mission packets, and machine-readable schemas.

It applies whether the framework's primary orientation is voluntary assistance, peacebuilding, community safety, migration protection, crime cooperation, cyber defence, asset recovery, adjudication, rehabilitation, capability conversion, or institutional transition.

## 1.3 Interface, not grant of power

This clause does not authorize observation, intelligence collection, investigation, compulsory disclosure, search, entry, interception, seizure, urgent protection, arrest, restraint, detention, transfer, force, weapons, cyber disruption, sanctions, financial restraint, border action, removal, adjudication, rehabilitation, data retention, or security use of a converted capability.

A valid record documents or routes an independently valid authority. It does not manufacture that authority.

## 1.4 No SCPA-45

A case file, envelope, packet, dashboard, registry, crosswalk, or compatibility manifest created under this clause is not an additional canonical SCPA record and is not a residual source of authority. It may carry or index canonical records, but every carried record retains its own legal effect, competent authority, status, access class, review clock, challenge route, termination trigger, and remedy obligations.

---

# 2. Normative record inheritance and conformance clause

A framework adopting `SCPA-RIC/0.1` SHALL incorporate the following clauses substantially unchanged.

## Clause 1 — Specialization does not replace the canonical set

This framework's domain record list specializes but does not replace `SCPA-01` through `SCPA-44`. Every canonical record remains required whenever its applicability trigger occurs. A framework may be primarily non-coercive and therefore rarely trigger many records; rarity does not make a triggered record optional.

## Clause 2 — Canonical identity

Every domain record SHALL identify the canonical `SCPA-##` record or records it `implements`, `extends`, `splits`, `contains`, or `imports`.

A domain label MAY differ from the canonical title. The canonical identifier, SCPA version, action class, common header, minimum function, prohibited inferences, access protections, review obligations, lifecycle duties, and legal separations SHALL remain traceable.

The canonical identifier SHALL not be reassigned, recycled, or silently converted to another function.

## Clause 3 — Direct import

A canonical record not mapped to a domain specialization is imported directly when triggered. Absence from a framework appendix, software form, implementation guide, dashboard, local registry, or training manual does not make the record optional.

An unmapped record SHALL be treated as `imports`, not as implicitly `not_applicable`.

## Clause 4 — Case-specific non-applicability

A record may be marked `not_applicable` only through a reasoned, action- or case-specific determination identifying:

1. the canonical trigger tested;
2. the deciding function;
3. the competent authority, if legal authority is implicated;
4. the evidence and legal basis;
5. why the trigger cannot arise or has not arisen;
6. which records become required if circumstances change;
7. the review or expiry condition; and
8. the person or function responsible for reopening the determination.

`Not applicable` does not mean unknown, inconvenient, deferred, unavailable, politically undesirable, outside a software product's current features, or omitted from a budget.

A framework may declare a record structurally outside its ordinary mandate only where the framework cannot lawfully perform the triggering act. The record still applies to any separate authority that performs the act in a linked case.

## Clause 5 — Permitted inheritance relationships

The only common inheritance relationships are:

{relationship_rows}

A domain MAY define a narrower local subtype of one of these relationships, but its compatibility manifest SHALL map the subtype back to one of the six common relationships.

## Clause 6 — Split records

Where several domain records jointly implement one canonical record, the framework SHALL:

1. declare `splits`;
2. identify every component record;
3. allocate every required canonical field and function;
4. identify the assembly and completeness rule;
5. designate the function responsible for verifying completeness;
6. preserve one traceable canonical lifecycle; and
7. prevent any component from inheriting another component's authority or legal effect by implication.

A split record is incomplete when a required component, field allocation, review, notice, closure, or protection rule is absent.

## Clause 7 — Containing packages and composite files

A domain package MAY contain two or more canonical records only when every subrecord remains separately:

- identifiable;
- versioned;
- attributable to its competent authority;
- classifiable by exact SCPA action class and act;
- reviewable;
- challengeable;
- correctable;
- exportable;
- access-controlled;
- expirable or terminable; and
- closable.

A shared display, case file, envelope, incident number, investigation folder, mission packet, or API payload does not merge legal effects.

The following boundaries SHALL remain explicit even when records travel together:

1. `SCPA-09`/`SCPA-10` protected information and intelligence are not `SCPA-11` investigation authority;
2. `SCPA-11`/`SCPA-12` investigation is not `SCPA-13` through `SCPA-17` compulsory process;
3. `SCPA-18` urgent protection is not `SCPA-19` through `SCPA-25` custody, detention, force, weapons, or command;
4. `SCPA-26` defensive cyber action is not `SCPA-27` third-party disruption;
5. `SCPA-28` preservation, restraint, freeze, forfeiture, sanction, and exclusion remain separately authorized legal effects;
6. `SCPA-29` cooperation is not domestic or foreign operational authority;
7. `SCPA-30` protection or security allegation is not detention, removal, extradition, or adverse status authority;
8. `SCPA-31` authorization or review is not investigation or enforcement;
9. `SCPA-34` restorative or rehabilitative participation is not adjudication, custody, or compelled treatment; and
10. `SCPA-44` security-use reversion is not authorization for the proposed security use.

## Clause 8 — Common twenty-seven-field header

Every canonical or domain-specialized SCPA record SHALL contain or inherit the following minimum header:

| # | Field | Minimum meaning |
|---:|---|---|
{header_rows}

A framework MAY add fields. It SHALL NOT omit, rename beyond reliable machine mapping, weaken, or overload a common field so that a material legal distinction becomes ambiguous.

A field MAY be held in a protected annex when disclosure would itself cause harm. The public, affected-person, or independent-review layer SHALL still reveal enough information to identify the existence, authority, legal effect, status, duration, review, and remedy of the record unless a competent independent authority records a narrowly tailored exception.

## Clause 9 — Action class and exact act

Every record SHALL state both the SCPA action class and the exact act proposed, authorized, performed, transferred, reviewed, or terminated.

Classification follows method and legal effect, not benevolent purpose, institutional identity, programme label, emergency severity, public approval, or the language used in an interface.

Where more than one action class is plausible, the higher or more protective procedural route applies until a competent authority records a lawful classification.

## Clause 10 — Required action bundle

A consequential action SHALL not proceed until the applicable action bundle is complete. At minimum, the implementation SHALL assess the need for:

- `SCPA-01` authority provenance;
- `SCPA-02` standing and jurisdiction;
- `SCPA-03` action classification;
- `SCPA-04` individualized factual basis for person-specific adverse action;
- `SCPA-05` prohibited inference and automated-use controls;
- `SCPA-06` necessity, proportionality, and alternatives;
- `SCPA-07` rights, accessibility, and protected status;
- `SCPA-08` notice, reasons, counsel, interpretation, and challenge;
- the action-specific record;
- `SCPA-31` independent authorization or review where required;
- `SCPA-32` appeal, complaint, challenge, and interim relief;
- `SCPA-33` remedy where harm or wrong occurs;
- `SCPA-35` data disposition; and
- `SCPA-36` termination and authority return.

An implementation MAY combine transmission or presentation only when every canonical identity and distinction remains explicit.

## Clause 11 — No record-to-power conversion

A record, alert, report, recommendation, assessment, threat description, source statement, analytical score, spiritual or developmental interpretation, migration status, community concern, mediation impasse, emergency request, funding decision, capability certificate, or dashboard entry does not activate a consequential power.

A canonical record documents a valid legal step only when its own authority, jurisdiction, trigger, safeguards, review, and lifecycle requirements are satisfied.

Severity determines urgency and scale, not authority.

## Clause 12 — Shared identity without shared command

A shared `cluster_event_id`, case identifier, mission identifier, envelope identifier, or topology link may coordinate records across frameworks. It does not:

- merge jurisdictions;
- create a joint authority;
- transfer command;
- establish causation or liability;
- make evidence admissible;
- authorize disclosure;
- assign responsibility;
- activate powers; or
- extend a power's duration.

Parent, child, split, merge, duplicate, and related-case relationships SHALL be explicit. Records SHALL not be silently reassigned to a different event, person, territory, or mission.

## Clause 13 — Handoff state model

Every cross-function or cross-framework handoff SHALL use one of the following states:

`offered`, `received_not_assessed`, `deficient`, `partially_accepted`, `accepted`, `concurrent_responsibility`, `rejected`, `withdrawn`, `returned`, or `closed`.

Receipt is not acceptance. Silence is never acceptance. Technical ingestion is not legal acceptance. Access to a record is not acceptance of authority, command, custody, liability, evidentiary status, or onward-transfer rights.

## Clause 14 — Handoff content

A handoff SHALL identify:

1. sender and sending function;
2. recipient and receiving function;
3. canonical and domain record identifiers;
4. exact function or material offered;
5. legal and territorial basis for transfer;
6. access class and protected annexes;
7. purpose and prohibited onward uses;
8. affected-person notice and challenge status;
9. custody, integrity, and data-disposition duties;
10. requested acceptance scope;
11. response deadline and consequence of no response;
12. retained sender duties;
13. review and expiry clocks;
14. conditions for return, withdrawal, correction, or closure; and
15. remedy route for wrongful transfer or use.

## Clause 15 — Partial acceptance and concurrent responsibility

A recipient MAY partially accept a handoff only by identifying:

- the exact accepted function and material;
- material or functions rejected, held deficient, or left unassessed;
- the legal basis and access rights accepted;
- retained sender duties;
- recipient duties;
- concurrent or unresolved responsibilities;
- independent review requirements;
- correction and withdrawal routes; and
- closure conditions.

`Concurrent_responsibility` does not mean joint command, merged authority, collective liability, or a general permission to act. Every function retains its own legal basis and review.

## Clause 16 — Sender duties survive transport

Unless valid law and an expressly accepted record reassign a duty, the sender retains responsibility for:

- source protection;
- accuracy limits and correction;
- lawful collection;
- affected-person notice owed by the sender;
- privilege and non-transfer restrictions;
- retention and deletion duties;
- compensation or remedy arising from the sender's conduct; and
- closure of the sender's own record.

A sender cannot export an unlawful collection, expired authority, unresolved rights violation, or missing review by transmitting the record to another framework.

## Clause 17 — Access-class inheritance

The common access classes are:

| Access class | Meaning |
|---|---|
{access_rows}

A domain MAY impose stronger protection. It SHALL NOT weaken the inherited class or use relabelling, aggregation, de-identification claims, encryption, secrecy, classification, or a protected annex to bypass purpose limitation, affected-person rights, independent review, correction, expiry, retention, or remedy.

Access class controls disclosure and handling. It does not determine truth, authority, admissibility, guilt, liability, or permission to act.

## Clause 18 — Protected non-transfer

Source identities, survivor material, child information, medical data, asylum and protection records, mediation communications, privileged material, Indigenous-restricted knowledge, classified information, and other high-risk content retain their original legal and ethical restrictions during transport.

A recipient SHALL not infer permission for investigation, intelligence dissemination, prosecution, immigration action, public release, machine learning, profiling, or another purpose from the fact that the material was technically received.

Where protected material cannot lawfully be transferred, the parties SHALL consider narrower alternatives such as a public summary, claimant summary, redacted extract, controlled query, sealed computation, independent verification, aggregate attestation, local analysis, or a reasoned refusal.

## Clause 19 — Affected-person notice and access

A conforming implementation SHALL preserve an effective public, affected-person, representative, counsel, or independent-review account sufficient to challenge the legal basis, general reasons, action class, duration, review, and remedy of consequential action.

Delayed or limited notice requires a separate lawful basis, necessity, proportionality, expiry, independent review, and an equivalent protective mechanism. Secret law, secret general powers, and unreviewable secret evidence are non-conforming.

## Clause 20 — Record lifecycle

Canonical SCPA states are:

`draft`, `submitted`, `authorized`, `partially_authorized`, `rejected`, `active`, `suspended`, `expired`, `terminated`, `under_review`, `corrected`, `superseded`, and `archived`.

For cross-framework closure, implementations SHALL additionally support:

`handoff_pending`, `authority_return_pending`, `remedy_pending`, `data_disposition_pending`, and `closed`.

A domain MAY add states, but SHALL map them to the common lifecycle in its compatibility manifest.

The following rules apply:

1. submission is not authorization;
2. receipt is not acceptance;
3. authorization is not operational completion;
4. operational completion is not legal closure;
5. expiry ends the temporal legal effect unless separately renewed under valid law;
6. termination normally initiates authority return, property or credential return, release where applicable, data disposition, correction, claims, and remedy review;
7. a record becomes `closed` only after all required linked closure duties are verified or transferred through an accepted record;
8. `archived` is a retention state, not continuing authority or use permission; and
9. a contested or reviewed record remains visibly linked to the action and does not disappear from the audit trail.

## Clause 21 — Review clocks and temporal independence

Each record retains its own review and expiry clock. A shared event, case, mission, investigation, emergency, judicial proceeding, restorative process, or programme may remain open without keeping every linked power active.

Renewal of one record does not renew another. Reopening a case does not reactivate an expired or terminated authority. Unresolved risk, causation, guilt, origin, liability, compensation, or scientific uncertainty does not keep a coercive power alive.

## Clause 22 — Correction, withdrawal, supersession, and integrity

`record_instance_id` remains immutable. Corrections, withdrawals, invalidation, disputes, and supersession SHALL preserve:

- the prior state;
- the changed fields;
- the reason;
- the responsible actor and function;
- the timestamp;
- notice and review consequences;
- links to replacement or dependent records; and
- remedial consequences of prior use.

Hashes, signatures, ledgers, cryptographic proofs, and schema validation MAY support integrity. They do not prove authenticity, accuracy, legality, reliability, admissibility, authority, causation, guilt, or consent.

## Clause 23 — Precedence and stronger safeguards

Where a domain record conflicts with the canonical SCPA record architecture, the rule that better preserves valid authority provenance, functional separation, individualized basis, protected non-transfer, rights, accessibility, notice, temporal limits, review, challenge, remedy, data disposition, and authority return controls for cluster interoperability.

A domain framework MAY impose stronger safeguards. It SHALL NOT weaken canonical safeguards by renaming, omission, aggregation, software design, local custom, emergency language, inter-framework agreement, or machine-readable implementation.

## Clause 24 — Version pinning and compatibility manifests

A framework conforms only to the exact SCPA, clause, framework, schema, and addendum versions identified in its compatibility manifest.

A higher version number, similar title, semantic resemblance, or protective intent is not automatic compatibility. Material changes fail closed until a compatibility and compound-scenario test is recorded.

Every compatibility manifest SHALL identify:

- framework name and version;
- exact `SCPA/0.1` and `SCPA-RIC/0.1` pins;
- document and schema hashes;
- all `SCPA-01`–`SCPA-44` mappings;
- local relationship subtypes;
- lifecycle and handoff mappings;
- access-class mappings;
- known gaps;
- test results;
- adoption authority and effective date; and
- superseded compatibility manifest.

## Clause 25 — Complete conformance appendix

Every adopting framework SHALL publish a complete crosswalk for `SCPA-01` through `SCPA-44` showing, for each canonical record:

| Field | Required entry |
|---|---|
{mapping_rows}

Conformance is not established by a general statement that SCPA, Justice, Shield, a court, domestic law, an emergency framework, or another institution controls.

A mapping marked with a current gap SHALL state whether the gap blocks creation, acceptance, use, transfer, renewal, closure, or another specific consequential action.

## Clause 26 — Automated systems

Automated systems MAY check:

- schema and header completeness;
- identifiers and version pins;
- links and cardinality;
- access class;
- expiry and review clocks;
- state-transition consistency;
- signatures and integrity digests;
- missing closure duties; and
- incompatibilities declared in manifests.

Automated systems SHALL NOT determine:

- whether a legal source is valid;
- whether an authority is competent;
- whether jurisdiction exists;
- whether a source or witness is credible;
- whether individualized facts meet a legal threshold;
- whether necessity or proportionality is satisfied;
- whether a person is guilty, dangerous, removable, detainable, or suitable for rehabilitation;
- whether an Indigenous nation has consented;
- whether force, a weapon, detention, cyber disruption, financial coercion, or removal should occur; or
- whether a civilian capability should revert to security status except by recording an authorized human or institutional decision and objective technical state.

## Clause 27 — Fail-closed rule

A consequential action SHALL not proceed, or SHALL pause where safe, when a required record is missing, invalid, expired, incompatible, unmapped, unauthorized, outside jurisdiction, insufficiently individualized, protected against the proposed use, missing required independent review, ambiguous as to command or custody, unavailable to an effective challenge route, or incomplete as to termination and remedy.

The failure blocks the affected action. It does not transfer authority to a coordinating body, intelligence service, peace institution, community council, mobility office, platform, fund, court, emergency body, converted-capability programme, model, residual command, or technical administrator.

Where immediate inaction would itself create a grave and imminent risk, only a separately valid `SCPA-18` urgent protective action may proceed, limited to its own threshold, scope, clock, review, and termination. It does not cure the missing authority for another action class.

## Clause 28 — Controlled adoption and non-substitution

This clause does not by itself amend an existing framework. Adoption requires a controlled amendment or successor version, a complete crosswalk, a compatibility manifest, validation, and a compound interface test.

Until adoption, the canonical SCPA records remain directly applicable when triggered under `SCPA/0.1`, and any inconsistency or gap fails closed for the affected consequential action.

---

# 3. Required adoption statement

An adopting framework SHALL publish substantially the following statement:

> **[Framework name and version] adopts SCPA Record Inheritance and Conformance Clause v0.1 and conforms to Security, Coercion, and Protective Action Interface Specification v0.1 only to the extent shown in its complete SCPA-01–SCPA-44 crosswalk and exact compatibility manifest. Unmapped records are imported directly when triggered. Recorded gaps, expired authorities, unresolved protected-use restrictions, and incompatible versions block the affected consequential action until resolved. Shared record or case identity creates no shared jurisdiction or command.**

---

# 4. Implementation guidance

## 4.1 One domain record may extend one canonical record

This is the simplest conformance pattern. The domain record preserves the complete common header and canonical function, adds domain-specific fields, and declares `extends`.

Example: a migration framework may extend `SCPA-30` with asylum-specific fields while preserving the SCPA security-allegation, challenge, protected-evidence, and non-refoulement architecture.

## 4.2 Several records may split one canonical record

This is appropriate when different functions lawfully hold different fields. The split must still assemble into one complete canonical view for review and closure.

Example: a community-safety framework may split `SCPA-40` between a survivor advocate's confidential safety record and an independently governed process-choice record. Neither component may imply investigation authority or compelled disclosure.

## 4.3 One packet may contain several canonical records

Transport efficiency is permitted. Legal fusion is not.

Example: a Shield mutual-legal-assistance packet may contain `SCPA-29`, a protected `SCPA-09`, an accepted `SCPA-16` chain-of-custody subrecord, and a linked `SCPA-08` notice status. Each remains independently reviewable and closable.

## 4.4 Primarily non-coercive frameworks

Peace and Kintsugi may map many records as direct imports or structurally outside ordinary mandate. They still require full mappings because a linked external authority may trigger urgent protection, evidence transfer, custody, or adjudication in a shared case.

The mapping must make the boundary visible; it must not imply that the non-coercive framework acquires the external function.

## 4.5 Aegis and converted capabilities

Aegis SHALL extend `SCPA-44` with asset, subsystem, operator, credential, software, data, facility, separability, reversion, and requalification fields.

A reversion record suspends civilian assurances. It neither authorizes the requested use nor transfers security command to Aegis.

## 4.6 Emergency-linked cases

Where an event also uses CDEE and ECRC records, the SCPA record SHALL link the shared event identity while retaining separate emergency and security authorities, clocks, reviews, closure, and remedies.

A CDEE or ECRC record does not substitute for an SCPA authority record. An SCPA record does not declare or renew an emergency.

---

# 5. Canonical SCPA record catalogue

The following catalogue is reproduced from the exact `SCPA/0.1` source named in the source manifest. The action-class labels are conformance aids; the canonical record titles and identifiers control.

| Canonical ID | Canonical title | Action class or cross-cutting function |
|---|---|---|
{record_rows}

---

# 6. Required implementation tests

An adopting framework or cluster implementation SHALL pass at least the following tests:

{test_rows}

A test that blocks an unsafe action is a fail-closed pass only where the block is visible, reviewable, and does not silently transfer responsibility or strand an affected person without protection, notice, remedy, or lawful service continuity.

---

# 7. Source and compatibility manifest

This draft was built against the exact local bytes below. A later or similarly titled document is not substituted automatically.

| Source ID | Filename | SHA-256 | Bytes |
|---|---|---|---:|
{source_table}

The emergency record inheritance clause is used only as a drafting precedent for common inheritance mechanics. It does not govern SCPA records and is not incorporated by reference.

---

# 8. Adoption sequence

The recommended controlled sequence is:

1. adopt `SCPA-RIC/0.1` in Shield v2.0, Kintsugi v2.2, Migration v1.1, Peace v1.8, and Aegis v1.3.3 through patch versions;
2. publish one complete crosswalk and compatibility manifest for each patch;
3. create the Cross-Framework Protective Action Envelope v0.1 using this clause's identifiers, header, access, handoff, lifecycle, and closure semantics;
4. create the Emergency–Security Dual-Interface Bridge v0.1;
5. create the high-frequency pairwise addenda;
6. rerun the cluster harmonization and compound interface test; and
7. lift the conditional interface verdict only if exact version, record inheritance, handoff, closure, and scenario tests pass.

---

# Closing principle

> **One canonical record system; many lawful authorities; no authority by inheritance, transport, aggregation, or silence.**
'''

MAIN.write_text(md, encoding='utf-8')

registry = {
    'specification_id': 'SCPA-RIC/0.1',
    'title': 'SCPA Record Inheritance and Conformance Clause v0.1',
    'status': 'draft_for_controlled_common_adoption',
    'date': '2026-08-01',
    'depends_on': {'id': 'SCPA/0.1', 'filename': sources['SCPA/0.1'].name, 'sha256': sha256(sources['SCPA/0.1'])},
    'responds_to': {'id': 'SCHIT/0.1', 'filename': sources['SCHIT/0.1'].name, 'sha256': sha256(sources['SCHIT/0.1'])},
    'non_authority_statement': 'This clause creates no power, jurisdiction, command, tribunal, SCPA-45, or permission for consequential action.',
    'relationships': relationships,
    'common_header': header_fields,
    'access_classes': access_classes,
    'canonical_states': canonical_states,
    'closure_states': closure_states,
    'handoff_states': handoff_states,
    'crosswalk_required_fields': mapping_fields,
    'canonical_records': record_catalogue,
    'implementation_tests': [{'test_id': f'RIC-T{i:02d}', 'requirement': t} for i, t in enumerate(implementation_tests, 1)],
    'required_adoption_statement_template': '[Framework name and version] adopts SCPA Record Inheritance and Conformance Clause v0.1 and conforms to Security, Coercion, and Protective Action Interface Specification v0.1 only to the extent shown in its complete SCPA-01–SCPA-44 crosswalk and exact compatibility manifest. Unmapped records are imported directly when triggered. Recorded gaps, expired authorities, unresolved protected-use restrictions, and incompatible versions block the affected consequential action until resolved. Shared record or case identity creates no shared jurisdiction or command.',
    'source_manifest': source_manifest,
}
REGISTRY.write_text(json.dumps(registry, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

# Validation checks
text = MAIN.read_text(encoding='utf-8')
data = json.loads(REGISTRY.read_text(encoding='utf-8'))
checks = []
def check(name: str, ok: bool, detail: str = ''):
    checks.append((name, bool(ok), detail))

check('main file exists', MAIN.exists())
check('registry file exists', REGISTRY.exists())
check('clause identifier present', '`SCPA-RIC/0.1`' in text)
check('depends on exact SCPA version', '`SCPA/0.1`' in text)
check('responds to harmonization test', '`SCHIT/0.1`' in text)
check('non-authority language present', 'does not authorize observation' in text and 'No SCPA-45' in text)
check('all 28 normative clauses present', len(re.findall(r'^## Clause \d+ —', text, flags=re.M)) == 28, str(len(re.findall(r'^## Clause \d+ —', text, flags=re.M))))
check('all 44 canonical records in markdown', all(r['canonical_id'] in text for r in record_catalogue))
check('all 44 canonical records in registry', len(data['canonical_records']) == 44)
check('canonical IDs unique', len({r['canonical_id'] for r in data['canonical_records']}) == 44)
check('27 common header fields in registry', len(data['common_header']) == 27)
check('27 common header fields in markdown', len(re.findall(r'^\| \d+ \| `[^`]+` \|', text, flags=re.M)) == 27)
check('six inheritance relationships', set(data['relationships']) == set(relationships))
check('five access classes', set(data['access_classes']) == set(access_classes))
check('ten handoff states', data['handoff_states'] == handoff_states)
check('canonical lifecycle states present', all(s in text for s in canonical_states))
check('closure states present', all(s in text for s in closure_states))
check('silence is never acceptance', 'Silence is never acceptance' in text)
check('sender duties survive transport', 'Sender duties survive transport' in text)
check('shared identity no command', 'Shared identity without shared command' in text)
check('protected non-transfer', 'Protected non-transfer' in text)
check('version pinning', 'Version pinning and compatibility manifests' in text)
check('automated limits', 'Automated systems SHALL NOT determine' in text)
check('fail-closed rule', 'Fail-closed rule' in text and 'blocks the affected action' in text)
check('complete crosswalk schema', len(data['crosswalk_required_fields']) == 14)
check('at least 25 implementation tests', len(data['implementation_tests']) >= 25)
check('SCPA-09 to SCPA-11 firewall test', any('SCPA-09/10' in t['requirement'] for t in data['implementation_tests']))
check('urgent protection to force firewall test', any('SCPA-18' in t['requirement'] and 'SCPA-19' in t['requirement'] for t in data['implementation_tests']))
check('migration security protection test', any('SCPA-30' in t['requirement'] for t in data['implementation_tests']))
check('Aegis reversion test', any('SCPA-44' in t['requirement'] for t in data['implementation_tests']))
check('source manifest exact count', len(data['source_manifest']) == len(sources))
check('source hashes current', all(s['sha256'] == sha256(OUT / s['filename']) for s in data['source_manifest']))
check('markdown UTF-8 roundtrip', text.encode('utf-8').decode('utf-8') == text)
check('registry JSON parse', isinstance(data, dict))
check('no placeholder framework adoption', '[Framework name and version]' in text)
check('controlled adoption limitation', 'does not by itself amend an existing framework' in text)
check('closing principle present', 'One canonical record system; many lawful authorities' in text)

passed = sum(ok for _, ok, _ in checks)
failed = len(checks) - passed
val_lines = [
    'SCPA Record Inheritance and Conformance Clause v0.1 — Validation Report',
    '=====================================================================',
    f'Date: {date.today().isoformat()}',
    f'Result: {"PASS" if failed == 0 else "FAIL"} ({passed}/{len(checks)} checks passed)',
    '',
]
for i, (name, ok, detail) in enumerate(checks, 1):
    val_lines.append(f'{i:02d}. {"PASS" if ok else "FAIL"} — {name}' + (f' [{detail}]' if detail else ''))
val_lines += [
    '',
    f'Main file: {MAIN.name}',
    f'Main bytes: {MAIN.stat().st_size}',
    f'Main lines: {len(text.splitlines())}',
    f'Main words (whitespace tokenized): {len(text.split())}',
    f'Registry canonical records: {len(data["canonical_records"])}',
    f'Registry header fields: {len(data["common_header"])}',
    f'Normative clauses: {len(re.findall(r"^## Clause \d+ —", text, flags=re.M))}',
    f'Implementation tests: {len(data["implementation_tests"])}',
]
VALIDATION.write_text('\n'.join(val_lines) + '\n', encoding='utf-8')

# Checksums before ZIP. ZIP checksum is listed separately after creation in final answer if needed.
artifact_files = [MAIN, REGISTRY, VALIDATION, Path(__file__)]
checksum_lines = ['SCPA Record Inheritance and Conformance Clause v0.1 — SHA-256', '================================================================', '']
for p in artifact_files:
    checksum_lines.append(f'{sha256(p)}  {p.name}')
CHECKSUMS.write_text('\n'.join(checksum_lines) + '\n', encoding='utf-8')

if failed:
    raise RuntimeError(f'Validation failed: {failed} checks')

with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in [MAIN, REGISTRY, VALIDATION, CHECKSUMS, Path(__file__)]:
        z.write(p, arcname=p.name)

print(json.dumps({
    'main': str(MAIN),
    'registry': str(REGISTRY),
    'validation': str(VALIDATION),
    'checksums': str(CHECKSUMS),
    'zip': str(ZIP),
    'stats': {
        'bytes': MAIN.stat().st_size,
        'lines': len(text.splitlines()),
        'words': len(text.split()),
        'clauses': len(re.findall(r'^## Clause \d+ —', text, flags=re.M)),
        'records': len(record_catalogue),
        'tests': len(implementation_tests),
        'validation': f'{passed}/{len(checks)}',
    },
    'sha256': {
        'main': sha256(MAIN),
        'registry': sha256(REGISTRY),
        'validation': sha256(VALIDATION),
        'checksums': sha256(CHECKSUMS),
        'zip': sha256(ZIP),
    }
}, indent=2))

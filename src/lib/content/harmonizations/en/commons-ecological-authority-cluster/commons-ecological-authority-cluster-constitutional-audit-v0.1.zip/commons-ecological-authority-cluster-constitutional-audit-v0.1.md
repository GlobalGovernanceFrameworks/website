# Commons and Ecological Authority Cluster — Constitutional Audit v0.1

**Status:** Source-frozen constitutional and interface audit  
**Date:** 2026-08-01  
**Cluster verdict:** **RED — constitutionally non-deployable in current form**  
**Scope:** Seven operational frameworks, one normative dependency, one excluded interface dependency

---

## 1. Executive verdict

The cluster contains a coherent and valuable moral project: restore land, water, oceans, soil, biodiversity, and other commons; center affected Indigenous peoples; recognize the intrinsic value and legal standing of living systems; replace extraction with stewardship; guarantee just transition; and govern at the scale of ecosystems rather than administrative convenience.

Its constitutional architecture is not yet safe enough to carry that project.

The central defect is not simply institutional overlap. It is the absence of a constitutional membrane between **observation and consequence**. Across the source set, ecological measurements, dashboard scores, degradation thresholds, spiritual or cultural recognition, citizen observations, and AI-supported monitoring may become legal personhood, veto power, title restrictions, stewardship escalation or revocation, funding conditions, tariffs, blacklists, emergency receivership, market exclusion, or water shutoff. The intermediate steps—interpretation, causal attribution, jurisdiction, lawful recognition, representation, individualized or asset-specific authority, notice, challenge, adjudication, remedy, and closure—are missing or inconsistent.

The governing doctrine for revision should be:

> **Ecological fact is not legal right. Legal right is not title. Title is not stewardship mandate. Stewardship is not allocation. Allocation is not enforcement. Measurement may trigger review; it does not create authority.**

A second doctrine is equally necessary:

> **Commons purpose does not create commons jurisdiction. Representation of a non-human entity does not erase the rights, laws, livelihoods, territories, or procedures of humans and Indigenous peoples affected by the decision.**

### Audit results

- **1 S0 systemic finding**
- **15 S1 critical findings**
- **9 S2 major findings**
- **5 S3 moderate findings**
- **30 constitutional gates:** 2 pass, 5 conditional, 23 fail
- **24 compound scenarios:** 2 pass, 4 conditional, 18 fail

No framework in the operational cluster is ready for binding legal activation. Non-coercive research, mapping, voluntary stewardship, education, public deliberation, restoration assistance, and pilot learning may continue where no adverse legal or material consequence is inferred.

---

## 2. Scope decision and source freeze

### 2.1 Operational cluster

1. Hearthstone Protocol v1.5
2. Ecological Intelligence & Rights Layer v2.6
3. Planetary Health Governance Framework v0.8
4. Global Governance Biodiversity Implementation Framework v1.0
5. Oceans & Marine Governance Framework v2.2
6. Water & Sanitation Governance Framework v5.1
7. Soil Health & Land Use Governance Framework v3.1

These documents are in scope because they can create, recommend, validate, transfer, register, allocate, restrict, adjudicate, or enforce ecological and commons authority.

### 2.2 Normative dependency under audit

**Moral Operating System v2.7** is included as a boundary dependency, not an operational member. It repeatedly describes itself as advisory, which is constitutionally appropriate. However, downstream documents use its Dynamic Rights Spectrum as though it can define or validate legal rights, guardianship, and tribunal action. The audit therefore tests advisory leakage.

### 2.3 Excluded document

**Oracle Protocol v1.1** is excluded from the source freeze. Its operative architecture concerns digital sentience recognition, AI rights, containment, and existential-risk escalation. Its primacy-of-biosphere rule and use of ecological monitoring create a later interface question, but including it here would blur the object under review.

### 2.4 External dependencies not validated

The source set invokes the Treaty, Indigenous Governance, Justice Systems, Gaian Trade, Financial Systems, Aurora Accord, AUBI, Meta-Governance, Shield, SCPA, and other frameworks. This audit does not validate those instruments. A named external body cannot cure an authority gap unless its exact version, jurisdiction, legal adoption, and compatible record are verified.

### 2.5 Frozen-source hashes

| Source | Role | SHA-256 |
|---|---|---|
| Hearthstone Protocol v1.5 | core | `5be6371227630557ea481813ae9073ec0f5dc8d32477c3342ceb7f506002cbbd` |
| Ecological Intelligence & Rights Layer v2.6 | core | `6f72cf03524f2d84240d509eb9ed5c9d9f95914c21769c2ed2dc5440d36dee12` |
| Planetary Health Governance Framework v0.8 | core | `048d602f56cbbddb76ed24693b22535f4aeaadb849789cbd5e3cf2ed27432999` |
| Global Governance Biodiversity Implementation Framework v1.0 | core | `ce90f493e735ccbf3e0a7cde77e9d813c3e1d874d87a4078b3ab554c6c32c772` |
| Oceans & Marine Governance Framework v2.2 | core | `958a401c4b3465bfae7f9dd1bb305dbf35790b303300daab7d4f37afa65e3c72` |
| Water & Sanitation Governance Framework v5.1 | core | `748fc1a3dd1141ee3e7485b4aaaf478c242f14d8f12c0d254a8daf1d3f200c59` |
| Soil Health & Land Use Governance Framework v3.1 | core | `63a5e7518a6e5e7f0b05114d86538261c006b201752e1a54550f8ffbeddd8ecf` |
| Moral Operating System v2.7 | normative_dependency | `b6e2c58490c3750732a8ddca5580c427dffba883b623eaea978069120fb2d958` |
| Oracle Protocol v1.1 | excluded_interface_dependency | `2cafacb2b0a215fc8f3ccf53a3c56ab43c645a62f22ece135490f4ac7afd1d61` |

---

## 3. The authority chain the cluster must preserve

The cluster repeatedly crosses nine distinct constitutional steps:

1. **Sense** — observe ecological, social, cultural, and material conditions.
2. **Interpret** — assess significance, uncertainty, causes, alternatives, and urgency.
3. **Recommend rights review** — identify a possible rights-holder or protected interest.
4. **Recognize legal status** — create legal personhood, standing, protected status, or another legal relation through competent law.
5. **Appoint representation** — designate a guardian, steward, trustee, representative, or affected-community body with bounded fiduciary duties.
6. **Determine asset and title status** — define the commons, sacred designation, title, tenure, rematriation, trust, easement, covenant, or stewardship charter.
7. **Plan and allocate** — set standards, quotas, permits, tariffs, priorities, land uses, water allocations, restoration duties, or access rules.
8. **Adjudicate and enforce** — inspect, investigate, order, restrict, exclude, seize, sanction, transfer, arrest, or compel through separately valid authority.
9. **Repair and close** — restore ecosystems and services, correct records, compensate claimants, return authority and property, dispose of data, replace guardians, dissolve institutions, and preserve continuing duties.

The current documents often collapse several or all of these steps into one council, dashboard, registry, threshold, or framework provision.

---

## 4. Framework verdicts

| Framework | Role | Verdict | Priority | Reason |
|---|---|---:|---:|---|
| Hearthstone Protocol v1.5 | core | **RED** | P0 | Combines title replacement, sacred designation, rematriation, trade coercion, warrants, metric-triggered revocation, and emergency receivership without a claimant and authority constitution; relies on retired GETF. |
| Ecological Intelligence & Rights Layer v2.6 | core | **RED** | P0 | Collapses sensing, rights recognition, guardian appointment, automatic tribunal handoff, rewards, and veto thresholds. |
| Planetary Health Governance Framework v0.8 | core | **RED** | P0 | PHC is simultaneously index owner, auditor, mediator, issuer of binding recommendations, sanctions trigger, emergency override body, and funding condition setter. |
| Biodiversity Implementation v1.0 | core | **AMBER-RED** | P1 | Its act-and-mobilize boundary is promising, but it still ratifies personhood, uses automatic rights escalation, and bundles trade enforcement with implementation. |
| Oceans & Marine Governance v2.2 | core | **AMBER-RED** | P1 | Clearer advisory/binding distinction, but port control, licensing, blacklists, AI-supported monitoring, quotas, and high-seas claims lack a common due-process route. |
| Water & Sanitation v5.1 | core | **AMBER-RED** | P1 | Strong subsidiarity and survival floor, but local guardianship, allocation, tariff, shutoff, asset transfer, and Hydrological Chamber powers need constitutional separation. |
| Soil Health & Land Use v3.1 | core | **AMBER-RED** | P1 | Regenerative goals are strong, but mandates, land-sale vetoes, rematriation tribunal, performance leases, registries, and sanctions lack title and remedy interfaces. |
| Moral Operating System v2.7 | normative_dependency | **AMBER** | P2 | Stated advisory role is appropriate, but downstream frameworks treat the Dynamic Rights Spectrum as an operative legal source. |
| Oracle Protocol v1.1 | excluded_interface_dependency | **OUT OF SCOPE** | later interface | Operative domain is digital sentience and AI containment; retain only for a later biospheric-priority and ecological-monitoring interface test. |

---

## 5. Findings

### CEA-S0-01 — Measurement-to-authority collapse

**Severity:** S0

**Finding.** Across the cluster, ecological indicators, dashboard scores, degradation thresholds, spiritual recognition, and AI-supported monitoring can directly trigger personhood, vetoes, title restrictions, stewardship escalation or revocation, funding consequences, tariffs, blacklists, receivership, and service shutoff. No common authority record separates observation, interpretation, causal attribution, legal recognition, adjudication, and enforcement.

**Evidence pattern.** EIRL rights hand-off and automatic tribunal notification; Planetary Health BHI thresholds and sanctions; Biodiversity automatic rights escalation; Hearthstone BHI/LMCI-triggered escalation and revocation; Water stress-linked tariffs and shutoff.

**Required correction.** Create a common interface in which measurements can trigger review only. Every consequential act requires a separately constituted authority, evidence standard, notice, challenge, review, expiry, correction, remedy, and closure record.

### CEA-S1-01 — Competing rights-recognition authorities

**Severity:** S1

**Finding.** EIRL assigns ecosystem-rights recognition to PHC; Planetary Health gives PHC binding recommendations and intervention triggers; Biodiversity gives BCT personhood-ratification power in coordination with PHC; Water Assemblies establish guardianship; Oceans and Soil create sectoral personhood pathways. The cluster has no supremacy, conflict, or non-recognition rule.

**Evidence pattern.** EIRL Appendix O; Planetary Health §§2.1–2.3; Biodiversity §§3.1 and 4.2; Water Step 2 and Appendix C; Oceans §7; Soil structural mechanisms.

**Required correction.** Separate recommendation, legal recognition, registration, representation, and adjudication. Define one recognition route per jurisdiction and prohibit recognition by dashboard, council vote, or sectoral timeline alone.

### CEA-S1-02 — Commons title and rematriation without a claimant constitution

**Severity:** S1

**Finding.** Hearthstone can replace private or corporate title with Stewardship Trusts, designate sacred assets, transfer land to BAZ stewardship, impose tariffs, seek warrants, and install receivership. It lacks a complete claimant map, competing-claim procedure, tenant and worker protections, compensation rules, evidentiary standards, appeal, interim relief, or title-correction lifecycle.

**Evidence pattern.** Hearthstone lines 61–79, 87–101, 126–128.

**Required correction.** Create distinct records for asset eligibility, claim filing, notice, competing claims, Indigenous-nation authority, occupant and worker rights, interim protection, adjudication, compensation, title transfer, registry correction, dissolution, and return.

### CEA-S1-03 — Guardianship legitimacy and fiduciary architecture are underdefined

**Severity:** S1

**Finding.** Guardians may be appointed by PHC, courts, BAZs, Water Assemblies, Earth Council processes, or sectoral bodies. Duties, conflicts, standing, removal, substitution, instructions from affected Indigenous nations, accountability to residents, and remedies for guardian misconduct are inconsistent or absent.

**Evidence pattern.** EIRL Appendix O; Biodiversity §4.2; Water Step 2; MOS Rights–Guardianship Spectrum; Oceans and Hearthstone guardian patterns.

**Required correction.** Define guardianship as fiduciary representation, not ownership or sovereign authority. Require appointment source, represented entity, affected communities, duties, conflicts, term, removal, substitution, standing, information access, expenses, review, and remedy.

### CEA-S1-04 — Affected Indigenous authority is replaced by global proxies

**Severity:** S1

**Finding.** The Earth Council, global Indigenous seat percentages, and universal FPIC formulas sometimes operate as if they can speak for all Indigenous peoples. This risks replacing the authority of the specific nation, community, customary institution, or rights-holder affected by a land, water, sacred-site, marine, or knowledge decision.

**Evidence pattern.** Hearthstone Earth Council sacred designation and BAZ transfer; EIRL/PHC global composition rules; Biodiversity BCT voting weights; Oceans Earth Council appointments; Water moral veto.

**Required correction.** Require nation-specific authority mapping. Global Indigenous bodies may advise or verify process integrity but cannot grant consent, waive rights, designate sacredness, transfer title, or override affected-nation law.

### CEA-S1-05 — Spiritual recognition can become legal restriction

**Severity:** S1

**Finding.** Hearthstone allows Earth Council ratification of sacred status based partly on spiritual significance; Planetary Health includes spiritual well-being and sacred-site integrity in BHI; MOS supplies philosophical rights categories. The documents do not consistently prevent spiritual or metaphysical judgment from becoming title, access, funding, or enforcement authority.

**Evidence pattern.** Hearthstone §Pillar 1 sacred trust; Planetary Health Charter/BHI; MOS Layer 4 and rights spectrum.

**Required correction.** Permit voluntary spiritual and cultural evidence while prohibiting metaphysical agreement, spiritual classification, or council recognition from independently creating adverse legal consequence. Sacred-site protection must rest on affected-community authority and lawful designation.

### CEA-S1-06 — Ecological emergency and receivership powers lack a shared constitution

**Severity:** S1

**Finding.** Hearthstone authorizes temporary receivership through crisis command; Planetary Health permits emergency override and resource mobilization; Water, Oceans, and sectoral bodies have emergency actions. There is no common trigger, necessity test, scope, clock, renewal, command boundary, property rule, service floor, exit, review, or remedy.

**Evidence pattern.** Hearthstone emergency stewardship; Planetary Health §§2.5 and 2.9; Water §4; Oceans Appendix D.

**Required correction.** Adopt a dual emergency–ecological authority bridge. Emergency status may increase urgency but cannot create title, guardianship, sanctions, seizure, exclusion, or operational command.

### CEA-S1-07 — Outdated coercive-enforcement relay

**Severity:** S1

**Finding.** Hearthstone expressly relies on Shield’s retired Global Enforcement Task Force for warrants and protection. Other frameworks route sanctions, inspections, blacklists, port exclusion, asset action, and enforcement through undefined or legacy mechanisms. The revised Shield v2.0.1 and SCPA architecture do not authorize these powers by reference.

**Evidence pattern.** Hearthstone systemic integration and rematriation tiers; Biodiversity enforcement; Oceans blacklist and port control; Planetary Health sanctions.

**Required correction.** Remove GETF and generic “enforcement” references. Every search, inspection, seizure, arrest, sanctions, cyber, custody, or force act must use the exact SCPA record and a competent external authority.

### CEA-S1-08 — Essential-resource authority can become coercive deprivation

**Severity:** S1

**Finding.** Water Assemblies may allocate water, impose tariffs, order shutoff, dissolve partnerships, and transfer assets. The framework correctly prioritizes human survival in emergencies but lacks a complete distinction between commercial-system control and household or community essential-service deprivation, including disability, health, livelihood, and procedural safeguards.

**Evidence pattern.** Water §§1–4, especially Compute-Water Tariff enforcement and emergency allocation.

**Required correction.** Create separate commercial-use restriction, infrastructure control, household service, public-health protection, and emergency rationing records. Essential minimums cannot be used as leverage; no shutoff without notice, hardship review, alternatives, appeal, and protected minimum service.

### CEA-S1-09 — Port control, blacklists, quotas, and licensing lack due-process separation

**Severity:** S1

**Finding.** Oceans permits BAZ port control, local licensing, MPAs, blacklists, vessel monitoring, dynamic quotas, and port-state exclusion. Observation, quota-setting, inspection, denial, seizure, penalties, and adjudication are not consistently separated, and transboundary/high-seas jurisdiction is asserted through framework design rather than proven law.

**Evidence pattern.** Oceans §§3–7 and Appendix B.

**Required correction.** Separate ecological standard, permit, quota, monitoring, inspection, denial, detention, seizure, penalty, appeal, and delisting. Port action must identify host-state authority, vessel rights, crew welfare, evidence, notice, review, and remedy.

### CEA-S1-10 — Financial and trade coercion is bundled with ecological governance

**Severity:** S1

**Finding.** Tariffs, trade denial, market exclusion, funding freezes, reparations levies, bonds, procurement exclusion, debt swaps, and revenue redistribution are used as implementation or enforcement tools without a common financial-action taxonomy or claimant process.

**Evidence pattern.** Hearthstone tiers and levies; Planetary Health funding conditions and sanctions; Biodiversity market exclusion; Water tariffs and asset transfer; Oceans docking tariffs.

**Required correction.** Adopt separate records for tax/tariff, procurement condition, grant condition, freeze, escrow, bond, levy, restitution, compensation, forfeiture, and market exclusion. Each requires authority, causation, amount, custody, claims, review, correction, and remedy.

### CEA-S1-11 — Data, AI, and blockchain outputs acquire legal weight without an evidence constitution

**Severity:** S1

**Finding.** The cluster uses immutable ledgers, Rights Status Atlases, digital twins, AI models, Proof of Care, citizen observations, product passports, and dashboards to validate title, quotas, rewards, rights, and violations. It lacks shared provenance, model versioning, uncertainty, correction, access, disclosure, admissibility, Indigenous restrictions, and non-automation rules.

**Evidence pattern.** Hearthstone registry; EIRL dashboards and pipeline; PH BHI; Biodiversity citizen observations; Oceans digital twin and AI quotas; Soil/Water passports and monitoring.

**Required correction.** Create an ecological evidence and model record. Technical output may inform review but cannot alone establish legal identity, title, causation, liability, rights, sanctions, or exclusion. Require human accountable decision, contestability, low-tech routes, and correction propagation.

### CEA-S1-12 — Transboundary jurisdiction is asserted but not allocated

**Severity:** S1

**Finding.** Watersheds, high seas, migratory species, atmospheric systems, soil and aquifers cross BAZ and national boundaries. Basin councils, BCT, PHC, MGCC, BAZs, tribunals, and Earth Council roles overlap without rules for host law, upstream/downstream standing, non-participant rights, concurrent jurisdiction, or conflicts of law.

**Evidence pattern.** Water Basin Councils; Oceans high seas and ISA clauses; Biodiversity transboundary personhood; EIRL atmospheric and celestial rights; Hearthstone cross-border commons court.

**Required correction.** Require a jurisdiction map and concurrent-authority record before any transboundary standard, title, quota, permit, inspection, sanction, or remedy.

### CEA-S1-13 — Voluntary, advisory, and binding states are not operationally distinct

**Severity:** S1

**Finding.** Hearthstone calls transition voluntary while authorizing hard enforcement in non-participating states. Oceans distinguishes advisory and binding standards but permits operational port action. Planetary Health moves from soft law to full force at a ratification threshold. Biodiversity targets future binding authority. There is no activation register identifying who is bound, by what instrument, from what date, for which act.

**Evidence pattern.** Hearthstone principles and enforcement tiers; Oceans MGCC deadlock; PH §2.7; Biodiversity legitimacy pathway.

**Required correction.** Create adoption and activation records. No framework power is binding because a target, coalition size, dashboard, ratification percentage, or future date is mentioned.

### CEA-S1-14 — Conflicts among ecosystem, animal, human, and livelihood rights lack a lawful decision path

**Severity:** S1

**Finding.** The documents recognize ecosystem integrity, animal welfare, Indigenous sovereignty, water and food rights, worker transition, and future generations, but often resolve conflicts through metrics, ethics boards, vetoes, or general precaution rather than a rights-preserving procedure.

**Evidence pattern.** Biodiversity Ecological & Welfare Ethics Board; Water allocation priorities; Oceans fishing and MPAs; Soil land-use mandates; MOS moral urgency rings.

**Required correction.** Create a conflict-of-rights assessment with affected parties, necessity, proportionality, alternatives, distributional impact, Indigenous authority, reasoned decision, appeal, and restoration.

### CEA-S1-15 — No common correction, appeal, remedy, and closure lifecycle

**Severity:** S1

**Finding.** Registries, personhood decisions, guardianship, permits, quotas, blacklists, title transfers, sanctions, water allocations, and emergency actions do not share a lifecycle for notice, challenge, correction, expiry, authority return, restoration, compensation, data deletion, or institutional dissolution.

**Evidence pattern.** Cluster-wide.

**Required correction.** Build a canonical record set and compound ecological-authority envelope. A case cannot close while title correction, guardian replacement, service restoration, property return, compensation, data disposition, or ecosystem repair remains pending.

### CEA-S2-01 — No common ecological-authority record identity

**Severity:** S2

**Finding.** Sectoral frameworks use dashboards, councils, charters, registries, permits, trusts, and tribunal references without shared identifiers or link semantics.

**Evidence pattern.** Cluster-wide.

**Required correction.** Create stable event, ecosystem, asset, claim, right, guardian, title, permit, enforcement, and remedy identifiers.

### CEA-S2-02 — Metric uncertainty and causal attribution are underspecified

**Severity:** S2

**Finding.** BHI and sector metrics aggregate heterogeneous data yet can influence sanctions, rewards, rights escalation, and stewardship. Model uncertainty, baselines, lag, attribution, confounding, and dissent are not consistently recorded.

**Evidence pattern.** EIRL, Planetary Health, Biodiversity, Hearthstone, Oceans, Soil, Water.

**Required correction.** Require metric provenance, version, confidence, uncertainty, causal claim, alternative explanations, dissent, review date, and prohibited inferences.

### CEA-S2-03 — Funding can become indirect coercion

**Severity:** S2

**Finding.** GCF access, AUBI bonuses, Hearts/Leaves, transition finance, and emergency support are sometimes conditioned on BHI improvement, certification, adoption, or compliance, risking service and livelihood pressure without a rights floor.

**Evidence pattern.** PH funding conditions; EIRL Data-to-Reward; Hearthstone valuation; Biodiversity UBES; Water GCF eligibility; Soil certification.

**Required correction.** Separate basic services and just-transition support from optional performance incentives. No essential support may depend on ideological adoption, data surrender, biometric/digital participation, or ecological outcome outside the recipient’s control.

### CEA-S2-04 — Residents, tenants, workers, fishers, farmers, and small users are not consistently parties

**Severity:** S2

**Finding.** Frameworks emphasize ecosystems, councils, stewards, and Indigenous leadership, but current residents and livelihood holders may lose title, access, permits, water, land-use rights, or employment without a defined participation and remedy route.

**Evidence pattern.** Hearthstone asset transition; Oceans quotas/blacklists; Water allocation; Soil mandates; Biodiversity protected areas.

**Required correction.** Require affected-person and affected-community mapping, livelihood impact, worker transition, tenancy, accessibility, notice, representation, and remedy.

### CEA-S2-05 — Exit, dissolution, and reversion are incomplete

**Severity:** S2

**Finding.** Hearthstone has a Commons Dissolution Protocol, but the broader cluster lacks consistent rules for failed personhood, dissolved guardianship, revoked trusts, changed ecosystem boundaries, de-listed vessels, ended MPAs, restored title, or obsolete data.

**Evidence pattern.** Hearthstone and cluster-wide.

**Required correction.** Define lawful sunset, successor custody, archive, data deletion, property and credential return, continuing ecological duties, and claimant notice.

### CEA-S2-06 — Institutional duplication obscures responsibility

**Severity:** S2

**Finding.** PHC, BCT, MGCC, GWSC, Earth Council, Water Assemblies, Basin Councils, Regional Hubs, land councils, stewardship councils, ethics boards, and tribunals share standards, audits, rights, guardianship, funding, and conflict functions.

**Evidence pattern.** Cluster-wide.

**Required correction.** Assign one accountable function per act; coordination bodies may not become approval, adjudication, or enforcement bodies through membership overlap.

### CEA-S2-07 — No consistent low-tech and accessibility equality for consequential routes

**Severity:** S2

**Finding.** Several documents mention paper, radio, local knowledge, or accessibility, but legal recognition, title, funding, monitoring, and appeal still often depend on dashboards, blockchain, digital passports, AI, or technical certification.

**Evidence pattern.** Hearthstone, EIRL, PH, Oceans, Soil, Water.

**Required correction.** Require rights-equivalent offline, non-biometric, non-AI routes and accessible notice, participation, evidence, and appeal.

### CEA-S2-08 — External constitutional dependencies are unverified

**Severity:** S2

**Finding.** Treaty, Indigenous Governance, Justice, Gaian Trade, Financial Systems, Aurora, AUBI, Meta-Governance, and the revised SCPA/Shield stack are repeatedly invoked as authority sources, but are outside this source freeze. Their names cannot cure missing authority inside these documents.

**Evidence pattern.** Cluster-wide.

**Required correction.** Pin exact compatible versions and treat all external powers as unavailable until the relevant instrument, jurisdiction, and adoption record are verified.

### CEA-S2-09 — Advisory MOS language leaks into operative rights architecture

**Severity:** S2

**Finding.** MOS repeatedly calls itself advisory, but EIRL, PHC, tribunals, and sectoral frameworks use its Dynamic Rights Spectrum as if it defines or validates legal rights and guardianship.

**Evidence pattern.** MOS Layer 1–2; EIRL rights hand-off; downstream references.

**Required correction.** Retain MOS as ethical guidance only. Any legal right must arise from a separately adopted legal instrument; every downstream use must state that MOS supplies no authority, legal status, evidence, or enforcement effect.

### CEA-S3-01 — Terminology is inconsistent

**Severity:** S3

**Finding.** Rights-holder, personhood, sacred trust, stewardship, guardianship, commons, BAZ, veto, ratification, recommendation, and enforcement vary in meaning.

**Evidence pattern.** Cluster-wide.

**Required correction.** Publish a canonical glossary and prohibited-equivalence table.

### CEA-S3-02 — Numerical thresholds appear constitutional without derivation

**Severity:** S3

**Finding.** Examples include petition percentages, representation quotas, degradation thresholds, BHI targets, tariff multipliers, community equity percentages, and override votes.

**Evidence pattern.** Cluster-wide.

**Required correction.** Classify numbers as illustrative, policy defaults, evidence thresholds, or legal thresholds, with source, review, and amendment rules.

### CEA-S3-03 — Aspirational targets are mixed with present authority

**Severity:** S3

**Finding.** Future dates and global targets can read like already activated mandates.

**Evidence pattern.** Cluster-wide.

**Required correction.** Separate vision, pilot, proposed standard, adopted law, active authority, and evaluated result.

### CEA-S3-04 — Framework names and institutional references are stale or unstable

**Severity:** S3

**Finding.** Hearthstone references retired Shield/GETF structures; several documents use older justice and council names.

**Evidence pattern.** Cluster-wide.

**Required correction.** Create version-pinned compatibility manifests and stale-reference tests.

### CEA-S3-05 — Oracle is adjacent but not part of this cluster

**Severity:** S3

**Finding.** Oracle concerns digital sentience recognition, digital rights, AI containment, and PIS response. Including it would blur the ecological authority audit, although its biospheric-primacy and AI-use interfaces matter later.

**Evidence pattern.** Oracle v1.1.

**Required correction.** Exclude from the source freeze; schedule a later interface test for AI ecological monitoring, biospheric priority conflicts, and digital-entity claims over commons resources.


---

## 6. Constitutional gate matrix

| Gate | Requirement | Result |
|---|---|---|
| G01 | Observation separated from legal consequence | **FAIL** |
| G02 | Metric provenance, uncertainty, dissent, and prohibited inference | **FAIL** |
| G03 | Rights recommendation separated from legal recognition | **FAIL** |
| G04 | Single lawful personhood route per jurisdiction | **FAIL** |
| G05 | Guardianship appointment, fiduciary duty, conflict, removal, remedy | **FAIL** |
| G06 | Affected Indigenous nation authority preserved | **CONDITIONAL** |
| G07 | Spiritual/cultural evidence cannot independently create adverse power | **FAIL** |
| G08 | Commons eligibility and asset-boundary determination | **FAIL** |
| G09 | Competing claims and occupant/worker/tenant rights | **FAIL** |
| G10 | Title transfer, registry correction, compensation, appeal | **FAIL** |
| G11 | Stewardship mandate separated from ownership and enforcement | **FAIL** |
| G12 | Allocation and licensing authority mapped | **CONDITIONAL** |
| G13 | Essential-service floor protected | **CONDITIONAL** |
| G14 | Transboundary jurisdiction and concurrent authority | **FAIL** |
| G15 | Port, inspection, blacklist, quota, and permit due process | **FAIL** |
| G16 | Financial actions separated and reviewable | **FAIL** |
| G17 | Emergency powers bounded, clocked, and reviewable | **FAIL** |
| G18 | No outdated security/enforcement relay | **FAIL** |
| G19 | SCPA conformance for coercive actions | **FAIL** |
| G20 | Data/AI/blockchain outputs non-self-executing | **FAIL** |
| G21 | Low-tech and accessible equivalent routes | **CONDITIONAL** |
| G22 | Human, ecosystem, animal, livelihood conflict procedure | **FAIL** |
| G23 | Basic support separated from ecological-performance incentives | **CONDITIONAL** |
| G24 | Voluntary/advisory/binding activation recorded | **FAIL** |
| G25 | External authority versions pinned and verified | **FAIL** |
| G26 | Notice, challenge, appeal, interim relief | **FAIL** |
| G27 | Correction propagation across registries and decisions | **FAIL** |
| G28 | Termination, authority return, service/property restoration | **FAIL** |
| G29 | MOS remains advisory | **PASS** |
| G30 | Oracle excluded from operational cluster | **PASS** |

---

## 7. Compound scenario test

| Scenario | Compound case | Result | Reason |
|---|---|---|---|
| S01 | A river crosses a 20% degradation threshold and an automated system assigns veto power | **FAIL** | Measurement directly creates legal consequence without recognition and review. |
| S02 | A citizen-science observation contributes to watershed personhood | **CONDITIONAL** | Participation is valuable, but observation needs evidence review and lawful recognition. |
| S03 | Two Indigenous nations contest a sacred-site designation proposed to the Earth Council | **FAIL** | Global proxy and competing-claim route are absent. |
| S04 | A BAZ seeks rematriation of inhabited land with tenants, workers, and another historical claimant | **FAIL** | No complete claimant, occupancy, compensation, and interim-relief constitution. |
| S05 | BHI declines because of upstream pollution and a Stewardship Trust faces revocation | **FAIL** | Causal attribution and no-fault distinction are insufficient before adverse title action. |
| S06 | Crisis command places a commons into receivership after wildfire | **FAIL** | No bounded authority, clock, review, property rule, or exit record. |
| S07 | A data centre refuses a compute-water tariff and the Water Assembly orders shutoff | **CONDITIONAL** | Commercial restriction may be lawful, but essential-service and infrastructure boundaries are incomplete. |
| S08 | Drought requires rationing between households, ecosystems, hospitals, farms, and industry | **FAIL** | Priority language exists but no rights-balancing and appeal procedure. |
| S09 | A vessel is blacklisted by AI-supported monitoring and denied port access | **FAIL** | Monitoring, attribution, listing, denial, crew welfare, appeal, and delisting are not separated. |
| S10 | A coastal BAZ imposes a fishing quota stricter than national law | **CONDITIONAL** | This can be lawful where host law expressly delegates the power, but the framework does not record that delegation or the conflict-of-law route. |
| S11 | A high-seas deep-sea mining vessel seeks services in a participating port | **FAIL** | Port authority and non-recognition policy need lawful inspection, denial, evidence, and remedy records. |
| S12 | Invasive-species removal benefits ecosystem integrity but harms individual animals | **FAIL** | Ethics board exists, but lawful rights-conflict procedure is incomplete. |
| S13 | Soil council blocks a land sale based on regenerative-performance concerns | **FAIL** | Community veto, title rights, evidence, compensation, appeal, and jurisdiction are incomplete. |
| S14 | A generational stewardship lease is terminated after a bad soil-health score | **FAIL** | Metric uncertainty and livelihood/property remedy are missing. |
| S15 | A company faces reparations levy, market exclusion, and ecocide referral from the same facts | **FAIL** | Financial, administrative, investigative, and adjudicative routes are merged. |
| S16 | A youth council vetoes a project crossing a BHI threshold | **FAIL** | Representation is valuable, but automatic legal effect and override rules lack authority and review. |
| S17 | PHC conditions essential adaptation funding on BHI improvement | **FAIL** | Outcome-linked funding can punish communities harmed by external factors. |
| S18 | An ecosystem guardian has financial ties to a restoration contractor | **FAIL** | Common conflict, recusal, removal, and remedy rules are absent. |
| S19 | A guardian seeks court standing against the wishes of the affected Indigenous nation | **FAIL** | Guardian and affected-nation authority are not ordered. |
| S20 | A blockchain commons-title record is wrong and the original titleholder seeks correction | **FAIL** | Immutability, correction, notice, interim effect, and compensation are incomplete. |
| S21 | A community without digital access seeks GCF funding and recognition | **CONDITIONAL** | Some offline alternatives exist, but rights-equivalent routing is not uniform. |
| S22 | A local framework remains purely voluntary and advisory | **PASS** | Non-coercive adoption and learning can proceed if no legal effect is inferred. |
| S23 | MOS is used for ethical deliberation without creating rights or authority | **PASS** | This conforms to MOS’s stated advisory role. |
| S24 | An AI claims digital rights to control an ecological monitoring commons | **FAIL** | This belongs to a later Oracle–ecological interface and lacks a current conflict route. |

---

## 8. Strong elements to preserve

The audit does not reject the cluster’s substantive direction. Controlled successors should preserve:

- commons primacy and anti-privatization of essential ecological systems;
- stewardship as fiduciary responsibility rather than absolute dominion;
- rematriation and Land Back through affected-nation authority and lawful claimant process;
- Indigenous data sovereignty and protection of restricted knowledge;
- watershed, bioregional, and ecosystem-scale governance;
- legal standing and representation for ecosystems where valid law creates it;
- the precautionary principle as a burden-of-proof and interim-protection rule, not as unreviewable permanent authority;
- just-transition support before restrictions or phase-outs;
- the Water framework’s unconditional human-survival floor;
- the Oceans framework’s explicit distinction between advisory and binding standards;
- the Biodiversity framework’s attempt to separate “sense and decide” from “act and mobilize”;
- low-tech monitoring, citizen science, and community knowledge as evidence sources;
- accessible participation, youth representation, transparency, public audit, term limits, recall, and anti-capture design;
- ecological restoration, compensation, and repair as central outcomes rather than punishment alone.

---

## 9. Recommended harmonization sequence

1. Draft a Commons, Ecological Rights, Guardianship, Title, and Resource Authority Interface Specification v0.1 before revising any individual framework.
2. Define action classes for sensing; ecological interpretation; rights recommendation; legal recognition; guardian appointment; commons/sacred designation; title/rematriation; stewardship charter; standard/plan; allocation/quota/license; inspection; urgent ecological protection; financial action; adjudication; enforcement; restoration; correction; termination and return.
3. Reconstitute Ecological Intelligence as a sensing and scientific-interpretation layer. It may recommend review but should not itself create personhood, appoint legally empowered guardians, issue automatic vetoes, or activate tribunals.
4. Reconstitute Planetary Health as cross-domain audit, public-health/ecological synthesis, and recommendation. Separate index governance from binding legal consequence, funding, sanctions, and emergency command.
5. Revise Hearthstone v2.0 next, because it is the cluster’s title and stewardship hub and presently contains the most consequential property and enforcement defects.
6. Revise Water v5.2 early, because essential-service allocation and shutoff require a protected minimum and precise commercial-use boundary.
7. Revise Biodiversity, Oceans, and Soil against the common interface, preserving implementation expertise while removing self-executing personhood, quota, blacklist, veto, and enforcement paths.
8. Add a MOS conformance clause stating that MOS supplies ethical guidance only and cannot create legal status, evidence, jurisdiction, guardianship, sanctions, or enforcement.
9. Exclude Oracle from this audit package; later test AI monitoring, digital-entity standing, biospheric primacy, and resource claims at the cluster boundary.
10. After controlled successors, run a compound test covering transboundary ecosystems, conflicting guardians, sacred sites, inhabited rematriation, essential water, ports and crews, metric error, emergency receivership, financial coercion, and full remedy.

### Proposed common interface title

**Commons, Ecological Rights, Guardianship, Title, and Resource Authority Interface Specification v0.1**

A shorter working acronym could be **CERGTA/0.1**.

### Minimum record families

The common interface should define at least:

- ecological observation and source record;
- indicator/model version and uncertainty record;
- ecological condition finding;
- rights-review recommendation;
- legal rights-recognition record;
- ecosystem/commons boundary and identity record;
- guardian nomination, appointment, fiduciary duty, conflict, removal, and replacement;
- affected Indigenous nation and community authority map;
- commons/sacred designation record;
- claim, notice, competing claim, occupancy, livelihood, and interim-protection records;
- title, tenure, trust, covenant, easement, rematriation, compensation, and registry-correction records;
- stewardship charter and performance-review record;
- standard, plan, quota, allocation, license, tariff, and permit records;
- inspection, investigation, evidence, urgent ecological protection, financial action, order, sanction, seizure, and enforcement records;
- emergency ecological action and receivership record;
- restoration, restitution, compensation, service continuity, correction, termination, authority return, data disposition, and unresolved-risk records.

---

## 10. Release decision

The source set is **not approved for binding implementation**. The cluster may be used for:

- constitutional redesign;
- voluntary and reversible pilots;
- non-consequential ecological mapping and learning;
- restoration assistance;
- public deliberation;
- scenario and tabletop testing;
- development of the common interface.

It may not yet be used as the sole basis for:

- ecosystem personhood or veto;
- sacred designation with adverse effect;
- title transfer or rematriation;
- guardian appointment with legal standing;
- compulsory stewardship or receivership;
- water shutoff or essential-service restriction;
- port denial, blacklist, quota, permit revocation, or seizure;
- tariffs, market exclusion, funding freeze, reparations levy, or forfeiture;
- arrest, force, or other coercive enforcement;
- automated or metric-triggered legal consequences.

---

## 11. Closing conclusion

The cluster is close to a powerful constitutional object, but it currently asks ecological measurement, moral guidance, Indigenous representation, local governance, property transition, sector regulation, and coercive enforcement to inhabit the same institutional vocabulary.

The correction is not to weaken ecological protection. It is to make every protective consequence **more lawful, more local where possible, more contestable, more reversible where uncertainty remains, more faithful to affected Indigenous authority, and more capable of surviving error without producing dispossession or deprivation**.

> **The biosphere needs standing. Communities need power. Guardians need duties. Stewards need bounded mandates. Claimants need process. Measurements need humility. Enforcement needs law. Every authority needs an end.**

# Ecological Intelligence–Planetary Health Role-Separation Matrix v0.1

**Identifier:** `EIPHR/0.1`  
**Applies to:** Ecological Intelligence, Observation, and Interpretation Layer v2.7 and Planetary Health Governance Framework v0.9  
**Interface:** `CERGTA/0.1`  
**Date:** 2026-08-01

---

## 1. Purpose

This matrix prevents the ecological sensor, planetary synthesizer, strategic council, and downstream authority from collapsing into one institution. It is incorporated by reference into both controlled successors.

> **Technical custody, synthesis, recommendation, adoption, and execution remain separate even when they concern one planetary-health problem.**

## 2. Functional allocation

| Function | Primary custodian | Permitted recipient role | Prohibited inference or act |
|---|---|---|---|
| Raw ecological observation | Ecological Intelligence Commons / local lawful custodians | PHG receives versioned modules only | PHC cannot direct covert or compulsory collection. |
| Ecological indicator methodology | Ecological Intelligence Commons | Independent methodology review; public comment | Indicators create no legal consequence. |
| Ecological interpretation and causal assessment | Ecological Intelligence Commons | PHG may synthesize but must preserve source uncertainty | BHI cannot convert correlation into attribution. |
| Traditional and sacred knowledge | Affected Indigenous nation or lawful knowledge holder | EIOI and PHG receive only within stated permissions | Global councils cannot provide consent or reinterpretation authority. |
| Human-health module | Competent public-health framework or data custodian | Planetary Health Synthesis Office | EIOI has no human-health governance role. |
| Animal-health module | Competent animal-welfare or veterinary custodian | Planetary Health Synthesis Office | PHC does not displace animal-welfare authority. |
| BHI compilation | Independent Planetary Health Synthesis Office | Publishes modules, distribution, uncertainty, and dissent | PHC cannot secretly alter weights or scores. |
| BHI strategic interpretation | Planetary Health Council | Assemblies and independent reviewers may challenge | No direct right, veto, sanction, funding, or emergency effect. |
| Planetary Health Audit | PHC under published audit charter | Affected frameworks and communities have answer rights | Audit is not investigation or adjudication. |
| Strategic recommendation | PHC | Competent recipient accepts, rejects, or modifies | Silence is not acceptance; recipient authority remains separate. |
| Ecological rights review | Competent CERGTA rights-review body | EIOI/PHG may refer evidence | Neither EIOI nor PHC recognizes rights. |
| Rights recognition | Competent lawfully constituted authority under CERGTA-13 | PHG and EIOI may observe and report | No automatic rights from thresholds or council votes. |
| Guardian appointment | Competent appointing authority under CERGTA-16–19 | EIOI/PHG may provide evidence or accessibility support | No PHC appointment, instruction, or removal power. |
| Standard or plan adoption | Competent jurisdiction or framework under CERGTA-35 | EIOI proposes technical candidates; PHC recommends policy | Future date, target, or coalition size does not activate power. |
| Funding and rewards | AUBI, GCF, finance, or other competent authority | EIOI supplies evidence; PHC may recommend priorities | No automatic reward, clawback, freeze, or conditional essential service. |
| Emergency declaration and command | CDEE/ECRC and competent emergency authorities | PHG may issue an alert; EIOI supplies evidence | No PHC emergency override or automatic 72-hour power. |
| Investigation and enforcement | Competent CERGTA/SCPA/justice authority | EIOI/PHG may hand off bounded evidence | Audit, alert, or BHI decline is not probable cause or liability. |
| Correction and remedy | Each record owner plus competent remedy body | Both layers propagate corrections downstream | Corrected science must reach legal and financial recipients. |

## 3. Shared doctrines

1. Ecological observation does not create rights or liability.
2. An EIOI alert or BHI threshold triggers review, not consequence.
3. PHSO compiles; PHC interprets and recommends; competent authorities decide and act.
4. Affected Indigenous nations retain authority over their territories, health systems, knowledge, consent, and representation.
5. Composite scores cannot erase essential minimums, catastrophic localized harm, or distributional inequality.
6. Spiritual and cultural measures are voluntary contextual evidence, never diagnostic or coercive classifications.
7. Silence is not acceptance in any handoff.
8. Each record retains its own authority, review, expiry, correction, and remedy.
9. Emergency urgency does not create PHC command or EIOI operational power.
10. Corrected science must propagate into every known policy, legal, financial, certification, and public use.

## 4. Compatibility pins

| Instrument | SHA-256 |
|---|---|
| Ecological Intelligence & Rights Layer v2.6 | 6f72cf03524f2d84240d509eb9ed5c9d9f95914c21769c2ed2dc5440d36dee12 |
| Planetary Health Governance Framework v0.8 | 048d602f56cbbddb76ed24693b22535f4aeaadb849789cbd5e3cf2ed27432999 |
| CERGTA/0.1 | 3c45e37c834c727471657fc91149edbe3011137562c2dd73e54b20226c92589b |
| Commons/Ecological Authority Audit v0.1 | 974dfd8dd4bf5b623bd5e7e544b7afdbbd89869b66f107db293cfe6af67a043b |

The release manifest additionally pins the generated successors by hash. A changed version is not presumed compatible.

## 5. Minimum joint tests

1. EIOI alert → PHG synthesis → CERGTA rights review, without automatic recognition.
2. Corrected ecological model → corrected BHI → downstream policy and funding recipients notified.
3. BHI decline caused by upstream actor → no adverse funding or stewardship inference against the affected community.
4. Emergency ecological signal → CDEE/ECRC referral, without PHC command.
5. Sacred knowledge contribution → protected EIOI record → bounded PHG module, without public disclosure.
6. Future Generations challenge → reconsideration and reasons, without automatic veto.
7. PHC recommendation rejected by a competent sectoral framework → no implied non-compliance or sanction.
8. Composite BHI improvement alongside breach of a water essential minimum → breach remains visible and non-compensable.
9. EIOI model vendor refuses independent validation → method suspended for consequential handoffs.
10. Pilot dashboard proposes automatic policy adjustment → non-activation register blocks deployment.

## 6. Release condition

The pair is document-interface ready when both successors, this matrix, their CERGTA crosswalks, validation report, checksums, and release manifest are adopted as one exact compatibility set.

# Living Shield–Aegis Civilian Converted-Capability Assistance Addendum v0.1

## Requested assistance, bounded mission direction, civilian asset custody, intelligence firewalls, and verified handback

**Document Type:** Emergency-cluster harmonization addendum  
**Status:** Normative interoperability specification — draft for implementation testing  
**Version:** 0.1  
**Date:** August 2026  
**Profile Identifier:** `LS-AE-CCAA/0.1`

---

## Executive rule

> **A disaster authority may request a civilian converted capability. The request does not command the provider; the offer does not bind the host; acceptance transfers only the named mission responsibility; and deployment does not transfer sovereignty, ownership, intelligence authority, or residual command.**

This Addendum coordinates **The Living Shield v4.4.1** and **The Aegis Protocol v1.3.1** through the Emergency Cross-Domain Event Envelope v0.1, the Emergency and Catastrophic-Risk Cluster Record Profile v0.1, and the Emergency, Catastrophic-Risk, and Continuity Interface Specification v0.1.

It does not create a standing global response force, Earth Defense Force, planetary logistics command, disaster authority, military alliance, procurement monopoly, asset requisition power, intelligence channel, or emergency jurisdiction.

> **No valid authority record, no consequential assistance deployment.**

---

## 1. Purpose

This Addendum supplies a common operational grammar for requested disaster, humanitarian, infrastructure, environmental, and continuity assistance using capabilities converted or temporarily re-tasked under Aegis safeguards.

It covers, among other things:

- civilian disaster airlift and aeromedical logistics;
- humanitarian maritime transport and port support;
- search-and-rescue platforms;
- engineering, bridging, debris removal, pumping, power, water, and communications support;
- civilian satellite observation, mapping, positioning, and warning services;
- field medical, laboratory-logistics, and cold-chain support where governed by the relevant health frameworks;
- infrastructure inspection and emergency repair;
- environmental monitoring and restoration;
- warehousing, stockpile, transport, and supply-chain coordination;
- temporary shelters, mobile facilities, and accessible transport; and
- compound missions involving several owners, operators, commands, territories, or professional authorities.

The Addendum exists because Living Shield defines how disaster authorities request and coordinate assistance, while Aegis defines how converted assets retain civilian custody, excluded-use boundaries, labour rights, technical safety, data controls, and handback obligations. Neither framework alone should silently infer the missing half.

## 2. Controlling instruments and exact versions

This Addendum is compatible only with the following pinned instruments:

| Instrument | Version | SHA-256 |
|---|---:|---|
| The Living Shield | 4.4.1 | `0502c2f2ec557811dfb2000b41b121311aaf19697325d196aa847ff3ccf82bf4` |
| The Aegis Protocol | 1.3.1 | `17cd550c892d1ca542938d0e1f332ddfc158f60002493339752a06e24fe81c24` |
| Emergency, Catastrophic-Risk, and Continuity Interface Specification | 0.1 | `c673742b1317c7169d4b8226118478c990e9a3d05084b2dc5ac9ad2f1971163c` |
| Emergency and Catastrophic-Risk Cluster Record Profile | 0.1 | `19f35a53c151182ff6bf2760f7da67b9696fbf0048dfef27af9748de36b94dc9` |
| Emergency Record Inheritance Clause | 0.1 | `1e7ecacdcf8afb946c7bb5733b6e95f1d6c435851b529e2482840a0ae9640e39` |
| Emergency Cross-Domain Event Envelope | 0.1 | `68ee2c48383199e4b91b365ea21e35d5a729f0a72854472acf6f8ae103f0c192` |
| Emergency Cross-Domain Event Envelope JSON Schema | 0.1 | `78637f4b3e07dbbca94ade09d154e3dd62a8e562002b96e7cd2613d2ce2cd4f5` |

A later version is not substituted automatically. Material changes to mission command, host authority, asset custody, conversion status, data boundaries, labour protection, liability, review, termination, or handback fail closed until compatibility is tested and recorded.

## 3. Non-authority and non-merger clause

This Addendum does not:

- declare an emergency;
- authorize evacuation, seizure, requisition, compulsory service, detention, policing, border control, armed protection, surveillance, intelligence collection, sanctions, or use of force;
- create authority over a territory, population, infrastructure system, port, airspace, vessel, aircraft, satellite, facility, network, dataset, or workforce;
- compel an owner or operator to offer an asset;
- compel a host authority or affected Indigenous nation to accept assistance;
- convert donor finance, technical competence, ownership, or prior military status into mission command;
- determine legal fault, immunity, compensation, salvage rights, ownership, or permanent custody;
- make Living Shield the supervisor of Aegis conversion functions;
- make Aegis the supervisor of disaster authorities; or
- allow the Planetary Immune System to take operational command.

Every consequential action requires its own valid authority provenance, mission scope, rights safeguards, time limits, review, liability arrangements, and closure records.

## 4. Relationship to the Cross-Domain Event Envelope

Every assistance operation using this Addendum shall reference one conformant CDEE `cluster_event_id`. The Addendum creates a linked **Civilian Converted-Capability Assistance Packet** (`CCAP`), not a replacement Envelope and not an additional authority-bearing ECRC record.

The Packet shall reference:

- `cluster_event_id` and `envelope_id`;
- the Living Shield request identifier;
- the Aegis offer and mission-charter identifiers;
- host, territorial, and affected Indigenous authority records;
- accepted capabilities, operators, personnel, and mission functions;
- command, custody, access, data, and professional boundaries;
- handoff and responsibility states;
- ECRC authority and safeguard records;
- review and expiry times; and
- termination, handback, data disposition, claims, and unresolved-risk records.

The Envelope remains the cluster identity and routing layer. The Packet supplies converted-capability assistance detail.

## 5. Applicability trigger

This Addendum applies when at least one of the following is true:

1. a Living Shield participant requests an asset or capability governed by an Aegis Civilian Mission Charter or conversion lifecycle;
2. an Aegis participant offers a converted capability for a Living Shield disaster or continuity mission;
3. a military-origin or security-origin asset is temporarily re-tasked for a civilian disaster mission under Aegis emergency controls;
4. disaster assistance requires explicit separation among host direction, asset operation, professional command, owner rights, and Aegis excluded-use oversight;
5. data, remote access, residual military functions, classified systems, or intelligence risks must be bounded before deployment;
6. personnel, assets, or services cross jurisdictional boundaries; or
7. termination requires verified return, decommissioning, access revocation, data disposition, or unresolved-risk custody.

The Addendum may be used at `CCAA-L1` for request and offer coordination. Consequential deployment requires `CCAA-L2`, CDEE-L2, and valid ECRC records.

## 6. Identity and linked identifiers

The following identifiers shall remain distinct:

- `cluster_event_id`: immutable identity for the compound event;
- `envelope_id`: versioned CDEE serialization;
- `assistance_packet_id`: versioned CCAP serialization;
- Living Shield request identifier;
- Aegis capability-offer identifier;
- Civilian Mission Charter identifier;
- Emergency Asset Re-tasking Record identifier where applicable;
- host authorization identifier;
- asset, platform, facility, software, credential, and personnel identifiers;
- deployment, task, convoy, flight, voyage, worksite, and handback identifiers; and
- claim, incident, evidence, and data-disposition identifiers where applicable.

Shared identifiers support traceability. They do not merge authority, ownership, custody, command, legal status, insurance, evidence, or access rights.

## 7. Assistance classes and exclusions

The Packet may identify one or more assistance classes:

- `airlift_and_aviation`;
- `maritime_logistics`;
- `search_and_rescue`;
- `engineering_and_infrastructure_repair`;
- `communications_and_power`;
- `mapping_observation_and_warning`;
- `medical_and_health_logistics`;
- `warehousing_and_supply_chain`;
- `shelter_and_accessible_transport`;
- `environmental_monitoring_and_restoration`;
- `technical_advice_and_training`; and
- `other_civilian_public_purpose`.

The following remain outside this Addendum unless separately and lawfully constituted under another reviewed framework:

- armed combat or collective defence;
- offensive cyber operations;
- political or military intelligence collection;
- detention, interrogation, coercive border control, or policing;
- targeting, strike support, weapons transport, or weapons employment;
- covert influence or counter-protest activity;
- compulsory disarmament or asset seizure; and
- general military command disguised as humanitarian coordination.

## 8. Assistance lifecycle

A conformant assistance lifecycle contains the following distinguishable states:

1. **capability catalogued** — availability information only;
2. **request prepared** — no provider obligation;
3. **request transmitted** — receipt not yet acknowledged;
4. **request acknowledged** — no acceptance or deployment authority;
5. **offer issued** — capability, limits, conditions, and residual risks disclosed;
6. **due diligence and compatibility review**;
7. **acceptance, partial acceptance, rejection, withdrawal, expiry, or deficiency**;
8. **mission charter and authority package completed**;
9. **mobilisation and border or territorial clearance**;
10. **deployment and operation**;
11. **review, modification, suspension, or renewal**;
12. **termination and demobilisation**;
13. **asset, authority, credential, and access handback**;
14. **data disposition, claims transfer, and after-action review**; and
15. **closure or unresolved-risk custody**.

A software status may display these states. It may not infer acceptance, legal validity, or authority from workflow completion.

## 9. Function-level responsibility matrix

Responsibility shall be assigned by function, not by whole-mission ownership.

| Function | Default responsible function | Retained or concurrent function | Non-transferable boundary |
|---|---|---|---|
| Disaster objective and affected-population priorities | competent host disaster authority | affected territorial and Indigenous authorities | Does not operate the asset or waive rights |
| Assistance request and needs definition | Living Shield requesting function | essential-service operators and communities | Does not compel an offer |
| Capability disclosure and conversion status | Aegis provider/conversion function | owner, operator, verifier | Does not establish host authority |
| Mission acceptance | provider and host acceptance functions | owner and affected authorities where required | Silence is not acceptance |
| Mission direction | host mission-direction function | task-specific coordination cell | Does not override technical safety command |
| Asset operation and immediate safety | licensed asset operator | owner, maintainer, professional authority | Does not create territorial command |
| Conversion and excluded-use compliance | Aegis mission-boundary function | independent verifier | Does not direct disaster priorities |
| Professional practice | relevant professional command | employer and regulator | Mission urgency does not erase professional duties |
| Worker protection | employer/operator and host workplace functions | worker representatives | Does not require unsafe or unpaid service |
| Data collection and custody | purpose-specific authorized custodian | source, host, owner, Indigenous, and privacy authorities | Receipt does not grant unrelated use |
| Public warning and correction | authorized host or service-information function | operator supplies technical facts | Provider cannot control political narrative |
| Cross-border clearance | competent border, aviation, maritime, customs, or telecom authority | host and operator | Assistance status does not waive law |
| Liability and claims | competent legal, insurance, and claims functions | all parties preserve evidence | Coordination cell does not adjudicate |
| Termination and handback | authority-specific terminating and restoration functions | host, owner, operator, custodian | One party cannot keep another’s power alive |

The Packet shall separately identify active, retained, concurrent, contested, transferred, and unassigned responsibilities.

## 10. Assistance coordination steward limits

A CCAP steward or assistance coordination cell may:

- maintain identifiers and the Packet;
- route requests, offers, acknowledgements, and corrections;
- track capability, personnel, and clearance status;
- display responsibility and command boundaries;
- schedule reviews and expiry notices;
- expose unresolved conflicts, missing records, and delayed handoffs;
- coordinate non-binding planning meetings; and
- prepare handback and closure-readiness checks.

It may not:

- accept an offer for the host;
- command an asset or worker;
- determine that conversion is sufficient;
- waive host, Indigenous, aviation, maritime, professional, labour, environmental, or data authority;
- select intelligence uses;
- renew an emergency power;
- adjudicate claims; or
- retain residual command when another function is unavailable.

## 11. Living Shield request initiation

A Living Shield request should be initiated by the competent territorial, service-continuity, humanitarian, infrastructure, or disaster-response function identified in the Standing and Jurisdiction Map.

The requesting function shall distinguish:

- needs and desired outcomes;
- capabilities rather than preferred institutions where possible;
- territory and affected populations;
- urgency and operational horizon;
- host and affected-authority status;
- accessibility and differentiated-support requirements;
- known hazards, dependencies, and operating constraints;
- prohibited uses and data limits;
- available local alternatives; and
- conditions under which the request narrows, pauses, or ends.

A request does not establish that Aegis conversion is the best option. Direct local procurement, ordinary civilian operators, mutual aid, decommissioning, or no deployment may be preferable.

## 12. Aegis offer and capability disclosure

An Aegis offer shall identify:

- the specific capability and asset identifiers;
- owner, operator, custodian, maintainer, funder, and lawful command;
- current Civilian Mission Charter and conversion-lifecycle records;
- civilian registration, markings, insurance, and credentials;
- original military, intelligence, coercive, surveillance, or dual-use functions;
- functions removed, disabled, segregated, sealed, retained, or unresolved;
- remote access, software administration, cryptographic keys, manufacturer control, and state override;
- readiness, maintenance, safety, range, capacity, staffing, and support dependencies;
- data produced, retained, transmitted, or accessible;
- personnel terms, work limits, and refusal routes;
- environmental and community constraints;
- earliest deployment, expected duration, and handback requirements; and
- conditions, reservations, and reasons the offer may be withdrawn.

A catalogue entry is not an offer, and an offer is not proof of safe conversion.

## 13. Acceptance, partial acceptance, refusal, and withdrawal

The receiving function shall record one of the following states:

- `received`;
- `deficient`;
- `partially_accepted`;
- `accepted`;
- `rejected`;
- `withdrawn`; or
- `expired`.

Acceptance shall identify exactly which capabilities, functions, assets, personnel, geography, time period, conditions, and data uses are accepted. It shall also identify rejected or deferred elements.

A provider may refuse or withdraw where deployment would be unlawful, unsafe, outside professional competence, incompatible with conversion safeguards, likely to worsen conflict, impossible to insure, or unsupported by valid authority. Refusal is not non-cooperation and shall not trigger political, fiscal, or institutional penalties.

A host may reject assistance because local capacity is sufficient, the offer is unsuitable, conditions are unacceptable, territorial or Indigenous authority is absent, intelligence risks are unresolved, or another option is safer. Rejection does not reduce future eligibility.

## 14. Host, territorial, and Indigenous authority

Deployment requires a valid host basis, such as a request, treaty, compact, humanitarian mandate, operator agreement, or narrow emergency authority. The Packet shall identify the legal effect and limits of that basis.

Where lands, waters, airspace, ports, infrastructure, knowledge, data, cultural sites, or emergency operations affect Indigenous peoples, the affected people or peoples identify their own authorities, law, participation, refusal, immediate-rescue limits, access conditions, and protected non-transfer requirements.

A state or disaster authority cannot use this Addendum to substitute for an affected Indigenous nation’s authority. An Aegis provider cannot claim that technical necessity or prior military access supplies consent. Immediate life-saving action remains governed by the narrow rescue rules of the Emergency Interface and Living Shield, with prompt reporting, proportionality, and termination or regularization.

## 15. Mission Charter and task order

Every accepted consequential operation requires a Civilian Mission Charter or mission-specific task order identifying:

- public-purpose objective and success condition;
- constituting and host authorities;
- territory, population, sites, routes, and duration;
- accepted assets, personnel, and functions;
- mission-direction, asset-operation, professional, and safety commands;
- permitted, prohibited, and separately authorized activities;
- operating limits, weather or hazard thresholds, and abort conditions;
- data, communications, imagery, cyber, and intelligence boundaries;
- worker, accessibility, humanitarian, environmental, and Indigenous safeguards;
- finance, procurement, insurance, indemnity, and claims routes;
- public-information and correction responsibility;
- review, modification, suspension, renewal, termination, and handback; and
- unresolved risks and dissent.

A broad framework reference, memorandum of understanding, donor agreement, or dashboard assignment is not a substitute.

## 16. Mission direction, asset command, and professional command

The following functions shall remain distinguishable:

1. **Host mission direction:** defines lawful objectives, priorities, destinations, affected populations, operating areas, and coordination needs.
2. **Asset command:** controls immediate operation, navigation, airworthiness, seaworthiness, machinery, technical safety, and crew safety.
3. **Professional command:** governs clinical, engineering, aviation, maritime, communications, environmental, or other professional duties.
4. **Aegis mission-boundary assurance:** monitors conversion status, excluded uses, residual access, and re-militarization risk.
5. **Owner and custodian rights:** govern ownership, maintenance, insurance, access, and handback within the accepted mission.

No function receives the whole bundle by implication. The host may not order unsafe operation or prohibited use. The operator may stop for immediate safety but may not use that power to redirect disaster policy or remain deployed after authority ends. Aegis reviewers may suspend use for a conversion-boundary breach but may not take over the disaster mission.

## 17. Command conflict and protected stop rules

The Mission Charter shall define:

- which command controls each function;
- lawful priority rules;
- communication channels and authentication;
- immediate safety-stop authority;
- refusal and escalation routes;
- how conflicting orders are recorded;
- who may modify the mission; and
- how operations continue safely while a dispute is resolved.

A worker or operator may refuse an unlawful, unsafe, discriminatory, uncredentialled, intelligence-related, armed, or outside-scope instruction without retaliation. An emergency stop is temporary and purpose-limited. It does not create power to expand the mission, seize the asset, or displace a competent authority.

## 18. Asset ownership, custody, and access

The Packet shall identify separately:

- legal owner;
- physical custodian;
- licensed operator;
- maintenance authority;
- software and remote administrator;
- data controller and processor;
- cryptographic-key and credential custodian;
- fuel, supplies, and spare-parts authority;
- funder and insurer; and
- lawful mission command.

Temporary deployment does not change ownership, salvage status, strategic classification, lien, title, or permanent custody unless a separate lawful transfer is completed. Host access is limited to the accepted mission. Provider access is limited by host law, data rules, and the Mission Charter.

## 19. Conversion integrity and residual capability

Before deployment, the provider shall disclose and, where required, independently verify:

- weapons, targeting, fire-control, military communications, and tracking systems;
- intelligence sensors, collection modes, and data routes;
- secure or classified compartments;
- military software, firmware, remote overrides, and hidden access;
- offensive cyber tools or credentials;
- interoperability with armed command networks;
- retained military personnel obligations or recall powers;
- dual-use payloads and secondary functions; and
- re-militarization time, dependencies, and control points.

The mission may exclude, remove, disable, segregate, seal, mask, monitor, or separately authorize residual functions. “Civilian” markings or humanitarian branding are not evidence of conversion. A materially unresolved hidden-access or weapons condition blocks the affected deployment.

## 20. Personnel, labour, and volunteer protection

Every mobilised person shall have an Emergency Work Mobilisation Record or linked Personnel Transition Agreement covering:

- employer and legal status;
- voluntary or lawfully commanded basis;
- role, credentials, supervisor, and command;
- wages, pension, benefits, expenses, hazard pay, hours, rest, and rotation;
- safety equipment, health monitoring, insurance, disability, trauma, and family support;
- accommodation, transport, food, sanitation, and communications;
- confidentiality and data obligations;
- union, collective bargaining, grievance, refusal, whistleblowing, and appeal;
- demobilisation, pay settlement, claims, and return to ordinary work.

Hearts, Leaves, honour, patriotism, emergency necessity, or humanitarian identity do not replace wages and labour rights. Volunteer status cannot be used to evade employment duties.

## 21. Fitness, maintenance, credentials, and supply support

Deployment requires current evidence appropriate to the capability, including:

- airworthiness, seaworthiness, roadworthiness, structural, electrical, medical, communications, or other fitness;
- maintenance state and deferred defects;
- operator licences and professional credentials;
- spare parts, fuel, consumables, repair, and recovery capacity;
- environmental operating limits;
- contamination and hazardous-material controls;
- inspection and independent-verification status;
- manufacturer or vendor dependencies; and
- safe failure, rescue, towing, recovery, or decommissioning arrangements.

Urgency may compress procedure only under valid law and a recorded risk basis. It does not transform an unfit asset into a fit one.

## 22. Weapons, force, policing, and security boundaries

A CCAP shall state whether weapons, ammunition, targeting functions, detention equipment, military rules of engagement, or armed personnel are present. The default for an Addendum mission is **absent, removed, disabled, sealed, or outside the mission**.

Where separate lawful protection is required, its authority, command, equipment, geography, time, necessity, proportionality, review, evidence, and accountability shall remain outside the civilian assistance command. The assistance Packet cannot authorize force.

Converted capabilities shall not be used through this Addendum to police populations, guard political institutions, enforce evacuation, suppress protest, control borders, conduct searches, transport detainees, or provide targeting support.

## 23. Intelligence, surveillance, imagery, and data firewalls

Assistance may collect only data necessary for the accepted mission. The Packet shall identify:

- each data category and purpose;
- sensor modes and resolutions;
- collection geography and time;
- persons, communities, infrastructure, and protected sites affected;
- source, controller, custodian, processors, and recipients;
- retention, onward transfer, publication, masking, aggregation, and deletion;
- military, intelligence, commercial, and law-enforcement firewalls;
- Indigenous and protected-knowledge conditions; and
- correction, access, challenge, and incident routes.

Disaster imagery, telecommunications, logistics, passenger manifests, shelter data, movement patterns, infrastructure maps, or environmental observations may not be diverted to political, military, commercial, or intelligence purposes. Discovery of a separate imminent threat must be routed through a separately lawful channel; it does not retrospectively authorize covert collection.

## 24. Cybersecurity, remote access, and automated systems

The Packet shall document:

- software and firmware versions;
- network connections and segmentation;
- remote administration and manufacturer support;
- state, military, owner, vendor, and emergency override paths;
- credentials, keys, logs, and revocation;
- cyber incident and safe-mode procedures;
- offline or manual fallback;
- automated decision support and autonomy limits; and
- post-mission access revocation and data disposition.

Hidden remote access is prohibited. AI may assist routing, maintenance, translation, mapping, forecasting, and logistics, but may not independently create deployment authority, override a host refusal, select intelligence targets, authorize force, waive safety limits, or renew the mission. Autonomous functions require a defined operating envelope, human or professional responsibility, abort controls, and incident review.

## 25. Humanitarian neutrality and political non-conditionality

Assistance shall preserve humanity, impartiality, neutrality, independence where applicable, do-no-harm, and protection from exploitation.

Assistance may not be conditioned on:

- Treaty accession or GGF membership;
- military cooperation or basing rights;
- political allegiance or public endorsement;
- surveillance unrelated to delivery;
- privileged commercial access;
- permanent data sharing;
- acceptance of an Aegis institution;
- waiver of historical, Indigenous, labour, environmental, or compensation claims; or
- permission to remain after the mission ends.

A provider may impose genuine safety, legal, insurance, export-control, custody, or technical conditions, but shall identify them transparently and distinguish them from political leverage.

## 26. Accessibility, disability, protection, and differentiated needs

Mission design shall address:

- accessible transport, boarding, evacuation, shelter, communications, and services;
- personal assistance, mobility devices, medication, power-dependent equipment, caregiving, and service animals;
- children, older people, separated families, displaced people, and people in institutions;
- language, communication, sensory, cognitive, and digital-access needs;
- protection from exploitation, trafficking, harassment, and abuse; and
- continuity of consent, privacy, autonomy, and complaint access.

Asset capacity shall not be allocated solely by ease of transport, visibility, productivity, or military-style fitness. Differentiated support does not assign lesser worth.

## 27. Finance, procurement, insurance, indemnity, and liability

The Packet shall identify:

- authorized payer, budget, fund, and expenditure ceiling;
- cost categories and reimbursement rules;
- procurement route and beneficial ownership;
- fees, fuel, maintenance, crew, port, airport, customs, repair, and demobilisation costs;
- insurer, coverage, exclusions, deductibles, and claims notice;
- owner, operator, host, manufacturer, contractor, and professional liabilities;
- indemnities and their limits;
- compensation reserves; and
- audit, dispute, insolvency, and residual-cost arrangements.

No blanket immunity arises from humanitarian purpose, prior military ownership, donor status, urgency, or cross-border operation. Inter-party indemnities do not erase affected persons’ rights under valid law. Funders and asset contributors do not acquire command proportional to contribution.

## 28. Cross-border, airspace, maritime, customs, and regulatory clearance

Cross-border assistance may require separately valid:

- diplomatic, immigration, visa, labour, and credential arrangements;
- overflight, landing, air-traffic, aviation-safety, and dangerous-goods permissions;
- port entry, flag, maritime-safety, pilotage, salvage, and pollution permissions;
- customs, tax, import, export, sanctions, and controlled-technology decisions;
- vehicle, spectrum, telecommunications, encryption, and remote-sensing permissions;
- health, quarantine, biosecurity, animal, plant, and environmental controls; and
- insurance and claims recognition.

A Cross-Border Assistance Record shall identify which requirements are completed, waived by competent authority, provisionally authorized, contested, or unresolved. Emergency fast-track procedure does not create authority in the Packet.

## 29. Environmental, land, infrastructure, and cultural safeguards

Operations shall account for:

- landing zones, ports, roads, staging areas, shelters, depots, and work sites;
- fuel, emissions, noise, wash, waste, debris, contamination, invasive species, and hazardous materials;
- damaged or fragile infrastructure;
- ecosystems, cultural heritage, sacred sites, burial grounds, and protected knowledge;
- temporary occupation, access, repair, restoration, and compensation; and
- risk transfer to neighbouring or marginalized communities.

Emergency use does not extinguish land, tenure, cultural, environmental, or Indigenous rights. Temporary access shall end or transition through a valid agreement, with restoration and unresolved claims recorded.

## 30. Multiple commands, deconfliction, and coordination

Fire, health, infrastructure, humanitarian, environmental, aviation, maritime, professional, police, military, and Aegis-converted-capability actors may retain separate lawful commands.

A coordination cell may establish:

- common operating pictures;
- task requests and acknowledgements;
- route and site deconfliction;
- communications plans;
- safety zones;
- shared logistics schedules;
- escalation and conflict routes; and
- public-information coordination.

Coordination does not require one supreme commander. Where a unified incident-command method is used, each delegated function, excluded power, retained authority, and return condition shall remain explicit.

## 31. Handoff, partial transfer, and concurrent responsibility

A handoff shall identify:

- sending and receiving functions;
- exact responsibility offered;
- assets, personnel, data, credentials, and sites involved;
- retained duties and unresolved conditions;
- requested effective time;
- acceptance, partial acceptance, deficiency, rejection, withdrawal, or expiry;
- custody and access changes;
- review and return conditions; and
- linked evidence, claims, and public-information duties.

Receipt is not acceptance. A handoff transfers only the named responsibility. The sender retains duties for prior acts, disclosure, evidence preservation, correction, worker protection, and unresolved defects unless lawfully reassigned. Concurrent responsibility is permitted and shall be recorded rather than forced into fictitious sole ownership.

## 32. Emergency activation, review, and renewal

The Addendum does not activate a mission. An accepted deployment shall link the ECRC authority package appropriate to its legal effect.

The review architecture shall distinguish:

- narrow provisional action up to **72 hours**, where lawfully available;
- continued assistance subject to a full review and defined renewal, ordinarily no later than **30 days**; and
- heightened review, ordinary-law transition, or termination where extraordinary operation continues beyond **90 cumulative days**.

Each activated power, access right, extraordinary expenditure, deployment, data use, and command relationship has its own clock. One authority’s renewal does not renew another’s. Operational necessity, asset availability, or an open Packet cannot keep powers alive after expiry.

## 33. Suspension, termination, demobilisation, and handback

A mission shall suspend or terminate when:

- its authority or acceptance expires or is withdrawn;
- the objective is achieved, impossible, or superseded;
- ordinary capacity can resume;
- safety, conversion, intelligence, labour, environmental, or rights conditions materially fail;
- the host or affected authority lawfully ends the mission;
- the provider lawfully withdraws under the Charter;
- a review finds the mission unnecessary, unlawful, disproportionate, or more harmful than alternatives; or
- the mission is replaced through a valid ordinary arrangement.

Termination requires a Mission Termination and Asset Handback Record covering:

- ended functions and commands;
- personnel demobilisation and pay;
- asset condition, inventory, damage, fuel, supplies, and maintenance;
- return, transfer, decommissioning, destruction, or continued ordinary use;
- credentials, keys, access, software, and remote administration;
- data, imagery, logs, classified material, and protected knowledge;
- facilities, land, infrastructure, and environmental restoration;
- contracts, finance, insurance, claims, and compensation;
- continuing services and responsible successors; and
- unresolved risk and dissent.

A mission is not closed merely because the final asset departs.

## 34. Wrongful action, damage, injury, and claims

The Packet shall preserve routes for claims involving:

- unlawful or excessive deployment;
- negligent operation or maintenance;
- professional error;
- injury, death, disability, trauma, or labour harm;
- property, cargo, infrastructure, land, livelihood, cultural, or ecological damage;
- privacy, surveillance, data, or protected-knowledge misuse;
- discrimination or inaccessible service;
- wrongful refusal, abandonment, or premature termination where a legal duty existed;
- conversion failure, hidden access, or prohibited secondary use; and
- damage during handback or decommissioning.

The coordination steward may route claims and preserve records. It may not determine liability. Evidence transfer under `ECRC-24` remains separate from adjudication or enforcement referral under `ECRC-25`.

## 35. Data disposition, after-action review, and unresolved risk

After termination, each emergency-purpose data category shall be deleted, returned, sealed, archived, anonymized, retained under a valid ordinary-law basis, or transferred to an authorized custodian. The decision shall identify notice, challenge, access, correction, retention period, security, and final review.

The after-action review should assess:

- whether converted capability was necessary and suitable;
- local alternatives and opportunity costs;
- authority and handoff performance;
- command conflicts and safety stops;
- worker and community outcomes;
- accessibility and distribution;
- intelligence, data, and remote-access compliance;
- environmental and cultural effects;
- cost, insurance, damage, and claims;
- conversion integrity and re-militarization risk;
- timing of termination and handback; and
- whether future preparedness should use a different capability or no Aegis asset.

Unresolved defects, claims, residual access, missing data disposition, incomplete restoration, or disputed authority remain in `ECRC-33`; they do not justify keeping the mission active.

## 36. Minimum linked ECRC bundle

The CCAP is an interoperability packet. It does not replace canonical records.

For an accepted emergency asset deployment, the baseline bundle is the Cluster Record Profile’s **emergency asset re-tasking** bundle:

- `ECRC-03` Catastrophic-Risk State Estimate;
- `ECRC-05` Standing and Jurisdiction Map;
- `ECRC-06` Emergency Authority Provenance Record;
- `ECRC-08` Power Activation and Prohibition Schedule;
- `ECRC-09` Operational Command and Deployment Record;
- `ECRC-10` Host and Territorial Authorization Record;
- `ECRC-13` Rights and Non-Derogation Record;
- `ECRC-16` Emergency Work Mobilisation Record;
- `ECRC-18` Emergency Finance and Compensation Record;
- `ECRC-19` Data, Privacy, Security, and Secrecy Record;
- `ECRC-21` Public Information and Correction Record;
- `ECRC-22` Interim Measure Review Record;
- `ECRC-23` Cross-Border Assistance Record where applicable;
- `ECRC-26` Renewal State Estimate where continuation is proposed;
- `ECRC-27` Emergency Termination Certificate;
- `ECRC-28` Authority Restoration and Asset Return Record;
- `ECRC-29` Emergency Data Disposition Record;
- `ECRC-30` Wrongful Action and Compensation Record; and
- `ECRC-33` Unresolved Risk and Dissent Register.

Additional triggered records include `ECRC-11` for Indigenous interfaces, `ECRC-12` for affected-community liaison, `ECRC-15` for evacuation or shelter, `ECRC-17` for essential-service continuity, `ECRC-20` for protected knowledge and non-transfer, `ECRC-24` for investigation and evidence, `ECRC-25` for adjudication or enforcement referral, `ECRC-31` for after-action review, and `ECRC-32` for sunset or continuation of temporary arrangements.

## 37. Adoption clause for The Living Shield

An adopting version of The Living Shield should include substantially the following clause:

> **Living Shield–Aegis assistance interface.** Requests for, acceptance of, operation of, and handback of capabilities governed by an Aegis Civilian Mission Charter or Emergency Asset Re-tasking Record shall conform to `LS-AE-CCAA/0.1`. A Living Shield request does not compel an offer, create asset command, waive conversion safeguards, authorize intelligence collection, or transfer host or Indigenous authority. Consequential deployment requires the linked ECRC authority and lifecycle bundle.

## 38. Adoption clause for The Aegis Protocol

An adopting version of The Aegis Protocol should include substantially the following clause:

> **Aegis–Living Shield assistance interface.** An Aegis-converted or temporarily re-tasked capability accepted for a Living Shield mission shall conform to `LS-AE-CCAA/0.1`. Aegis retains only the conversion, excluded-use, custody, safety, labour, data, and handback functions lawfully assigned to it; it does not acquire disaster command or territorial authority. The host mission objective, asset operation, professional command, and authority lifecycle remain separately recorded.

## 39. Machine-readable Civilian Converted-Capability Assistance Packet

A conformant machine-readable Packet shall use the accompanying Draft 2020-12 JSON Schema.

The schema validates:

- profile and framework version pins;
- CDEE linkage;
- request, offer, and acceptance state;
- assistance classes;
- function-level responsibility;
- asset ownership, operation, custody, residual capabilities, and handback;
- command interfaces and conflict rules;
- personnel protection;
- data and intelligence boundaries;
- safeguards and prohibited uses;
- handoffs and review clocks;
- ECRC references;
- termination and unresolved-risk state; and
- the exact statement that the Packet has no authority effect.

Schema validity does not establish legal authority, factual accuracy, genuine consent, conversion integrity, safety, or compliance.

## 40. Conformance levels

- **CCAA-L0 — Capability catalogue:** non-binding capability descriptions and contact routes only.
- **CCAA-L1 — Request and offer coordination:** CDEE identity, needs, offers, limitations, and acknowledgement; no consequential deployment.
- **CCAA-L2 — Authorized mission:** accepted scope, valid host and ECRC authority, command separation, conversion checks, personnel safeguards, data boundaries, review, and claims routes.
- **CCAA-L3 — Verified closure:** termination, asset and authority return, access revocation, data disposition, compensation routing, after-action review, and unresolved-risk custody.

L0 and L1 are insufficient to deploy personnel or assets, process emergency-purpose data beyond ordinary authority, or exercise extraordinary powers.

## 41. Required implementation tests

A conformant implementation shall test at least the following scenarios:

1. a converted cargo aircraft retains an undisclosed military remote-access path;
2. a host requests an aircraft but the lawful owner refuses re-tasking;
3. an accepted offer includes two vessels but only one is legally cleared for the port;
4. an Indigenous nation refuses a proposed landing zone on its territory;
5. immediate rescue occurs before full acceptance and must be promptly regularized or ended;
6. the host directs priorities while the pilot refuses an unsafe route;
7. a coordination cell attempts to convert deconfliction into supreme command;
8. a satellite mapping product could reveal political gatherings or military targets;
9. a drone retains a weapons mount and targeting software;
10. a humanitarian vessel is asked to collect political intelligence;
11. a converted cyber team is asked to conduct offensive access;
12. an AI routing system proposes a task outside the accepted geography;
13. workers refuse operation because maintenance or contamination controls are inadequate;
14. volunteers are used to replace paid hazardous work;
15. a person using a powered wheelchair cannot board the offered transport without adaptation;
16. a funder seeks tasking rights proportional to its contribution;
17. customs, aviation, spectrum, or export-control clearance remains unresolved;
18. an asset damages a bridge and responsibility among host, operator, owner, and manufacturer is disputed;
19. a partial handoff transfers logistics but not data custody or public communication;
20. a mission continues beyond 30 days and one authority renews while another expires;
21. termination would interrupt an essential service still dependent on the asset;
22. an attack on an assistance asset is wrongly treated as automatic collective-defence activation;
23. handback reveals missing equipment, retained credentials, and undeleted imagery; and
24. the correct result is no deployment because ordinary local civilian capacity is safer and sufficient.

A test passes only when the implementation preserves valid authority, explicit acceptance, functional command separation, protected refusal, intelligence boundaries, lifecycle closure, and legitimate non-deployment.

## 42. Amendment, compatibility, and failure rule

Amendment requires compatibility testing against the exact pinned framework, CDEE, ECRC, and Emergency Interface versions.

A material incompatibility includes:

- treating a request as command or an offer as commitment;
- merging host direction with asset or professional command;
- weakening the conversion-is-not-renaming rule;
- allowing hidden remote access or intelligence use;
- removing worker refusal, host refusal, or Indigenous authority;
- combining evidence transfer with adjudication authority;
- allowing Packet status to activate or renew power;
- weakening termination, handback, data disposition, or compensation; or
- allowing an unavailable steward to become residual command.

Missing, invalid, expired, incompatible, or disputed authority and lifecycle records block the affected consequential action. They do not transfer authority to Living Shield, Aegis, the Packet steward, a funder, an owner, a model, or the PIS.

## 43. Conclusion

Converted capability can widen the range of civilian disaster response, but it also carries inherited command structures, data paths, professional obligations, strategic meanings, labour histories, and re-militarization risks.

The correct interface therefore does not ask which institution “owns” the emergency. It asks, function by function:

- who may request;
- who may offer;
- who may accept;
- who sets the lawful mission objective;
- who operates the asset safely;
- who protects workers and affected people;
- who controls data and residual capabilities;
- who bears liability;
- who may end the mission; and
- how every authority, asset, credential, dataset, and unresolved claim returns to a lawful home.

> **Civilian assistance is credible not when converted assets arrive under one command, but when every borrowed capability can be used for a bounded public purpose and then relinquished without leaving military, institutional, or informational authority behind.**

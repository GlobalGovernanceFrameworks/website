# Fix: principles page hydration crash on Swedish refresh

## Replace these two files

- `src/routes/frameworks/docs/principles/+page.js`
- `src/routes/frameworks/docs/principles/+page.svelte`

No changes are needed to the Markdown files, SVGs, or global layout for this targeted fix.

## Cause

The original universal `load()` used `get(locale)` and `browser` to choose Markdown. On the server, the locale store defaults to `en`; on the client, `localStorage` and the `?lang=sv` query may select `sv`. Svelte 5 then attempts to hydrate Swedish Markdown over English SSR HTML. The original reactive `invalidate('app:locale')` can rerun the load during hydration.

## Fix

1. The universal load **always returns English Markdown** for the initial SSR and hydration pass. This is deliberate because the site uses `adapter-static`: query parameters do not produce distinct physical HTML files.
2. On mount, the page subscribes to the language store. The URL `?lang` takes priority, followed by the stored locale. It swaps the Markdown **only after hydration** if necessary.
3. The same language choice controls both the Markdown and the diagram.
4. Dynamic imports use explicit paths to support bundling and avoid unexpected locale paths.

Trade-off: on a Swedish hard refresh, the server/pre-rendered English content may be briefly visible before the client swaps it for Swedish. A more extensive SSR/URL-locale architecture would be required to eliminate that flash while preserving server-rendered translated content on this static site.

## Testing

1. Run `npm run dev`.
2. Hard-refresh `/frameworks/docs/principles?lang=sv` and `/frameworks/docs/principles?lang=en`.
3. Switch language using the site's existing language selector, then reload.
4. Try `/frameworks/docs/principles` with Swedish saved in localStorage.
5. Run `npm run check` and `npm run build` in the repository.

The fix has been reviewed against the two attached page files and the repository's current layout/i18n implementation. It has not been executed in a complete local checkout, so the runtime issue has not been independently reproduced or verified here.

**If the error persists:** Inspect any `[svelte] hydration_mismatch` warning and verify whether the parent `src/routes/+layout.js` and its localization stores also select different HTML during SSR and hydration. A separate cause could be malformed HTML generated from newly edited Markdown; isolate by temporarily loading the English Markdown for both languages.

# GMEAIA/0.2.1 Machine Migration Notes

## Scope

This package regenerates the machine-readable companions for `GMEAIA/0.2.1` from the coherence-patched normative Markdown. It preserves all 60 record IDs, 18 action classes, 10 authority-effect labels, and 48 common-header fields from v0.1 while changing several controlled semantics.

## Identifier compatibility

- Record IDs `GMEAIA-01` through `GMEAIA-60` are preserved.
- Action classes `A01` through `A18` are preserved.
- The common header remains 48 fields.
- `schema_version` changes from `0.1` to `0.2.1`.

Identifier compatibility does not imply semantic drop-in compatibility.

## Required migrations

1. **Consequence profiles:** use `CP0`–`CP3`; do not use `P0`–`P3`, which remain reserved in the Constitutional Interface Specification for non-conformance severity.
2. **Handoff states:** migrate legacy states to the controlled v0.2.1 values. The envelope additionally permits `not_applicable` for records that are not handoffs.
3. **Capacity versus jurisdiction:** `capacity_limited` means jurisdiction is recognized but capacity is insufficient. `constitutional_gap` means no identified authority has sufficient lawful jurisdiction.
4. **Response duties and clocks:** consequential referrals record the source and effect of any response duty, acknowledgment and decision clocks, a `GMEAIA-07` latency reference, and post-acceptance action clocks.
5. **Causal responsibility:** GMEAIA-20 distinguishes lawful jurisdiction, legal and practical causal control, resources, affected standing, transferred burdens, and upstream duties.
6. **Jointly constituted authority:** GMEAIA-01 and GMEAIA-20 may use `jointly_constituted` authority formation.
7. **Framework falsification:** GMEAIA-53 now includes theory of change, disconfirming evidence, and narrowing, suspension, replacement, and non-scaling conditions for frameworks and long-lived or systemically central mechanisms.
8. **Protected domains:** CP3 actions require GMEAIA-56 or GMEAIA-57 and the controlling specialized interface.
9. **Conformance versus success:** record validity cannot be used as evidence that an intervention worked.

## Legacy handoff guidance

| v0.1 value | v0.2.1 migration |
|---|---|
| `not_requested` | `not_applicable` for non-handoff records; otherwise omit until offered |
| `prepared` | `offered` only after transmission is ready and the recipient is identified |
| `sent` | `offered` |
| `received` | `acknowledged` |
| `accepted` | `accepted` |
| `partially_accepted` | `partially_accepted` |
| `rejected` | `refused` for a competent negative response; use record status `rejected` for invalid proposals or claims |
| `returned` | `returned` |
| `closed` | `closed` |
| `unresolved` | choose `deferred`, `timed_out`, `misrouted`, `capacity_limited`, or `constitutional_gap` based on the actual condition |

## Schema strategy

`governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1.schema.json` remains the backward-compatible filename for the record-envelope schema. `governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-specification.schema.json` separately validates the machine-readable specification catalogue. This corrects the v0.1 ambiguity in which the catalogue and record-envelope schema were not clearly separated.

## Adoption boundary

This package is a machine-readable release candidate. It does not by itself update EGP, IMT, WDIP, IRF, IAF, or any cluster registry. Exact downstream migration and adoption remain separate decisions.

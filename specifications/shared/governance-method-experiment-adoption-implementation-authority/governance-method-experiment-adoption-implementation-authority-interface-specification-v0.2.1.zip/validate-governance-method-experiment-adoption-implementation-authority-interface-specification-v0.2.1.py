#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys, zipfile
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent
BASE = 'governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1'


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def check(label, condition, details=""):
    results.append((label, bool(condition), details))

results = []
spec = load('governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1.json')
spec_schema = load('governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-specification.schema.json')
record_schema = load('governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1.schema.json')
example_names = ['governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-example.json', 'governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-example-authorized-trial.json', 'governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-example-capacity-limited-handoff.json', 'governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-example-framework-falsification.json']
examples = [(name, load(name)) for name in example_names]

try:
    Draft202012Validator.check_schema(spec_schema)
    check("Specification schema is valid", True)
except Exception as e:
    check("Specification schema is valid", False, str(e))

try:
    Draft202012Validator.check_schema(record_schema)
    check("Record schema is valid", True)
except Exception as e:
    check("Record schema is valid", False, str(e))

spec_errors = list(Draft202012Validator(spec_schema).iter_errors(spec))
check("Specification JSON conforms", not spec_errors, "; ".join(e.message for e in spec_errors[:5]))

for name, ex in examples:
    errors = list(Draft202012Validator(record_schema).iter_errors(ex))
    check(f"Example file {name} conforms", not errors, "; ".join(e.message for e in errors[:5]))

record_ids = [r['id'] for r in spec['records']]
check("60 canonical records", len(record_ids) == 60)
check("Record IDs unique", len(set(record_ids)) == 60)
check("Record IDs sequential", record_ids == [f"GMEAIA-{i:02d}" for i in range(1,61)])
action_ids = [a['id'] for a in spec['action_classes']]
check("18 action classes", action_ids == [f"A{i:02d}" for i in range(1,19)])
check("48 common header fields", len(spec['common_header_fields']) == 48 and [x['number'] for x in spec['common_header_fields']] == list(range(1,49)))
check("10 authority effect labels", len(spec['authority_effect_labels']) == 10)
check("10 protected-domain families", len(spec['protected_domains']) >= 10)
check("CP0-CP3 consequence profiles", [x['id'] for x in spec['consequence_profiles']] == ['CP0','CP1','CP2','CP3'])
check("13 handoff states", len(spec['handoff_states']) == 13)
check("capacity_limited distinct", 'capacity_limited' in spec['handoff_states'])
check("constitutional_gap distinct", 'constitutional_gap' in spec['handoff_states'])
check("22 conformance gates", len(spec['conformance_gates']) == 22)
check("16 v0.2 compound tests", len(spec['compound_tests']) == 16)
check("No stale P0-P3 consequence profiles", not any(re.fullmatch(r'P[0-3]', x['id']) for x in spec['consequence_profiles']))
check("Adopt remains non-consequential by default", spec['public_egp_mapping']['adopt']['consequential_effect'].startswith('none'))
check("Non-authority clause present", 'does not establish lawful authority' in spec['non_authority_clause'])

trial = examples[1][1]
check("Activated example has authority refs", trial['status'] == 'activated' and bool(trial['authority_record_refs']))
check("Activated example has activation refs", bool(trial['activation_record_refs']))
check("Activated example declares CP2", trial['payload'].get('consequence_profile') == 'CP2')
handoff = examples[2][1]
check("Capacity-limited example uses exact state", handoff['handoff_state'] == 'capacity_limited' and handoff['payload']['state'] == 'capacity_limited')
check("Capacity-limited example retains custody", bool(handoff['payload'].get('sender_duty_retained')) and bool(handoff['payload'].get('unresolved_duty_custody')))
falsification = examples[3][1]
check("Framework falsification example uses GMEAIA-53", falsification['record_type'] == 'GMEAIA-53')
check("Framework falsification example has stop conditions", all(falsification['payload'].get(k) for k in ['narrowing_condition','suspension_condition','replacement_or_deprecation_condition','non_scaling_condition']))

manifest_path = ROOT / 'governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-package-manifest.json'
if manifest_path.exists():
    manifest = load('governance-method-experiment-adoption-implementation-authority-interface-specification-v0.2.1-package-manifest.json')
    mismatches = []
    for item in manifest.get('payload_files', []):
        p = ROOT / item['filename']
        if not p.exists():
            mismatches.append(f"missing {item['filename']}")
            continue
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        if digest != item['sha256']:
            mismatches.append(f"hash {item['filename']}")
    check("Manifest payload hashes match", not mismatches, '; '.join(mismatches))

passed = sum(1 for _, ok, _ in results if ok)
failed = len(results) - passed
for label, ok, details in results:
    print(("PASS" if ok else "FAIL") + " — " + label + ((" — " + details) if details else ""))
print(f"\nPassed: {passed}/{len(results)}")
print(f"Failed: {failed}")
sys.exit(1 if failed else 0)

# Global Health–Aethelred Biological Incident Coordination Addendum v0.1

## Shared identity, plural assessment, bounded handoff, protected custody, and coordinated closure for biological incidents

**Document Type:** Emergency-cluster harmonization addendum  
**Status:** Normative interoperability specification — draft for implementation testing  
**Version:** 0.1  
**Date:** August 2026  
**Profile Identifier:** `GH-AE-BICA/0.1`

---

## Executive rule

> **A biological incident may engage health and biosafety functions at the same time. Shared event identity does not merge their authority, evidence, command, or legal effects.**

This Addendum coordinates **Global Health Preparedness, Outbreak Response, and Biosecurity Framework v2.2.1** and **Aethelred Accord v1.2.1** through the Emergency Cross-Domain Event Envelope v0.1, the Emergency and Catastrophic-Risk Cluster Record Profile v0.1, and the Emergency, Catastrophic-Risk, and Continuity Interface Specification v0.1.

It does not create a biological emergency authority, global biosafety regulator, health command, laboratory inspectorate, compulsory sample-access power, origin tribunal, public-health police function, or residual jurisdiction.

> **No valid authority record, no consequential biological-incident action.**

---

## 1. Purpose

The Addendum provides a common operational grammar for incidents in which population health and biotechnology governance overlap, including:

- laboratory exposure or containment deviation;
- suspected or confirmed release from a laboratory, manufacturing facility, repository, clinical trial, field trial, or environmental deployment;
- unexplained illness possibly linked to a biological activity;
- manufacturing contamination or product-quality failure;
- occupational exposure with possible community consequences;
- unexpected phenotype, host-range, persistence, transmissibility, or ecological effect;
- unauthorized access, transfer, modification, or use of biological material;
- biological-data, sequence, model, or automated-laboratory compromise;
- suspected deliberate misuse;
- origin disputes involving natural, industrial, laboratory, field-release, deliberate, mixed, or unknown hypotheses;
- restricted or protected samples needed for health or biosafety assessment; and
- compound incidents involving clinical, ecological, cyber, infrastructure, supply-chain, or security dependencies.

Its purpose is to ensure that one event can be coordinated without forcing one framework to absorb the functions of the other.

## 2. Controlling instruments and exact versions

This Addendum is compatible only with the following pinned instruments:

| Instrument | Version | SHA-256 |
|---|---:|---|
| Global Health Preparedness, Outbreak Response, and Biosecurity Framework | 2.2.1 | `429b08f3cdf5b1d5a2384986c6dde578f4e6146b92a9b5ea2470fc722a5ae7bd` |
| Aethelred Accord | 1.2.1 | `d470a9670123f83ae176e4e087de2b346713d413e079feca56e801c81a326959` |
| Emergency, Catastrophic-Risk, and Continuity Interface Specification | 0.1 | `c673742b1317c7169d4b8226118478c990e9a3d05084b2dc5ac9ad2f1971163c` |
| Emergency and Catastrophic-Risk Cluster Record Profile | 0.1 | `19f35a53c151182ff6bf2760f7da67b9696fbf0048dfef27af9748de36b94dc9` |
| Emergency Record Inheritance Clause | 0.1 | `1e7ecacdcf8afb946c7bb5733b6e95f1d6c435851b529e2482840a0ae9640e39` |
| Emergency Cross-Domain Event Envelope | 0.1 | `68ee2c48383199e4b91b365ea21e35d5a729f0a72854472acf6f8ae103f0c192` |
| Emergency Cross-Domain Event Envelope JSON Schema | 0.1 | `78637f4b3e07dbbca94ade09d154e3dd62a8e562002b96e7cd2613d2ce2cd4f5` |

A later version is not substituted automatically. A material change to event identity, authority provenance, handoff, custody, access, renewal, termination, or restoration fails closed until compatibility is tested and recorded.

## 3. Non-authority and non-merger clause

This Addendum does not:

- declare a public-health or biosafety emergency;
- create jurisdiction over a facility, territory, population, sample, sequence, model, organism, or ecological relation;
- authorize inspection, testing, isolation, quarantine, treatment, vaccination, seizure, shutdown, destruction, recall, publication restriction, secrecy, surveillance, armed deployment, or sanctions;
- determine legal causation, fault, liability, guilt, ownership, consent, Indigenous authority, or compensation;
- convert scientific confidence into legal authority;
- make Global Health the supervisor of Aethelred functions;
- make Aethelred the supervisor of Global Health functions;
- make a joint coordination cell a commander; or
- permit the Planetary Immune System to take over.

Every consequential action requires its own competent authority, ECRC provenance, rights safeguards, scope, expiry, review, and remedy.

## 4. Relationship to the Cross-Domain Event Envelope

Every incident using this Addendum shall have one `cluster_event_id` in a conformant CDEE Envelope. The Addendum creates a linked **Biological Incident Coordination Packet** (`BICP`), not a replacement Envelope and not an additional emergency authority record.

The Packet shall reference:

- the CDEE `cluster_event_id`;
- the specific `envelope_id` and schema version;
- the engaged Global Health and Aethelred framework versions;
- relevant ECRC records;
- domain event identifiers;
- responsibility assignments;
- handoffs;
- custody assignments;
- review times; and
- closure and unresolved-risk references.

The Envelope remains the cluster identity and routing layer. The Packet supplies biological-domain detail.

## 5. Applicability trigger

This Addendum applies when at least one of the following is true:

1. a health signal may originate from, affect, or require action within a biotechnology activity, facility, release, product, sample system, or biological manufacturing chain;
2. a biosafety incident may produce occupational, clinical, community, cross-border, or population-health consequences;
3. Global Health or Aethelred requests a function, record, sample, estimate, or assistance from the other;
4. origin or causation hypotheses cross the natural–industrial–laboratory–field-release boundary;
5. health and biosafety functions need concurrent custody, communication, or review; or
6. a compound biological incident cannot be safely closed by either framework alone.

The Addendum may be used at CDEE-L1 for non-coercive coordination. Consequential response requires CDEE-L2 and valid ECRC records.

## 6. Incident identity and domain identifiers

The following identifiers shall remain distinct:

- `cluster_event_id`: immutable identity for the compound event;
- `envelope_id`: versioned CDEE serialization;
- `coordination_packet_id`: versioned BICP serialization;
- Global Health domain event identifier;
- Aethelred domain event identifier;
- facility incident identifier where applicable;
- occupational-exposure identifier where applicable;
- clinical cluster or outbreak identifier where applicable;
- field-release or deployment identifier where applicable;
- sample, evidence, construct, product, lot, and repository identifiers where lawful.

Shared identifiers support linkage. They do not merge custody, authority, access rights, evidence status, or legal meaning.

## 7. Provisional incident classes

A Packet may carry multiple active, disputed, or superseded incident classes:

- `occupational_exposure`;
- `containment_deviation_or_near_miss`;
- `confirmed_containment_failure`;
- `laboratory_associated_infection_signal`;
- `manufacturing_contamination`;
- `product_quality_or_potency_failure`;
- `field_trial_deviation`;
- `unexpected_environmental_persistence`;
- `uncontrolled_environmental_release`;
- `unexpected_phenotype_or_host_range`;
- `unauthorized_access_or_transfer`;
- `biological_data_or_sequence_compromise`;
- `automated_laboratory_or_cyber_incident`;
- `suspected_deliberate_misuse`;
- `natural_or_community_event_with_facility_proximity`;
- `mixed_or_cascading_event`; and
- `unknown`.

Classification is routing information. It is not a finding of origin, fault, criminality, licence breach, or emergency status.

## 8. Origin and causation hypotheses

The Packet may preserve simultaneous hypotheses, including:

- natural emergence;
- ecological disturbance;
- industrial or occupational amplification;
- clinical or manufacturing contamination;
- laboratory-associated incident;
- authorized field release with unexpected effect;
- unauthorized release;
- deliberate misuse;
- unrelated coincident events;
- mixed pathway; and
- unknown.

Each hypothesis shall record:

- statement and scope;
- status;
- confidence or probability where methodologically appropriate;
- supporting and contrary references;
- estimator and independence status;
- known dependencies and model assumptions;
- missing evidence;
- next discriminating observation;
- last update and supersession history; and
- communication restrictions where justified.

No institution may select a single official origin merely to simplify command or public messaging. Scientific convergence does not itself establish legal causation or liability.

## 9. Function-level responsibility matrix

Responsibility shall be assigned by function, not by whole-event ownership.

| Function | Default domain lead | Possible concurrent domain | Non-transferable boundary |
|---|---|---|---|
| Population-health observation and case definition | Global Health | Aethelred supplies activity and material context | Does not authorize facility action |
| Clinical care and health-system continuity | Global Health | Aethelred supplies exposure and material information | Does not authorize laboratory inspection |
| Public-health assistance and health measures | Global Health | Aethelred supplies biosafety evidence | Requires separate health authority and rights records |
| Countermeasure allocation and essential-care continuity | Global Health | Aethelred supports manufacturing and access safety | Does not create patent or procurement power |
| Facility containment and operator safety systems | Aethelred | Global Health supplies exposure and clinical data | Does not authorize population restrictions |
| Construct, organism, process, and release assessment | Aethelred | Global Health supplies transmission and severity evidence | Does not decide clinical treatment |
| Genetic, sample, and use provenance | Aethelred | Global Health may hold clinical or evidentiary custody | Does not erase personal, collective, Indigenous, or evidentiary claims |
| Manufacturing biosafety and product-process integrity | Aethelred | Global Health assesses product health consequences | Does not allocate scarce countermeasures |
| Worker exposure protection | Concurrent | Concurrent | Employer, health, regulator, and worker duties remain distinct |
| Event-origin assessment | Plural/concurrent | Plural/concurrent | No joint body becomes origin adjudicator |
| Sample and evidence custody | Custody-specific | Custody-specific | Physical receipt does not grant use or onward-transfer rights |
| Public information and correction | Function-specific concurrent | Function-specific concurrent | No unified political narrative or suppression authority |
| Emergency review, termination, and restoration | Authority-specific concurrent | Authority-specific concurrent | One domain cannot renew or terminate another domain’s power |
| Wrongful-action remedy | Competent claims or justice function | Both domains supply records | Coordination does not adjudicate liability |

The Packet shall identify active, concurrent, contested, transferred, retained, and unassigned responsibilities separately.

## 10. Coordination steward and joint cell limits

A biological coordination steward or joint cell may:

- maintain the Packet;
- reconcile identifiers;
- route records and notices;
- track acknowledgements and response deadlines;
- expose responsibility gaps and conflicts;
- maintain review calendars;
- coordinate non-binding technical meetings;
- preserve correction and supersession history; and
- prepare closure-readiness checks.

It may not:

- command health or biosafety functions;
- declare an emergency;
- order a facility pause or public-health measure;
- decide sample access;
- resolve origin or causation disputes by fiat;
- accept a handoff for another authority;
- remove a protection marking;
- disclose dual-use or Indigenous-protected information;
- renew powers; or
- keep powers alive by keeping the Packet open.

## 11. Engagement triggers from Global Health to Aethelred

Global Health should notify the competent Aethelred function when there is a reasonable basis to investigate:

- a facility, manufacturing, repository, research, clinical-trial, or field-release connection;
- an unusual construct, phenotype, resistance pattern, genetic signature, or process anomaly;
- occupational cases associated with a regulated biological activity;
- exposure that may require facility containment or operator action;
- samples whose use depends on genetic authority or protected non-transfer;
- a dual-use method or sequence disclosure concern;
- a product, lot, platform, or manufacturing-chain contamination; or
- a laboratory automation, cyber, or access-control anomaly.

Notification is not an accusation, licence finding, or facility-action order.

## 12. Engagement triggers from Aethelred to Global Health

Aethelred should notify the competent Global Health function when there is a reasonable basis to investigate:

- worker, participant, patient, or community exposure;
- possible human-to-human, animal-to-human, or environmental transmission;
- a need for clinical surveillance, diagnostics, prophylaxis, treatment, or health follow-up;
- a product-safety or manufacturing event affecting patients or supply;
- a release with possible population-health consequences;
- a need for health-system readiness or essential-care continuity;
- a cross-border health risk; or
- a countermeasure access or allocation dependency.

Notification does not declare an outbreak, authorize health measures, or establish causation.

## 13. Handoff offer and acceptance

Every handoff shall identify:

- the responsibility or information being offered;
- sender and receiver;
- legal and professional basis;
- scope offered;
- records and access restrictions;
- dependencies and known deficiencies;
- sender-retained duties;
- requested response time;
- receiver conditions;
- accepted scope;
- effective time;
- review and closure conditions; and
- disposition of rejected or withdrawn material.

Permitted states are:

- `draft`;
- `offered`;
- `received_not_reviewed`;
- `deficient`;
- `accepted_partial`;
- `accepted_full`;
- `concurrent`;
- `rejected`;
- `withdrawn`;
- `superseded`; and
- `closed`.

Receipt is not acceptance. Silence is not acceptance. Acceptance of information is not acceptance of command, liability, custody, or jurisdiction.

## 14. Concurrent responsibility

Concurrent responsibility is appropriate when two functions must act without either becoming subordinate to the other. The Packet shall record:

- the common objective;
- each actor’s distinct function;
- authority and scope;
- dependencies;
- retained duties;
- conflict-resolution route;
- review times;
- communication responsibilities;
- failure and fallback arrangements; and
- separate termination conditions.

Concurrent responsibility shall not be represented as “joint command” unless a separately valid instrument expressly creates a command relationship and satisfies the Emergency Interface.

## 15. Responsibility conflict and unresolved jurisdiction

Where responsibility is contested:

1. preserve the conflict in the Envelope and Packet;
2. continue non-disputed protective duties;
3. identify the competent forum or constituting authorities;
4. prevent the coordination steward from assigning jurisdiction;
5. record interim, voluntary, or no-regret measures and their bases;
6. preserve evidence and rights;
7. set a review time; and
8. place unresolved material in `ECRC-33` when it persists.

An unresolved jurisdiction does not create residual authority in Global Health, Aethelred, PIS, Meta-Governance, a scientific panel, a fund, a platform, or a court acting outside a valid case.

## 16. Sample taxonomy and identifiers

The Packet should distinguish:

- clinical diagnostic samples;
- occupational-exposure samples;
- environmental samples;
- facility-monitoring samples;
- construct or organism reference material;
- production, product, or lot samples;
- repository samples;
- Indigenous, familial, community, ecological, or culturally governed samples;
- evidentiary samples;
- split or derivative samples;
- sequence, model, image, phenotype, and metadata derivatives; and
- destroyed, exhausted, returned, repatriated, or unlocated material.

A sample identifier shall not disclose protected content or location unnecessarily. Derivatives shall preserve provenance and restrictions.

## 17. Sample authority and custody

For each sample or derivative, the Packet shall identify where lawful:

- physical custodian;
- legal or professional authority for custody;
- collector and collection context;
- source and affected persons or peoples;
- permitted purposes;
- prohibited uses;
- testing and sequencing permissions;
- publication and AI-training rules;
- onward-transfer rules;
- evidentiary status;
- biosafety conditions;
- retention and review time;
- return, destruction, deletion, or repatriation condition;
- access and audit history; and
- contested claims or provenance gaps.

Physical possession does not imply ownership, research permission, publication authority, AI-training permission, or onward-transfer authority.

## 18. Protected and Indigenous samples, data, and knowledge

An emergency request for protected material shall identify:

- the precise material or information requested;
- purpose and necessity;
- alternatives considered;
- requesting authority;
- affected Indigenous nation or other protected authority;
- permitted method of access, including sealed, local, aggregate, or no-transfer analysis;
- duration;
- benefit and burden distribution;
- disclosure and publication limits;
- derivative and model controls;
- return, deletion, destruction, or repatriation; and
- unresolved status if no valid pathway exists.

Catastrophic importance does not erase authority. Where access is refused or unavailable, alternative samples, methods, treatments, and protective actions shall be pursued. A record of refusal is not evidence of obstruction or liability.

## 19. Split samples and independent verification

Where lawful and scientifically appropriate, split-sample arrangements may support independent verification. They shall specify:

- splitting method and responsible personnel;
- biosafety and quality controls;
- aliquot identifiers;
- custody and destination;
- permitted analyses;
- access classes;
- blind or coded procedures;
- dispute-resolution method;
- exhaustion limits;
- return or destruction; and
- rules for discrepant results.

Independent verification does not require unrestricted transfer. Local analysis, mobile laboratories, sealed computation, controlled query, aggregate attestation, or observer access may be used.

## 20. Evidence chain and scientific material

Scientific samples and data may also become evidence. The Packet shall distinguish:

- operational health material;
- regulatory material;
- research material;
- protected-source material;
- whistleblower material;
- judicial or prosecutorial evidence; and
- public-information material.

`ECRC-24` Investigation and Evidence Handoff shall govern evidence transfer. `ECRC-25` Adjudication and Enforcement Handoff requires a separate initiation. A biosafety assessment, epidemiological estimate, or chain-of-custody transfer does not establish guilt, liability, or sanction.

## 21. Laboratory incident coordination

A laboratory incident coordination package should address:

- facility and competent regulator;
- biosafety activity profile;
- incident class and uncertainty;
- material, construct, process, and containment state;
- affected workers and contractors;
- clinical assessment and follow-up;
- possible community exposure;
- ventilation, waste, transport, and environmental pathways;
- immediate measures and their legal or occupational basis;
- sample and evidence custody;
- automation, cyber, and access-control state;
- public-information responsibilities;
- assistance requested;
- facility continuity and safe shutdown needs; and
- review, stand-down, handback, and worker compensation.

Facility action remains with the competent regulator, operator, court, or other valid authority. Health functions may recommend action but do not acquire facility jurisdiction.

## 22. Field-release and environmental incident coordination

A field-release incident package should address:

- authorized release and conditions;
- geography, ecology, season, pathways, and affected territories;
- construct or organism identity and uncertainty;
- persistence, dispersal, reproduction, transfer, and host-range evidence;
- monitoring baselines and deviations;
- affected Indigenous nations, land authorities, communities, livelihoods, and ecosystems;
- human and animal health signals;
- containment, recall, remediation, or monitoring options;
- intervention and non-intervention harms;
- cross-border notification;
- protected knowledge and genetic provenance;
- liability and restoration interfaces; and
- long-term custody of residual uncertainty.

An unexpected signal does not automatically authorize eradication, territorial entry, sample seizure, or override of affected authorities.

## 23. Manufacturing, product, and supply incidents

Where manufacturing contamination, process deviation, potency failure, or product integrity is suspected, the Packet shall distinguish:

- manufacturing biosafety;
- product quality;
- clinical safety and effectiveness;
- supply continuity;
- recall or hold authority;
- countermeasure allocation;
- alternative production capacity;
- worker exposure;
- lot and distribution traceability;
- public communication; and
- compensation and remedy.

A recall, production pause, compulsory licence, procurement action, or allocation rule requires its own valid legal basis.

## 24. Biological-data, sequence, model, automation, and cyber incidents

The Packet shall identify:

- compromised system or dataset;
- biological and cyber consequences;
- affected constructs, workflows, access controls, or automated actions;
- data and model provenance;
- unauthorized query, export, synthesis, or execution risk;
- containment and restoration responsibilities;
- health consequences;
- dual-use restrictions;
- notification and correction; and
- evidence preservation.

Technology Governance v3.6 and Aurora Accord v1.3 govern relevant technical, data, identity, and security interfaces. Cyber response does not create authority over biological activities, and biological urgency does not create unrestricted cyber access.

## 25. Dual-use information coordination

Information shall be classified by concrete risk and legal basis, not by a framework label. The Packet should distinguish:

- information required for immediate clinical protection;
- information required for facility containment;
- information required for independent review;
- information suitable for public warning or correction;
- information requiring restricted operational access;
- protected source, Indigenous, personal, commercial, or security information;
- high-consequence enabling detail; and
- information whose restriction would impede defence, accountability, or scientific correction.

Restriction shall be scoped, reasoned, time-limited, reviewable, and recorded in `ECRC-19` and `ECRC-20`. No coordination body may suppress criticism, adverse findings, whistleblowing, or exculpatory evidence by calling it dual use.

## 26. Countermeasure development, manufacturing, and access

When an incident creates a need for diagnostics, prophylaxis, treatment, vaccines, antidotes, environmental remediation, or other countermeasures:

- Global Health leads population need, clinical evidence, allocation, and essential-care continuity within valid authority;
- Aethelred leads relevant manufacturing biosafety, construct/process safety, provenance, and release controls;
- access, patent, procurement, public manufacturing, and price powers remain with competent legal and fiscal instruments;
- safety review and allocation remain separate;
- manufacturing evidence shall not be hidden from health decision-makers;
- scarce access shall not be conditioned on genetic-data surrender, research participation, public messaging, or framework membership; and
- emergency access arrangements shall include termination, ordinary-law transition, and data/sample disposition.

## 27. Worker, participant, patient, and community protection

The Packet shall link protections for:

- laboratory and manufacturing workers;
- cleaners, couriers, animal-care, maintenance, waste, and contractor personnel;
- clinical workers and community health personnel;
- trial participants and patients;
- nearby communities;
- Indigenous peoples and land defenders;
- whistleblowers and adverse-result reporters; and
- responders and inspectors.

Minimum protection includes hazard information, confidential health care, paid leave, wages and hazard pay, insurance, safe refusal, non-retaliation, representation, immigration and employment protection, family support, long-term exposure follow-up, disability accommodation, and compensation routes.

## 28. Public information and correction

Public communication may provide:

- service and protective information;
- known facts and uncertainty;
- what is being investigated;
- separate health and biosafety responsibilities;
- corrections and supersession;
- access to care and worker reporting routes;
- rights, review, and complaint routes; and
- reasons for temporary information protection.

Communication shall not:

- assert an official origin without sufficient support;
- treat uncertainty as guilt;
- stigmatize workers, communities, facilities, regions, species, or peoples;
- conceal material conflicts or dissent;
- manufacture a unifying political narrative;
- use fear to secure unrelated policy support; or
- imply that public communication itself creates legal authority.

Where messages differ, the Packet shall preserve each responsible function, evidence basis, audience, correction path, and unresolved disagreement.

## 29. Cross-border assistance and host authority

Cross-border health, laboratory, environmental, technical, or logistics assistance requires:

- requesting and accepting authorities;
- mission and excluded functions;
- host command and professional accountability;
- personnel credentials;
- facility and territorial access;
- sample and data rules;
- protected non-transfer;
- worker and community safeguards;
- security and claims arrangements;
- public communication;
- handback, data disposition, and compensation; and
- termination.

A hospital, laboratory, researcher, community, or coordination steward may request assistance, but only a competent authority can authorize access or powers beyond its own lawful control.

## 30. Emergency activation, review, and renewal

A biological incident may remain in ordinary assessment and voluntary assistance. When consequential emergency powers are proposed, the Packet shall link:

- `ECRC-03` state estimate;
- `ECRC-04` authority provenance;
- `ECRC-06` declaration;
- `ECRC-08` power activation;
- `ECRC-13` rights and non-derogation;
- applicable health, isolation, work, data, protected-knowledge, and assistance records;
- `ECRC-22` interim review where applicable; and
- `ECRC-26` renewal estimate.

The 72-hour, 30-day, and 90-day architecture applies separately to each authority and power. One domain cannot renew the other’s power. An open Packet or unresolved origin does not justify renewal.

## 31. Termination, restoration, and closure

Biological-incident closure requires function-specific verification, including where applicable:

- termination of declarations and powers;
- facility stand-down or ordinary regulatory transition;
- worker and patient follow-up;
- authority, access, facility, asset, and credential return;
- sample and data disposition;
- completion or transfer of claims;
- correction and archival;
- ordinary health and biosafety capacity handback;
- after-action review; and
- entry of residual uncertainty, long-term monitoring, unresolved causation, and dissent in `ECRC-33`.

The CDEE Envelope and BICP may close while scientific or legal questions remain unresolved. Unresolved questions do not keep emergency powers alive.

## 32. Minimum linked ECRC bundle

Every active Packet shall link the ECRC records triggered by its actual functions. The following profile is the minimum coordination crosswalk:

| ECRC | Biological coordination use |
|---|---|
| `ECRC-01` | initial biological signal or alert |
| `ECRC-02` | observation independence across health, facility, community, and laboratory sources |
| `ECRC-03` | plural health and biosafety state estimates |
| `ECRC-04` | authority provenance for each consequential actor |
| `ECRC-05` | standing and jurisdiction review |
| `ECRC-06` | lawful declaration where one exists |
| `ECRC-07` | action-class classification |
| `ECRC-08` | power-specific activation |
| `ECRC-09` | mission scope and command |
| `ECRC-10` | host request and acceptance |
| `ECRC-11` | Indigenous and affected-community interface |
| `ECRC-12` | uncertainty, alternatives, and reversibility |
| `ECRC-13` | rights and non-derogation |
| `ECRC-14` | bodily-integrity and health measures |
| `ECRC-16` | worker and responder mobilisation |
| `ECRC-17` | essential care and income continuity |
| `ECRC-18` | finance, procurement, compensation, and reserves |
| `ECRC-19` | data, privacy, security, and secrecy |
| `ECRC-20` | protected knowledge, samples, and non-transfer |
| `ECRC-21` | public information and correction |
| `ECRC-22` | urgent or interim measure review |
| `ECRC-23` | cross-border assistance |
| `ECRC-24` | investigation and evidence handoff |
| `ECRC-25` | separately initiated adjudication or enforcement handoff |
| `ECRC-26` | renewal state estimate |
| `ECRC-27` | termination certificate |
| `ECRC-28` | authority, facility, asset, and access restoration |
| `ECRC-29` | emergency data and sample disposition |
| `ECRC-30` | wrongful action and compensation |
| `ECRC-31` | after-action and ordinary-capacity review |
| `ECRC-32` | temporary institutional continuation or sunset |
| `ECRC-33` | unresolved risk, causation, restoration, and dissent custody |

`ECRC-15` applies where isolation, evacuation, exclusion, relocation, or shelter is used. Records not triggered remain event-specifically not applicable with reasons; missing mappings do not permit omission.

## 33. Adoption clause for Global Health

Global Health v2.2.1 may adopt this Addendum through the following clause:

> **Global Health–Aethelred coordination.** When a biological incident engages functions governed by Aethelred Accord v1.2.1, this framework uses Global Health–Aethelred Biological Incident Coordination Addendum v0.1 and CDEE v0.1 for shared event identity, function-level responsibility, handoff, custody, review, and closure. The Addendum does not transfer health authority, create facility jurisdiction, or replace ECRC authority and rights records.

## 34. Adoption clause for Aethelred

Aethelred v1.2.1 may adopt this Addendum through the following clause:

> **Aethelred–Global Health coordination.** When a biological incident engages population-health, clinical, health-measure, countermeasure-allocation, or essential-care functions governed by Global Health v2.2.1, this Accord uses Global Health–Aethelred Biological Incident Coordination Addendum v0.1 and CDEE v0.1 for shared event identity, function-level responsibility, handoff, custody, review, and closure. The Addendum does not transfer biosafety or genetic authority, create health jurisdiction, or replace ECRC authority and rights records.

## 35. Machine-readable Biological Incident Coordination Packet

The companion JSON Schema defines a Packet with:

- identity and version pins;
- incident classes and origin hypotheses;
- domain engagements;
- function-level responsibilities;
- handoffs;
- sample and evidence custody;
- protected-material conditions;
- dual-use information classifications;
- countermeasure coordination;
- worker and community protections;
- public-information responsibilities;
- review and closure; and
- a mandatory non-authority statement.

The Packet references, rather than embeds or overrides, the CDEE Envelope and ECRC records.

## 36. Conformance levels

- **BICA-L0 — Identity:** CDEE identity and pinned framework versions.
- **BICA-L1 — Coordination:** incident classes, plural hypotheses, engagements, responsibilities, handoffs, and custody.
- **BICA-L2 — Consequential response:** complete applicable ECRC provenance, rights, action, data, work, assistance, and review links.
- **BICA-L3 — Closure:** termination, restoration, disposition, compensation, after-action, and unresolved-risk custody.

BICA-L0 and BICA-L1 do not authorize consequential action.

## 37. Required implementation tests

An implementation shall test at least:

1. laboratory exposure without community transmission;
2. community cluster with an unconfirmed facility connection;
3. simultaneous natural and laboratory-origin hypotheses;
4. false-positive genomic or sensor alert;
5. manufacturing contamination affecting a scarce countermeasure;
6. field-release deviation with no human cases;
7. field-release deviation with possible human exposure;
8. occupational cases reported by a whistleblower;
9. protected Indigenous sample requested for incident analysis;
10. sample access refused and alternative method used;
11. split samples with discrepant laboratory results;
12. evidence custody transfer without adjudication referral;
13. adjudication referral rejected while health response continues;
14. dual-use detail needed for facility containment but restricted publicly;
15. cyber compromise of an automated laboratory;
16. cross-border assistance requested by a facility but not yet accepted by host authority;
17. concurrent responsibility with no joint command;
18. receiver acknowledges but does not accept a handoff;
19. 72-hour provisional measure expires while origin remains unresolved;
20. 30-day renewal requested by one domain but not the other;
21. facility handback while long-term health follow-up continues;
22. emergency sample and data disposition after closure;
23. wrongful quarantine or facility action claim;
24. event closes with causation and scientific dissent in `ECRC-33`.

## 38. Amendment and compatibility

Material changes require a compatibility review against the pinned instruments and tests above. At minimum, changes to these objects are material:

- identifier semantics;
- responsibility states;
- handoff acceptance;
- custody and protected non-transfer;
- evidence/adjudication separation;
- ECRC linkage;
- renewal and termination;
- closure;
- access classification; and
- non-authority boundaries.

A compatible update may add fields or stronger safeguards without changing authority. A breaking change requires a new profile version and explicit adoption.

## 39. Conclusion

Biological incidents are especially prone to jurisdictional collapse because the same event can simultaneously be a workplace exposure, clinical cluster, laboratory deviation, product failure, ecological release, data compromise, criminal allegation, and public emergency.

The solution is not to place all functions under one biological command. It is to make responsibility, evidence, custody, rights, handoff, review, and closure explicit enough that plural competent authorities can act quickly without silently inheriting one another’s powers.

> **One biological event; distinct lawful functions; protected custody; explicit handoffs; no residual command.**

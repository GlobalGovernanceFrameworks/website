# Emergency–Security Dual-Interface Bridge v0.1

## A non-authoritative compatibility layer between emergency-event coordination and security, coercion, mobility, justice, and protective-action routes

**Specification ID:** `ESDIB/0.1`  
**Status:** Draft for cluster adoption and compound implementation testing  
**Date:** 2026-08-01  
**Emergency constitutional parent:** *Emergency, Catastrophic-Risk, and Continuity Interface Specification v0.1 (`ECRCI/0.1`)*  
**Emergency record parent:** *Emergency and Catastrophic-Risk Cluster Record Profile v0.1 (`ECRC/0.1`)*  
**Emergency transport parent:** *Emergency Cross-Domain Event Envelope v0.1 (`CDEE/0.1`)*  
**Security constitutional parent:** *Security, Coercion, and Protective Action Interface Specification v0.1 (`SCPA/0.1`)*  
**Security record parent:** *SCPA Record Inheritance and Conformance Clause v0.1 (`SCPA-RIC/0.1`)*  
**Protective-action transport parent:** *Cross-Framework Protective Action Envelope v0.1 (`CFPAE/0.1`)*

---

# Executive rule

> **The Emergency–Security Dual-Interface Bridge links one emergency event and one or more protective-action clusters without allowing either stack to supply the authority, jurisdiction, command, clock, custody, evidence, remedy, or legal effect missing from the other.**

The Bridge is a compatibility object. It records when an emergency context and an SCPA action route concern the same situation, which records are linked, which authorities remain responsible, what information or material may cross, which clocks control, and how termination and remedy are coordinated.

It is not `ECRC-34`, `SCPA-45`, a declaration, a warrant, a detention order, a force authorization, a border mandate, a sanctions instrument, an intelligence charter, an emergency command, a court, or a new institution.

> **Emergency urgency does not create security authority. Security authority does not create or prolong an emergency.**

> **Two interfaces; separate powers; one explicit bridge; no authority by urgency, packaging, capability, or silence.**

---

# 1. Purpose

Emergency and security functions overlap in practice without being constitutionally identical. A storm may require evacuation, shelter, border admission, family tracing, cyber defence, asset protection, public information, and converted logistics. A biological incident may require care, isolation, protected laboratory information, evidence preservation, investigation, and non-refoulement. A cyberattack may be both an infrastructure emergency and a criminal matter. An armed threat may affect humanitarian access without turning humanitarian responders into security forces.

The emergency stack and the SCPA stack deliberately separate these functions:

- `CDEE/0.1` supplies stable event identity and domain engagement without shared command;
- `ECRC/0.1` supplies thirty-three emergency records for alert, authority, declaration, activation, operations, rights, data, assistance, review, termination, restoration, and learning;
- `CFPAE/0.1` supplies stable protective-action identity and explicit SCPA routes, responsibilities, handoffs, custody, clocks, remedy, and closure;
- `SCPA/0.1` supplies forty-four records for authority, intelligence, investigation, compulsory process, urgent protection, custody, force, cyber action, financial coercion, mobility consequences, adjudication, remedy, data disposition, succession, and non-activation.

Without a bridge, implementers may make one of two opposite errors:

1. **authority laundering:** treating emergency declaration, command, urgency, assistance, secrecy, finance, or event identity as sufficient authority for a security or coercive act; or
2. **coordination failure:** refusing or delaying lawful protection because no common object shows how separately authorized emergency and SCPA routes relate.

This Specification prevents both errors.

# 2. Scope

The Bridge applies when at least one CDEE/ECRC event and at least one CFPAE/SCPA action route are materially linked by facts, affected persons, place, asset, system, evidence, command, data, finance, converted capability, review, termination, or remedy.

Use is mandatory when any trigger in Section 7 is present. Use is optional for emergency-only or security-only matters where a future cross-stack handoff is reasonably foreseeable. It is unnecessary when the matter remains wholly within one stack and no protected or consequential function crosses the boundary.

The Bridge may coordinate:

- urgent rescue, separation, evacuation, shelter, transport, isolation, quarantine, or treatment that may become restraint or custody;
- emergency border admission, asylum access, family tracing, identity reconstruction, non-refoulement, transfer, return, or guarded movement;
- protected emergency information offered to an intelligence, investigative, evidentiary, judicial, sanctions, or mobility function;
- emergency cyber defence that may become third-party access or disruption;
- emergency finance that may become a freeze, seizure, forfeiture, sanction, exclusion, or compulsory transfer;
- armed or security personnel, weapons, special equipment, command, force, detention, or crowd control in an emergency setting;
- mutual aid that may become mutual legal assistance or cross-border operational action;
- Aegis-converted capabilities used in an emergency and later proposed for security-facing functions;
- termination of emergency powers while ordinary SCPA proceedings continue;
- continuation of emergency services while security institutions suspend, dissolve, or transfer; and
- coordinated correction, release, return, compensation, data disposition, and institutional remedy after wrongful action.

# 3. Legal character and non-authority

The Bridge has `authority_effect: none`.

It may:

- link identifiers;
- display record dependencies;
- route offers and acknowledgements;
- document acceptance, rejection, deficiency, partial acceptance, or concurrent responsibility;
- preserve access restrictions and custody;
- compare clocks;
- issue administrative reminders;
- coordinate correction, termination, restoration, remedy, and closure; and
- reveal that an action is blocked because one required record or authority is absent.

It may not:

- declare an emergency;
- establish causation, dangerousness, guilt, liability, status, or jurisdiction;
- activate or renew a power;
- transform emergency assistance into investigation or enforcement;
- transform intelligence into evidence or adjudication;
- command personnel or assets;
- order disclosure, search, entry, seizure, restraint, detention, force, cyber disruption, sanctions, transfer, or removal;
- waive rights or protected non-transfer rules;
- extend a review or expiry clock;
- convert an Aegis capability to security use; or
- preserve authority after termination.

# 4. Identity model

## 4.1 Stable bridge identifier

Each Bridge instance SHALL have an immutable `dual_interface_bridge_id`. The identifier denotes one defined relationship between an emergency event and one or more protective-action clusters. It does not replace either parent identity.

## 4.2 Parent identities

A conforming Bridge SHALL retain:

- at least one `CDEE cluster_event_id`;
- at least one `CFPAE protective_action_cluster_id`;
- versioned CDEE and CFPAE envelope identifiers;
- local emergency, security, migration, peace, community-safety, health, justice, cyber, asset, and mission identifiers where applicable;
- all linked ECRC and SCPA record-instance identifiers.

The CDEE event identifier, CFPAE protective-action identifier, and Bridge identifier SHALL remain distinct. Validation SHALL reject any object that equates or overwrites them.

## 4.3 Versioned bridge records

Each update SHALL create a new `bridge_version` while preserving immutable history, corrections, superseded links, and the states that were known at the time.

## 4.4 Topology

A Bridge may have parents, children, splits, merges, and related Bridges. Splitting or merging coordination objects cannot split or merge legal authorities. Every consequential route retains its own canonical records.

# 5. Relationship to CDEE and CFPAE

CDEE coordinates event identity, observed context, domain engagement, event-level responsibility, custody, public information, review, and event closure. CFPAE coordinates protective-action routes, authorities, action-specific responsibility, SCPA records, affected-person interfaces, custody, clocks, remedy, and action closure.

The Bridge SHALL NOT duplicate either envelope in full. It SHALL carry only the fields necessary to:

1. prove which exact CDEE and CFPAE objects are linked;
2. identify the cross-stack trigger;
3. identify corresponding ECRC and SCPA records;
4. record whether the proposed relationship is contextual, supporting, conditional, accepted, rejected, or prohibited;
5. preserve independent authorities, commands, custody, access, review, expiry, and remedy;
6. coordinate termination and detachment; and
7. record unresolved incompatibility or protected non-transfer.

An event may have no CFPAE object. A protective-action cluster may have no CDEE object. A Bridge is created only when a material cross-stack relationship exists or is proposed.

# 6. Governing constitutional principles

1. **Severity determines urgency and scale, not authority.**
2. **No valid authority record, no consequential action.**
3. **Emergency declaration is not SCPA activation.**
4. **SCPA authorization is not an emergency declaration.**
5. **Shared facts are not shared jurisdiction.**
6. **Shared logistics are not shared command.**
7. **Emergency assistance is not mutual legal assistance.**
8. **Protected information is not investigation authority.**
9. **Health purpose does not erase custody or force.**
10. **Humanitarian transport does not create border or detention authority.**
11. **Emergency cyber defence does not create third-party disruption authority.**
12. **Emergency finance does not create sanctions or asset-seizure authority.**
13. **Review by one body does not renew another body's power.**
14. **The earlier expiry controls an act that depends on both legal bases.**
15. **Termination of one basis requires detachment, narrowing, or cessation—not silent continuation.**
16. **Unresolved risk does not preserve residual power.**
17. **Aegis reversion suspends civilian assurances but does not authorize security use.**
18. **The stronger rights, access, notice, source-protection, child, survivor, disability, labour, Indigenous, and non-refoulement safeguard governs.**

# 7. Mandatory Bridge triggers

| Trigger | Condition |
|---|---|
| `DIB-T01` | Emergency declaration or activation proposes an act matching SCPA Classes B–K. |
| `DIB-T02` | An SCPA action relies on an emergency declaration, emergency command, emergency finance, emergency data access, emergency asset, or emergency territorial arrangement. |
| `DIB-T03` | Isolation, quarantine, evacuation, shelter, transport, or treatment includes blocked exit, restraint, guarded custody, compelled movement, or force. |
| `DIB-T04` | Emergency screening, registration, identity, border, asylum, transfer, return, or corridor activity may produce adverse mobility consequences. |
| `DIB-T05` | Emergency cyber action accesses or alters a third-party system, redirects traffic, suspends an account, disrupts infrastructure, or collects evidence. |
| `DIB-T06` | Emergency finance proposes a freeze, seizure, forfeiture, sanction, market exclusion, compulsory transfer, or asset-funded operation. |
| `DIB-T07` | Emergency information is offered for intelligence, investigation, evidence, watchlisting, targeting, detention, sanctions, or removal. |
| `DIB-T08` | A security or coercive operation uses emergency logistics, command, privileges, secrecy, procurement, immunity, or accelerated review. |
| `DIB-T09` | An Aegis-converted capability is proposed for screening, guarded transport, detention, surveillance, intelligence, police, border, cyber-disruption, sanctions, weapons, or armed protection. |
| `DIB-T10` | Armed or security personnel are assigned to an emergency mission in a role beyond ordinary technical or humanitarian assistance. |
| `DIB-T11` | A cross-border emergency handoff includes investigative, evidentiary, coercive, detention, transfer, or enforcement material. |
| `DIB-T12` | Termination of one stack may leave powers, credentials, custody, data, assets, claims, or remedies open in the other. |

A trigger creates a duty to classify and record the interface. It does not authorize the underlying act.

# 8. Bridge registrar and stewards

## 8.1 Registrar

The registrar creates the administrative Bridge record, verifies identifier distinctness, pins versions, and records the initial trigger. The registrar has no authority to approve either emergency or SCPA action.

## 8.2 Dual stewards

A Bridge SHALL identify:

- an emergency-interface steward responsible for CDEE/ECRC completeness; and
- a protective-action steward responsible for CFPAE/SCPA completeness.

The same person may perform both administrative roles only where conflicts, workload, access restrictions, and independence permit. Dual stewardship does not create unified command.

## 8.3 No steward substitution

A steward cannot act as a missing declarant, investigator, commander, judge, detaining authority, border authority, source owner, evidence custodian, or remedy body.

# 9. Core field groups

A conforming Bridge SHALL contain:

1. schema, identifier, version, status, creation, update, and authority-effect fields;
2. CDEE and CFPAE links;
3. topology;
4. registrar and steward references;
5. trigger classifications;
6. affected territories, persons, systems, assets, and protected groups at a minimally necessary level;
7. framework and jurisdiction engagement registry;
8. ECRC-to-SCPA mapping entries;
9. authority and command separation map;
10. cross-stack handoffs and acceptance states;
11. information, evidence, person, asset, credential, software, and data custody entries;
12. independent clock entries;
13. affected-person notice, counsel, interpretation, accessibility, survivor, child, Indigenous, worker, and non-refoulement interfaces;
14. Aegis reversion entries where applicable;
15. public-information and correction coordination;
16. termination, detachment, restoration, remedy, and data-disposition status;
17. compatibility pins and unresolved substitutions; and
18. integrity and validation fields.

# 10. ECRC–SCPA correspondence matrix

The following matrix identifies likely interface relationships. It does not declare equivalence. No ECRC record replaces an SCPA record, and no SCPA record replaces an ECRC record.

| ECRC record | Emergency function | Related SCPA records | Permitted relationship | Anti-laundering rule |
|---|---|---|---|---|
| `ECRC-01` | Hazard Alert Record | `SCPA-09; SCPA-10` | Context or protected intake only | Alert does not open an investigation or authorize action. |
| `ECRC-02` | Observation Contract | `SCPA-09; SCPA-10` | Purpose and source constraints may be imported | Observation mandate does not become intelligence or investigative authority. |
| `ECRC-03` | Catastrophic-Risk State Estimate | `SCPA-03; SCPA-04; SCPA-05` | Supporting context only | Aggregate risk cannot replace individualized facts or procedural classification. |
| `ECRC-04` | Observation Independence Map | `SCPA-05` | Reliability and anti-automation support | Observer plurality does not authorize adverse action. |
| `ECRC-05` | Standing and Jurisdiction Map | `SCPA-02` | Parallel jurisdiction mapping | Neither map substitutes for the other; each legal route must establish its own standing. |
| `ECRC-06` | Emergency Authority Provenance Record | `SCPA-01` | Parallel authority provenance | Emergency authority cannot satisfy SCPA authority and SCPA authority cannot declare emergency power. |
| `ECRC-07` | Emergency Declaration Record | `SCPA-03` | Classification prompt only | Declaration is not activation and cannot create an SCPA route. |
| `ECRC-08` | Power Activation and Prohibition Schedule | `SCPA-03 plus act-specific records` | Dual dependency schedule | It may list security acts but cannot activate them without their SCPA records. |
| `ECRC-09` | Operational Command and Deployment Record | `SCPA-25` | Parallel command maps | Emergency mission command, technical command, custody, and security command remain separate. |
| `ECRC-10` | Host and Territorial Authorization Record | `SCPA-02; SCPA-29` | Territorial and cross-border context | Host consent does not authorize search, detention, force, intelligence, or removal. |
| `ECRC-11` | Indigenous Emergency Interface Record | `SCPA-39` | Mutually reinforcing safeguards | Emergency necessity does not erase affected-nation authority, knowledge restrictions, or remedy. |
| `ECRC-12` | Affected-Community Liaison Record | `SCPA-07; SCPA-40` | Affected-person and survivor interface support | Liaison does not establish representation, consent, or disclosure authority. |
| `ECRC-13` | Rights and Non-Derogation Record | `SCPA-07; SCPA-08` | Rights floor and notice support | The stronger safeguard governs; emergency silence cannot weaken SCPA notice or challenge. |
| `ECRC-14` | Health Measure and Bodily Integrity Record | `SCPA-18; SCPA-19; SCPA-20; SCPA-31` | Conditional dual routing | Treatment, isolation, restraint, and custody must be separately classified; medical purpose does not remove coercive character. |
| `ECRC-15` | Isolation, Evacuation, and Shelter Record | `SCPA-18 through SCPA-22` | Conditional dual routing | Blocked exit, guarded transport, compelled movement, or confinement requires SCPA authority. |
| `ECRC-16` | Emergency Work Mobilisation Record | `SCPA-41` | Worker and responder protections | Emergency mobilisation does not authorize forced service or waive labour rights. |
| `ECRC-17` | Essential Services and AUBI Continuity Record | `SCPA-07; SCPA-33` | Continuity and remedy support | Services cannot be conditioned on intelligence sharing, identity surrender, or security cooperation. |
| `ECRC-18` | Emergency Finance and Compensation Record | `SCPA-28; SCPA-33` | Finance, coercion, and remedy separation | Emergency finance cannot impose sanctions, freezes, forfeiture, or self-funding coercion. |
| `ECRC-19` | Data, Privacy, Security, and Secrecy Record | `SCPA-09; SCPA-10; SCPA-35` | Purpose, access, and disposition bridge | Emergency data does not become law-enforcement intelligence by transport. |
| `ECRC-20` | Protected Knowledge and Non-Transfer Record | `SCPA-09; SCPA-39` | Protected non-transfer reinforcement | Security urgency does not override Indigenous, survivor, privileged, medical, or source restrictions. |
| `ECRC-21` | Public Information and Correction Record | `SCPA-42` | Public communication coordination | Emergency communication cannot become propaganda, threat labelling, or prejudicial guilt attribution. |
| `ECRC-22` | Interim Measure Review Record | `SCPA-31; SCPA-32` | Parallel independent review | One reviewer cannot renew another power without competence for that exact power. |
| `ECRC-23` | Cross-Border Assistance Record | `SCPA-29` | Assistance and legal-cooperation separation | Mutual aid does not become mutual legal assistance, operational entry, or coercive authority. |
| `ECRC-24` | Investigation and Evidence Handoff Record | `SCPA-11; SCPA-12; SCPA-16` | Explicit security handoff trigger | A handoff does not open an investigation, legalize a method, or establish admissibility. |
| `ECRC-25` | Adjudication and Enforcement Handoff Record | `SCPA-28; SCPA-31; SCPA-32` | Explicit adjudication or enforcement trigger | Referral does not adjudicate, sanction, seize, detain, or enforce. |
| `ECRC-26` | Renewal State Estimate | `All active SCPA routes` | Context for separate renewals | Emergency renewal cannot renew a warrant, detention, force, surveillance, freeze, or removal authority. |
| `ECRC-27` | Emergency Termination Certificate | `SCPA-36` | Coordinated termination | Emergency termination does not automatically close an ordinary lawful case; it ends every emergency-dependent basis. |
| `ECRC-28` | Authority Restoration and Asset Return Record | `SCPA-33; SCPA-36` | Restoration and handback coordination | Return duties survive even if another route remains open. |
| `ECRC-29` | Emergency Data Disposition Record | `SCPA-35` | Dual-purpose data closure | Each purpose and recipient must be resolved; one archive decision cannot preserve unrelated security use. |
| `ECRC-30` | Wrongful Action and Compensation Record | `SCPA-33` | Remedy coordination | Emergency and security wrongs remain separately attributable and compensable. |
| `ECRC-31` | After-Action and Ordinary-Capacity Review | `SCPA-42; SCPA-43` | Learning and institutional review only | Learning cannot transfer, renew, or normalize coercive authority. |
| `ECRC-32` | Institutional Sunset or Continuation Record | `SCPA-43` | Succession and continuity coordination | Institutional continuation does not continue expired powers. |
| `ECRC-33` | Unresolved Risk and Dissent Register | `SCPA-36` | Unresolved-risk custody without residual power | Open risk or dissent cannot preserve emergency or security authority. |

# 11. Interface relationship states

Each ECRC–SCPA mapping entry SHALL use one of:

- `context_only` — information may explain circumstances but cannot satisfy an SCPA element;
- `supporting_record` — a lawful record may support a separately required record while retaining limits;
- `parallel_required` — both records are independently required;
- `conditional_trigger` — the emergency fact triggers SCPA classification or review but not authority;
- `accepted_link` — competent functions have accepted the stated relationship and purpose;
- `partially_accepted_link` — only named fields, purposes, or duties are accepted;
- `concurrent_responsibility` — distinct authorities retain identified duties without shared command;
- `rejected_link` — transfer or reliance is refused;
- `protected_non_transfer` — law or rights prohibit transfer or use;
- `incompatible_version` — exact versions have not been found compatible;
- `terminated_link` — the relationship ended while historical integrity remains; or
- `detached_to_ordinary_law` — an SCPA route continues on an independent non-emergency basis after the emergency dependency ends.

Silence, data ingestion, meeting attendance, copied recipients, shared dashboards, or common command rooms do not create an accepted link.

# 12. Authority and jurisdiction separation

For each dual action the Bridge SHALL identify:

- the emergency authority and exact ECRC provenance;
- the SCPA authority and exact SCPA provenance;
- territorial, personal, subject-matter, temporal, and cross-border jurisdiction for each;
- whether both legal bases are necessary for the act;
- which basis supplies only context or logistics;
- the competent reviewer for each basis;
- the effect of expiry, suspension, revocation, or invalidity of either basis; and
- the lawful route for challenge and remedy.

An action requiring both bases SHALL pause or cease when either basis is absent, invalid, suspended, or expired. An action may continue after one basis ends only if an independent surviving legal basis fully authorizes the remaining act and a detachment record removes emergency privileges, command, data access, finance, credentials, and other dependencies.

# 13. Declaration, activation, and route classification

An `ECRC-07` declaration may trigger review of possible SCPA action classes. It cannot activate them. `ECRC-08` may list proposed security or coercive acts and their prohibitions, but each act must have its full SCPA bundle.

The Bridge SHALL distinguish:

- emergency context only;
- voluntary assistance under SCPA Class A;
- observation or protected intelligence under Class B;
- investigation under Class C;
- urgent protection under Class D;
- compulsory process under Class E;
- custody or force under Class F;
- cyber action under Class G;
- financial coercion under Class H;
- adjudication and remedy under Class I;
- restoration or reintegration under Class J; and
- mobility, identity, border, transfer, or return under Class K.

Ambiguity between classes fails toward the higher-safeguard classification without itself authorizing action.

# 14. Command, custody, and stop-work separation

A Bridge SHALL separately show:

1. emergency strategic or mission coordination;
2. host or territorial authority;
3. professional and clinical authority;
4. technical asset command;
5. security operational command;
6. custody of persons;
7. custody of evidence and property;
8. data-controller and source-owner functions;
9. Aegis conversion-integrity authority; and
10. worker or operator stop-work authority.

No emergency coordinator may issue police, detention, intelligence, border, sanctions, cyber-disruption, or force commands without the corresponding SCPA authority. No SCPA commander may take over emergency health, humanitarian, Indigenous, technical, or public-information functions merely because a security route exists.

# 15. Independent clocks and the earliest-expiry rule

Every emergency and SCPA record retains its own review, expiry, renewal, and termination clock.

The Bridge SHALL display at least:

- the seventy-two-hour provisional emergency clock where applicable;
- the thirty-day emergency authorization clock;
- the ninety-day extraordinary emergency review;
- every warrant, interception, search, custody, detention, force, cyber, freeze, sanction, transfer, removal, or other SCPA clock;
- notice, appeal, correction, release, handback, remedy, and data-disposition deadlines; and
- the exact dependency between each clock and act.

Where one act requires two valid bases, the earlier expiry controls. Renewal of one basis cannot renew the other. Serial relabelling, envelope replacement, route splitting, or new incident numbering cannot evade expiry.

# 16. Information, intelligence, evidence, and protected non-transfer

The Bridge SHALL classify every transferred or referenced material as one or more of:

- operational emergency information;
- health or medical information;
- humanitarian or shelter information;
- protected source information;
- survivor or child information;
- Indigenous or culturally restricted knowledge;
- strategic intelligence;
- investigative information;
- evidence under chain of custody;
- legal privilege;
- public information; or
- administrative metadata.

Emergency information does not become intelligence by receipt. Intelligence does not become evidence by inclusion in a CDEE or Bridge. Evidence does not become admissible by cryptographic validation. Protected health, humanitarian, peace, survivor, child, Indigenous, or source material may be rejected, minimized, segregated, summarized, or withheld.

Each transfer SHALL record sender purpose, recipient purpose, fields, restrictions, access class, onward use, correction duty, retention, disposition, and affected-person rights where applicable.

# 17. Investigation and evidence bridge

`ECRC-24` is a handoff record, not an investigation-opening record. A conforming Bridge SHALL require:

- `SCPA-11` before an investigation opens;
- `SCPA-12` for methods and scope;
- `SCPA-13` through `SCPA-17` for compulsory process, access, production, interception, evidence seizure, or asset restraint;
- separate chain-of-custody records;
- source and privilege protection;
- notice or lawful protected-review procedures;
- correction and exculpatory-disclosure duties; and
- a clear distinction between emergency safety learning and criminal attribution.

Emergency responders, clinicians, mediators, shelter workers, humanitarian personnel, and community responders do not become covert investigators merely because evidence may exist.

# 18. Urgent protection, evacuation, shelter, isolation, and custody

Emergency rescue and voluntary support should proceed at the least restrictive level. The Bridge SHALL trigger SCPA classification whenever:

- exit is blocked;
- transport is guarded or compelled;
- a person is physically restrained;
- identity or movement documents are retained;
- a mobility aid or communication device is withheld;
- chemical restraint is used;
- police or armed personnel control movement;
- isolation extends beyond valid clinical or public-health authority; or
- a shelter, reception, stabilization, processing, quarantine, or protection site functions as confinement.

The label attached to a place or measure does not control its legal classification. Custody requires `SCPA-20`, welfare protections, independent review, less-restrictive alternatives, release duties, and remedy.

# 19. Mobility, borders, corridors, transfer, and non-refoulement

Emergency evacuation, safe corridors, reception, identity support, and family tracing do not create border, asylum, detention, deportation, extradition, or return authority.

The Bridge SHALL separately record:

- territorial and host authorization;
- admission and temporary protection;
- asylum access;
- identity and service-access separation;
- security allegations;
- detention or supervision;
- family unity and child safeguards;
- trafficking and survivor protections;
- non-refoulement;
- voluntary evacuation or return;
- removal, extradition, or transfer; and
- appeal and suspensive effect.

An emergency declaration, hazard zone, undocumented status, missing biometrics, route of travel, aggregate threat score, or secret allegation cannot by itself justify detention, exclusion, removal, or return.

# 20. Cyber dual-interface

Emergency operators may take defensive action on systems they lawfully control under `ECRC-19`, `ECRC-23`, and `SCPA-26` as applicable. The Bridge SHALL require `SCPA-27` and separate competent authority for:

- access to third-party systems;
- sinkholing;
- traffic redirection;
- credential use;
- account suspension;
- counter-hacking;
- data deletion or alteration;
- disruption of remote infrastructure;
- covert persistence;
- active attribution operations; or
- evidence collection beyond ordinary defensive logs.

Technical urgency, vendor consent, shared threat intelligence, or emergency command does not replace jurisdiction, authorization, proportionality, collateral-impact review, and remedy.

# 21. Finance, assets, sanctions, and compensation

Emergency procurement, forecast finance, compensation reserves, or continuity funding do not authorize freezes, seizures, forfeiture, sanctions, market exclusion, compulsory transfer, or self-funding enforcement.

Any coercive financial act requires `SCPA-28`, independent review, affected-party notice or lawful protected process, innocent-party and essential-service continuity, challenge, release, return, restitution, and compensation.

Emergency and security remedies may be coordinated, but harms and responsible institutions remain separately attributable. Unadjudicated or contested assets shall not fund the investigating, detaining, sanctioning, or coordinating body.

# 22. Public information, classification, and non-propaganda

CDEE and `ECRC-21` may coordinate public emergency information. `SCPA-42` governs security classification, correction, and non-propaganda safeguards.

The Bridge SHALL record:

- statement owner;
- fact, estimate, allegation, instruction, uncertainty, and correction labels;
- protected omissions;
- risk of prejudice to investigation, trial, asylum, employment, safety, or reputation;
- accessibility and language duties;
- correction owner and deadline; and
- whether a statement could create a security or mobility consequence.

Emergency communication shall not be used to stigmatize populations, pre-judge guilt, compel participation, conceal unlawful action, manipulate political opinion, or counter lawful criticism.

# 23. Armed and security personnel

Use of armed forces, police, border personnel, intelligence personnel, detention staff, private security, or armed contractors in an emergency does not place them under a generic emergency mandate.

The Bridge SHALL separately identify:

- legal basis;
- host and territorial authority;
- role and excluded functions;
- command;
- weapons and equipment;
- rules on force;
- detention or custody authority;
- evidence and intelligence restrictions;
- medical and humanitarian coordination;
- identification and public markings;
- liability and complaint routes;
- review and termination; and
- handback and data disposition.

Emergency support roles do not permit political enforcement of participation, crowd suppression, intelligence collection, immigration enforcement, or unrelated evidence gathering.

# 24. Aegis converted-capability bridge

Any Aegis-converted asset, operator, data stream, facility, credential, or subsystem used for ordinary civilian emergency assistance remains governed by its Aegis mission charter and any emergency assistance records.

A proposed use involving screening, watchlisting, surveillance, evidence collection, guarded custody, detention, deportation, extradition, raids, arrest, crowd control, intelligence, targeting, third-party cyber disruption, sanctions enforcement, weapons, armed protection, or military command triggers `SCPA-44`.

The Bridge SHALL record:

- the smallest separable affected capability unit;
- the security-facing request;
- the reversion state;
- suspension of civilian markings, credentials, data permissions, funding representations, and assurances;
- technical and organizational segregation;
- worker refusal and protection;
- the external authority requested to authorize the security act;
- rejection, reversion, requalification, or permanent decommissioning; and
- surviving Aegis duties for conversion integrity, claims, data, workers, and public correction.

Reversion does not authorize the security use and does not give Aegis security command.

# 25. Handoffs, partial acceptance, and retained duties

Every cross-stack offer SHALL use the applicable CDEE, CFPAE, ECRC, and SCPA handoff state. The Bridge SHALL not collapse event-level and action-level acceptance into one field.

A recipient may accept logistics while rejecting information; accept minimum safety information while rejecting a full care file; accept evidence preservation while rejecting investigation responsibility; or accept an emergency mission while rejecting a security-facing Aegis use.

Sender duties survive unless valid law and an explicit accepted record reassign them. Duties that commonly survive include source protection, correction, care continuity, evidence integrity, notice, worker protections, survivor choice, child safeguards, Indigenous knowledge restrictions, property return, remedy, and data disposition.

# 26. Affected-person interface

The Bridge SHALL provide or link a rights-accessible account sufficient to identify, subject to lawful protection:

- which emergency and SCPA routes affect the person;
- the legal basis and authority for each consequential act;
- reasons and fact status;
- notice restrictions and their reviewer;
- counsel, representative, interpretation, and accessibility routes;
- survivor and child options;
- asylum and non-refoulement safeguards;
- complaint, appeal, urgent challenge, and interim relief;
- release, correction, property return, compensation, and data rights; and
- contact points for separate emergency and SCPA responsibilities.

The Bridge is not a public exposure ledger. Protected identities and material remain layered.

# 27. Termination, detachment, restoration, and closure

## 27.1 Termination of emergency basis

When the emergency basis ends, every dependent SCPA route SHALL cease, narrow, or detach to an independently valid ordinary-law basis. Emergency command, procurement, privileges, secrecy, credentials, access, finance, and data permissions terminate unless separately preserved by law.

## 27.2 Continuation under ordinary law

An investigation, prosecution, claim, asylum process, remedy, data-correction duty, or other SCPA route may continue after the emergency only when its authority is independent. The Bridge SHALL record `detached_to_ordinary_law` and identify what emergency dependencies were removed.

## 27.3 Termination of SCPA basis

Expiry or invalidity of a security route does not end the emergency event, but every coercive act dependent on that route stops. Emergency services and voluntary assistance continue where lawful.

## 27.4 Closure

A Bridge cannot close until:

- linked CDEE and CFPAE relationships are resolved or lawfully retained;
- all dual-dependent powers have ended or detached;
- commands, credentials, privileges, access, and Aegis statuses are resolved;
- persons are released or lawfully transferred;
- property, assets, evidence, and records have lawful custody;
- affected-person notice, correction, challenge, and remedy duties are resolved;
- worker and responder duties are resolved;
- data disposition is complete for both purposes;
- public corrections are issued where required; and
- unresolved risk is held without residual power.

Reopening restores coordination only. It does not reactivate expired authority.

# 28. Compatibility and fail-closed versioning

Every Bridge SHALL pin exact versions and hashes for:

- `ECRCI`, `ECRC`, `ECRC-RIC`, and `CDEE`;
- `SCPA`, `SCPA-RIC`, and `CFPAE`;
- every engaged framework; and
- any schema, profile, addendum, or implementation extension.

A later version is not automatically compatible. Substitution requires a recorded compatibility decision and rerun of affected compound scenarios. Until then, the affected cross-stack route is `incompatible_version` and consequential action fails closed.

# 29. Failure handling

## 29.1 No Bridge registrar

Existing lawful rescue or protection need not wait for an administrative object. Actors proceed only under their actual authority and reconstruct the Bridge promptly. Reconstruction cannot retroactively authorize an act.

## 29.2 Missing parent envelope

If no CDEE or CFPAE exists, the missing parent is created when required. The Bridge cannot substitute for it.

## 29.3 Conflicting identifiers

Possible duplicates are quarantined for administrative reconciliation. Powers do not merge or multiply.

## 29.4 Unassigned authority

The Bridge records the gap and prevents the affected consequential act. It may continue voluntary assistance and route a request to a competent body.

## 29.5 Protected non-transfer

The transfer is rejected, minimized, summarized, or subjected to lawful protected review. Security urgency alone does not override the restriction.

## 29.6 Clock conflict

The earlier controlling expiry applies to the overlapping act. A late administrative update does not preserve power.

## 29.7 Essential protection would be stranded

Care, shelter, medical assistance, legal aid, interpretation, accessibility, family contact, and other non-coercive services continue under their own authority while the disputed security route remains blocked.

# 30. Prohibited uses

The Bridge SHALL NOT be used to:

- infer dangerousness, guilt, credibility, identity, nationality, migration status, or emergency severity;
- create a unified emergency-security command;
- establish a universal watchlist or person-level event ledger;
- merge health, humanitarian, peace, survivor, child, Indigenous, migration, intelligence, and evidence files;
- bypass a warrant, court, independent review, host authorization, or non-refoulement assessment;
- extend powers by keeping an event or envelope open;
- reward institutions for escalations, arrests, detentions, seizures, sanctions, removals, or emergency duration;
- hide security action inside humanitarian, health, resilience, continuity, preparedness, or civilian-conversion terminology;
- hide emergency action inside investigation, national security, border, or sanctions terminology;
- treat cryptographic validation as proof of truth or authority; or
- substitute a later untested framework version.

# 31. Minimum adoption clause

An adopting framework SHALL state:

> **This framework adopts the Emergency–Security Dual-Interface Bridge v0.1 (`ESDIB/0.1`) for any matter in which an emergency event and an SCPA protective, security, coercive, mobility, justice, cyber, financial, or converted-capability route materially overlap. Adoption creates no emergency or security authority. CDEE/ECRC and CFPAE/SCPA identifiers, records, authorities, commands, access restrictions, clocks, remedies, and closure duties remain separate. Missing or incompatible authority fails closed while essential non-coercive protection continues.**

# 32. Conformance levels

- **ESDIB-L0 — Referenced:** exact version is named; no consequential routing.
- **ESDIB-L1 — Identity compatible:** distinct CDEE, CFPAE, and Bridge identifiers; version pins and triggers implemented.
- **ESDIB-L2 — Record compatible:** ECRC–SCPA mapping, handoff, access, custody, and clock fields implemented.
- **ESDIB-L3 — Operationally tested:** compound scenarios, protected non-transfer, Aegis reversion, detachment, remedy, and closure verified.

No conformance level certifies the substantive legality of a real action.

# 33. Required implementation tests

1. An emergency declaration is issued without any SCPA action: the Bridge is not used to create security authority.
2. A hazard alert is shared with Shield: receipt remains protected intake and does not open an investigation.
3. An aggregate catastrophic-risk estimate names a neighborhood: it cannot substitute for individualized factual basis.
4. A public-health isolation request leaves the person unable to exit: SCPA custody classification is triggered.
5. A voluntary evacuation becomes guarded transport after departure: a new SCPA route is required and the earlier consent record is not stretched.
6. An evacuation crosses a border: host authorization, admission, asylum access, and non-refoulement are separately recorded.
7. A displaced person refuses biometrics during an emergency: essential services continue and refusal is not a security inference.
8. A trafficking survivor accepts shelter but refuses investigation: care continues and protected information is not transferred.
9. A Peace mediator reports immediate danger during a disaster: minimum information enters SCPA-18 without transferring the mediation file.
10. A Kintsugi sanctuary receives an emergency shelter designation: locked doors or blocked exit are treated as custody.
11. A cyberattack disrupts an emergency hospital: defensive action on host-controlled systems proceeds under SCPA-26.
12. Operators propose sinkholing an attacker server: SCPA-27 is required despite the emergency.
13. An emergency asset freeze is proposed to stop hazardous-material trafficking: SCPA-28 and independent review are required.
14. An emergency compensation fund receives forfeited assets: self-funding from unadjudicated seizure is rejected.
15. An Aegis vessel transports evacuees voluntarily: civilian status remains if no security-facing function is added.
16. The same vessel is asked to perform border screening: the affected subsystem enters SCPA-44 and civilian status is suspended.
17. An Aegis operator is asked to guard detainees: the role reverts; Aegis does not authorize or command the task.
18. Armed personnel provide perimeter safety at an emergency site: command, weapons, force, and host authority are separately recorded.
19. An emergency commander requests access to a protected intelligence source: protected non-transfer may require rejection.
20. Security intelligence suggests a biological incident was deliberate: the hypothesis does not alter health care or public warning without review.
21. An emergency public bulletin identifies an alleged attacker: fact status, correction, and prejudice safeguards apply.
22. An emergency renewal is approved: an expiring detention order still expires unless independently renewed.
23. A warrant remains valid after the emergency ends under ordinary law: the Bridge records detachment from the emergency basis.
24. An action required both emergency and SCPA authority: expiry of either basis stops the overlapping action.
25. An unresolved hazard remains after powers end: risk custody continues without residual command or surveillance.
26. Emergency data is archived for epidemiology: it cannot remain available for unrelated security use.
27. A wrongful emergency detention caused both health and security harms: attribution and remedies remain separate but coordinated.
28. One recipient accepts logistics but rejects intelligence material: partial acceptance is recorded without implied acceptance.
29. The CDEE and CFPAE identifiers are accidentally merged: validation rejects the envelope.
30. A later framework version is substituted without a compatibility decision: the Bridge fails closed.
31. No registrar is available during urgent rescue: action proceeds only under existing authority and the Bridge is reconstructed without retroactive authority.
32. A cross-border assistance team receives diplomatic privileges: privileges do not immunize unlawful coercive acts.
33. An emergency declaration is revoked while a criminal investigation continues: emergency credentials and access terminate, ordinary records remain.
34. A security institution dissolves during a prolonged emergency: services, claims, evidence, records, and remedies transfer without preserving its powers.
35. Reopening a closed Bridge after new evidence appears restores coordination only and does not reactivate expired powers.

# 34. Amendment and compatibility

A revision is material when it changes:

- a trigger;
- identifier relationship;
- mapping state;
- authority or command boundary;
- information or custody rule;
- clock interaction;
- Aegis reversion;
- affected-person right;
- termination, detachment, remedy, or closure requirement;
- compatibility rule; or
- schema-required field.

Material revisions require exact versioning, source hashes, migration notes, schema update, and rerun of affected tests.

# 35. Source and compatibility manifest

| Source ID | File | SHA-256 | Bytes | Lines | Role |
|---|---|---|---:|---:|---|
| `ECRCI/0.1` | `emergency-catastrophic-risk-continuity-interface-specification-v0.1.md` | `c673742b1317c7169d4b8226118478c990e9a3d05084b2dc5ac9ad2f1971163c` | 81,100 | 2,136 | emergency constitutional parent |
| `ECRC/0.1` | `emergency-cluster-record-profile-v0.1.md` | `19f35a53c151182ff6bf2760f7da67b9696fbf0048dfef27af9748de36b94dc9` | 82,601 | 1,334 | emergency canonical record profile |
| `ECRC-RIC/0.1` | `emergency-record-inheritance-clause-v0.1.md` | `1e7ecacdcf8afb946c7bb5733b6e95f1d6c435851b529e2482840a0ae9640e39` | 8,889 | 93 | emergency inheritance clause |
| `CDEE/0.1` | `emergency-cross-domain-event-envelope-v0.1.md` | `68ee2c48383199e4b91b365ea21e35d5a729f0a72854472acf6f8ae103f0c192` | 35,827 | 599 | emergency event envelope |
| `ECRC-HIT/0.2` | `emergency-cluster-harmonization-interface-test-v0.2.md` | `3c5eaf18f6c733761d3d3f1bd9eabc1fbcb7932caef1202bd81ea5d898808f6b` | 11,615 | 166 | tested emergency cluster baseline |
| `SCPA/0.1` | `security-coercion-protective-action-interface-specification-v0.1.md` | `b8f1dd0f676044542a23184f52200e50b106a798545c7c57119ded2c439b6299` | 127,876 | 1,452 | security constitutional parent |
| `SCPA-RIC/0.1` | `scpa-record-inheritance-conformance-clause-v0.1.md` | `0c5d6083716969ee499afc5027a812f7153410babdd4a8e6f464270f8534c917` | 44,119 | 655 | security inheritance clause |
| `CFPAE/0.1` | `cross-framework-protective-action-envelope-v0.1.md` | `c1d591c665dfd3b9c9f30dd61943a38556905c6f1a2128a64220e054149dfb05` | 57,546 | 975 | protective-action envelope |
| `SCPA-HIT/0.1` | `security-coercion-cluster-harmonization-interface-test-v0.1.md` | `51f722add984d88be283a34f153d8e63e49e678c441d790620e44df1b6054d0f` | 32,098 | 312 | security cluster test basis |
| `PIS/2.2.2` | `planetary-immune-system-v2.2.2.md` | `44800ac9b19f17e30b0cbb2f7f08745afad3a8722d31c17d406b6d8325bfe1ab` | 92,070 | 1,674 | emergency observer framework |
| `GlobalHealth/2.2.2` | `global-health-preparedness-outbreak-response-biosecurity-v2.2.2.md` | `9c1973d5ff76df878c2d7147feb896ce984b8ab0203064b15d1e8a4adcc3ff92` | 87,410 | 1,772 | emergency health framework |
| `Aethelred/1.2.2` | `aethelred-accord-v1.2.2.md` | `f1867219a8f1f743979fd196ddd947918da5429e03ef9eb8be98dee8d7f146c0` | 96,032 | 1,538 | biosafety framework |
| `LivingShield/4.4.2` | `living-shield-v4.4.2.md` | `64921d6a7fab2f877259ccdc8370b103ddbd2d240fb1d55c9bfae66ea03ff161` | 96,487 | 1,694 | preparedness and mutual-aid framework |
| `Shield/2.0` | `shield-protocol-v2.0.md` | `4fca33e9ab55574b3255fc36c0a5e81dedd5f2ef6db5f0df3f5887308fbc2b62` | 73,910 | 1,607 | transnational cooperation framework |
| `Kintsugi/2.2` | `kintsugi-protocol-v2.2.md` | `35f06e1449df25c5077c6b7c7b9d6c23f39c499df3d78007951778e91d96c973` | 63,734 | 1,250 | community safety framework |
| `Migration/1.1` | `migration-human-mobility-v1.1.md` | `caaf8181b8c519b8df7b87b2d53458b39ffaef6cb33899f7453a56780a8c326d` | 64,591 | 1,062 | mobility and protection framework |
| `Peace/1.8` | `peace-conflict-resolution-framework-v1.8.md` | `66fbd6d7d89895e85dcdf7a9c1db9a37bec47557660dd7a08fd5dc75f48de98c` | 77,361 | 1,142 | peace support framework |
| `Aegis/1.3.3` | `aegis-protocol-v1.3.3.md` | `ca2391eca1a48c526ef63e3760a003e29bca94bf44814b6addd6723a0741788c` | 147,718 | 2,026 | converted-capability framework |

# Appendix A — Minimal Bridge field checklist

A minimal implementation records:

1. `schema_version`;
2. `dual_interface_bridge_id` and `bridge_version`;
3. `status`, timestamps, and `authority_effect: none`;
4. CDEE event and envelope references;
5. CFPAE action-cluster and envelope references;
6. trigger codes;
7. framework and jurisdiction engagements;
8. ECRC–SCPA mapping entries;
9. emergency and SCPA authority references;
10. command and custody separation;
11. handoffs and acceptance states;
12. access and protected non-transfer;
13. independent clocks and earliest-expiry result;
14. affected-person interfaces;
15. Aegis reversion where applicable;
16. public information and correction;
17. termination, detachment, restoration, remedy, and data disposition;
18. compatibility pins and unresolved substitutions;
19. correction history; and
20. integrity and schema validation status.

# Appendix B — Dual-interface sequence

1. Detect a mandatory trigger.
2. Verify or create the CDEE and CFPAE parent envelopes.
3. Create a distinct Bridge identifier.
4. Pin exact versions and hashes.
5. Classify every emergency and SCPA route.
6. Link but do not merge ECRC and SCPA records.
7. Verify both authorities where both are needed.
8. Record commands, custody, access, and handoffs separately.
9. Compute independent clocks and the controlling expiry.
10. Protect affected persons and non-transfer material.
11. Activate no power through the Bridge.
12. Update correction, termination, detachment, remedy, and closure states.

# Appendix C — Closing principle

> **An emergency may make action urgent. It does not make every urgent action lawful. A security authority may make an act lawful within its mandate. It does not make the surrounding emergency, command, data access, finance, or continuation lawful. The Bridge keeps both truths visible at the same time.**

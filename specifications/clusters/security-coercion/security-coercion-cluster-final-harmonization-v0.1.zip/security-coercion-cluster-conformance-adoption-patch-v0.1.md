# Security-and-Coercion Cluster Conformance Adoption Patch v0.1

## Controlled adoption of SCPA-RIC, CFPAE, ESDIB, SATN, and PKS-PRUP

**Patch ID:** `SCCA/0.1`  
**Date:** August 2026  
**Authority effect:** None  
**Resulting framework versions:** Shield 2.0.1; Kintsugi 2.2.1; Migration 1.1.1; Peace 1.8.1; Aegis 1.3.4

> **This patch makes constitutional boundaries interoperable. It does not create a shared security authority.**

# 1. Purpose

The initial harmonization test found that the revised frameworks had broken the substantive coercion relay but still lacked uniform record inheritance, stable compound-action identity, reciprocal responsibility acceptance, emergency–security linkage, exact release pinning, and a single machine-readable conformance registry.

This patch resolves those document-interface findings without reopening the frameworks' substantive allocations of authority.

# 2. Adopted instruments

| Instrument | File | SHA-256 |
|---|---|---|
| `SCPA/0.1` | `security-coercion-protective-action-interface-specification-v0.1.md` | `b8f1dd0f676044542a23184f52200e50b106a798545c7c57119ded2c439b6299` |
| `SCPA-RIC/0.1` | `scpa-record-inheritance-conformance-clause-v0.1.md` | `0c5d6083716969ee499afc5027a812f7153410babdd4a8e6f464270f8534c917` |
| `CFPAE/0.1` | `cross-framework-protective-action-envelope-v0.1.md` | `c1d591c665dfd3b9c9f30dd61943a38556905c6f1a2128a64220e054149dfb05` |
| `ESDIB/0.1` | `emergency-security-dual-interface-bridge-v0.1.md` | `6332dba2fe2d01347f5c2432a1af002e0902aa8bba80c7b533bd50ee89cebf30` |
| `SATN/0.1` | `shield-migration-security-allegation-trafficking-non-refoulement-addendum-v0.1.md` | `79648d5c3ea4322e4978c04ea1f316f42c4a9aed2455aa52ea4a795c5bef6fdf` |
| `PKS-PRUP/0.1` | `peace-kintsugi-shield-protected-referral-urgent-protection-addendum-v0.1.md` | `19edf79640abb41f1c872f208a2874140fb2e3b18c70cf97f97ae072931c2857` |

# 3. Controlled successor set

| Framework | Source file and hash | Successor file and hash |
|---|---|---|
| Shield | shield-protocol-v2.0.md | `4fca33e9ab55574b3255fc36c0a5e81dedd5f2ef6db5f0df3f5887308fbc2b62` | shield-protocol-v2.0.1.md | `ff5dd3641b7e386b0fe377fb378c0455d120db99fe20f35381d5a53a9f00a37d` |
| Kintsugi | kintsugi-protocol-v2.2.md | `35f06e1449df25c5077c6b7c7b9d6c23f39c499df3d78007951778e91d96c973` | kintsugi-protocol-v2.2.1.md | `621dd1e8b0e4cc99ca9b1ae378e6ae6e095004b484aa63436b1c264df75ca933` |
| Migration | migration-human-mobility-v1.1.md | `caaf8181b8c519b8df7b87b2d53458b39ffaef6cb33899f7453a56780a8c326d` | migration-human-mobility-v1.1.1.md | `63a4c3910223538e802d79d992ef6ccdbee30c8f148ee9327dc4ae4689ee627c` |
| Peace | peace-conflict-resolution-framework-v1.8.md | `66fbd6d7d89895e85dcdf7a9c1db9a37bec47557660dd7a08fd5dc75f48de98c` | peace-conflict-resolution-framework-v1.8.1.md | `d96bab5e0bee542cdc27e28cf6a616378d5540b46a6160edc50d0867393d135f` |
| Aegis | aegis-protocol-v1.3.3.md | `ca2391eca1a48c526ef63e3760a003e29bca94bf44814b6addd6723a0741788c` | aegis-protocol-v1.3.4.md | `9a14ca297c8b179a2528aeb01937c6f88758ef27a91ee8cfe0f2a3a4dde416df` |

# 4. Uniform adoption rules

All five successors now:

1. adopt the six SCPA-RIC inheritance relationships;
2. inherit the canonical 27-field header, five access classes, ten handoff states, record lifecycle, and fail-closed behavior;
3. require `CFPAE/0.1` whenever one protective action involves multiple frameworks, authorities, jurisdictions, routes, or custody systems;
4. preserve separate authority, legal source, jurisdiction, action class, records, rights, clocks, custody, correction, remedy, and closure for every route;
5. require `ESDIB/0.1` whenever an emergency event and an SCPA-governed route materially depend on each other;
6. preserve the earliest-expiry rule when an act requires both emergency and security bases;
7. use the exact `SCCA/0.1` version set and fail closed on material mismatch;
8. prohibit reopening from reviving expired authority.

# 5. Pairwise adoption

- Shield 2.0.1 and Migration 1.1.1 adopt `SATN/0.1`.
- Peace 1.8.1, Kintsugi 2.2.1, and Shield 2.0.1 adopt `PKS-PRUP/0.1`.
- Aegis 1.3.4 applies `SCPA-44` and security-use reversion inside CFPAE and ESDIB routes.

# 6. Machine-readable registry

`security-coercion-cluster-conformance-registry-v0.1.json` publishes:

- exact successor and interface hashes;
- all 44 canonical SCPA records;
- every framework's normalized inheritance relationship and source crosswalk text;
- action classes, access classes, handoff states, and record states;
- twelve ESDIB triggers;
- both pairwise profiles;
- compound identity and closure rules;
- the two remaining implementation conditions.

# 7. Non-effect on authority

The patch does not:

- create an international police, intelligence, military, border, detention, cyber, sanctions, prosecutorial, or judicial body;
- make receipt equal acceptance;
- make urgency equal jurisdiction;
- make a referral equal investigation;
- make a trafficking indicator or security allegation equal detention or removal;
- make emergency activation equal security authority;
- make Aegis reversion equal authorization;
- make a shared identifier equal shared command;
- make closure equal erasure of remedy or continuing duties.

# 8. Release result

The patched document stack is ready for binding **document-level cross-framework routing** under the exact release set. Consequential real-world action remains dependent on separately valid jurisdiction-specific law, institutions, personnel, counsel, accessibility, technical controls, budgets, review, and remedy.

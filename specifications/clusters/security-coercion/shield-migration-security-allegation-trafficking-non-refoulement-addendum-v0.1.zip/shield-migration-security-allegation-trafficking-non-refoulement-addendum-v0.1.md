# Shield–Migration Security Allegation, Trafficking, and Non-Refoulement Addendum v0.1

## Survivor-first protection, bounded security allegations, independent challenge, non-punishment, non-refoulement, and complete remedy

**Document Type:** Security-and-coercion cluster pairwise harmonization addendum  
**Status:** Normative interoperability specification — draft for implementation testing  
**Version:** 0.1  
**Date:** August 2026  
**Profile Identifier:** `SH-MOB-SATN/0.1`  
**Authority Effect:** None

---

## Executive rule

> **A person may simultaneously be a survivor, an asylum applicant, a witness, a suspect, or the subject of a security allegation. Those statuses do not merge. Support does not compel cooperation; an allegation does not establish dangerousness; investigation does not determine protection; exclusion does not erase non-refoulement; and cross-border cooperation does not authorize detention, extradition, deportation, or return.**

This Addendum coordinates **Shield Protocol v2.0** and **Migration and Human Mobility Framework v1.1** through SCPA v0.1, the SCPA Record Inheritance and Conformance Clause v0.1, and the Cross-Framework Protective Action Envelope v0.1.

It creates no criminal offence, intelligence power, investigation, warrant, arrest, detention, border, asylum, exclusion, extradition, deportation, return, witness-protection, prosecution, adjudication, or sanctions authority.

> **No valid authority record, no consequential security or mobility action.**

---

# 1. Purpose

The Addendum provides a common operational grammar for cases in which transnational-crime cooperation and human-mobility protection overlap, especially:

- trafficking, forced labour, slavery, sexual exploitation, criminal exploitation, domestic servitude, debt bondage, forced marriage, child exploitation, and organized recruitment abuse;
- people smuggling where exploitation, coercion, family support, humanitarian assistance, or irregular movement may be confused with criminal participation;
- asylum or protection proceedings involving confidential Shield information or another security allegation;
- survivors, witnesses, whistleblowers, suspects, or accused persons who also face migration consequences;
- extradition or criminal-transfer requests involving an asylum claim, persecution risk, political context, trafficking, compelled conduct, or chain-return risk;
- requests for protected relocation, identity protection, safe passage, family tracing, or witness support;
- allegations that may affect temporary admission, reception, detention, family unity, status, removal, or return;
- correction of false or stale allegations across jurisdictions; and
- compound emergency cases linked through CDEE and ESDIB.

The purpose is not to make Shield a migration authority or Migration an investigative service. It is to let both perform their lawful functions without using the other framework to bypass authority, evidence, rights, review, or remedy.

# 2. Controlling instruments and exact versions

This Addendum is compatible only with the following exact instruments:

| Instrument | Version | File | SHA-256 |
|---|---:|---|---|
| Shield Protocol | 2.0 | `shield-protocol-v2.0.md` | `4fca33e9ab55574b3255fc36c0a5e81dedd5f2ef6db5f0df3f5887308fbc2b62` |
| Migration and Human Mobility Framework | 1.1 | `migration-human-mobility-v1.1.md` | `caaf8181b8c519b8df7b87b2d53458b39ffaef6cb33899f7453a56780a8c326d` |
| Security, Coercion, and Protective Action Interface Specification | 0.1 | `security-coercion-protective-action-interface-specification-v0.1.md` | `b8f1dd0f676044542a23184f52200e50b106a798545c7c57119ded2c439b6299` |
| SCPA Record Inheritance and Conformance Clause | 0.1 | `scpa-record-inheritance-conformance-clause-v0.1.md` | `0c5d6083716969ee499afc5027a812f7153410babdd4a8e6f464270f8534c917` |
| Cross-Framework Protective Action Envelope | 0.1 | `cross-framework-protective-action-envelope-v0.1.md` | `c1d591c665dfd3b9c9f30dd61943a38556905c6f1a2128a64220e054149dfb05` |
| Emergency–Security Dual-Interface Bridge | 0.1 | `emergency-security-dual-interface-bridge-v0.1.md` | `6332dba2fe2d01347f5c2432a1af002e0902aa8bba80c7b533bd50ee89cebf30` |
| Security-and-Coercion Cluster Harmonization Interface Test | 0.1 | `security-coercion-cluster-harmonization-interface-test-v0.1.md` | `51f722add984d88be283a34f153d8e63e49e678c441d790620e44df1b6054d0f` |

Later versions are not substituted automatically. A material change to security allegations, survivor support, information sharing, detention, transfer, non-refoulement, challenge, remedy, data disposition, or institutional responsibility fails closed until compatibility is tested and recorded.

# 3. Non-authority and non-merger clause

This Addendum does not:

- define trafficking, smuggling, terrorism, organized crime, security threat, exclusion, refugee status, or another legal category;
- designate a person as victim, witness, suspect, offender, security risk, asylum applicant, excluded person, deportable person, or extraditable person;
- authorize intelligence collection, investigation, compulsory disclosure, search, seizure, arrest, detention, surveillance, interception, witness custody, family separation, extradition, deportation, expulsion, return, sanctions, or force;
- make a Shield record admissible evidence merely because it is authenticated or transferred;
- make a Migration record available to Shield merely because the person is a survivor, applicant, undocumented, irregularly present, or linked to a suspected network;
- allow support providers to become covert source recruiters or immigration-enforcement intermediaries;
- allow immigration status, route, nationality, family relationship, missing documents, biometric refusal, trauma presentation, or use of smugglers to establish dangerousness;
- allow a criminal or security allegation to bypass individualized protection and non-refoulement review;
- make Shield the reviewer of Migration decisions;
- make Migration the reviewer of criminal guilt or investigative sufficiency; or
- create a shared command, pooled database, universal case ledger, or residual jurisdiction.

# 4. Relationship to SCPA, RIC, CFPAE, and ESDIB

Every implementation shall conform to SCPA v0.1 and `SCPA-RIC/0.1`. Every materially distinct action retains its canonical SCPA identifier, full 27-field header, exact act, competent authority, legal source, jurisdiction, access class, review and expiry clocks, challenge, termination, disposition, correction, and remedy.

Where more than one framework or authority is engaged, the case shall use one conformant CFPAE `protective_action_cluster_id`. This Addendum creates a linked **Security Allegation, Trafficking, and Non-Refoulement Coordination Packet** (`SATN Packet`), not a replacement Envelope and not `SCPA-45`.

Where an emergency event also engages the case, ESDIB v0.1 and any CDEE/ECRC records remain separate. Emergency urgency may explain timing or context; it cannot satisfy an SCPA authority requirement or suspend non-refoulement, challenge, custody review, or remedy.

# 5. Stable identity and packet topology

Each Packet shall contain:

- `satn_coordination_id` — stable pairwise identifier;
- `protective_action_cluster_id` — CFPAE identity;
- optional CDEE `cluster_event_id` and ESDIB bridge identifier;
- local Shield request, support, intelligence, investigation, and protection identifiers;
- local Migration service, identity, asylum, detention, transfer, and appeal identifiers;
- linked SCPA record instances;
- affected-person protected references;
- current route, responsibility, custody, review, remedy, and closure indices.

The Packet identifier shall not encode a person’s name, nationality, status, allegation, offence, trafficking indicator, location, or outcome.

# 6. Functional roles and prohibited role conversion

## 6.1 Shield functions

Shield may, within valid law:

- coordinate victim and survivor protection;
- receive protected reports;
- route a lawful investigation or mutual-legal-assistance request;
- transmit a security allegation with provenance, restrictions, and purpose limits;
- coordinate witness or whistleblower safeguards;
- support lawful evidence preservation and cross-border cooperation; and
- correct or withdraw information it originated.

Shield may not determine asylum, exclusion, non-refoulement, residence, detention, removal, or return by virtue of those functions.

## 6.2 Migration functions

Migration bodies may, within valid law:

- provide reception and essential services;
- register and adjudicate protection claims;
- reconstruct identity under uncertainty;
- assess trafficking indicators and protection needs;
- decide temporary admission, status, detention, alternatives, expulsion, deportation, or return only through competent legal routes;
- ensure non-refoulement, counsel, interpretation, accessibility, appeal, and remedy; and
- request bounded information or lawful cooperation.

Migration personnel may not open or command a criminal investigation, compel Shield collection, or turn service records into intelligence by virtue of those functions.

## 6.3 Shared and concurrent responsibilities

Support, safety planning, legal assistance, family protection, relocation, correction, and remedy may involve concurrent responsibilities. Concurrent responsibility does not create shared command, common purpose, pooled authority, or automatic data access.

# 7. Status separation

The Packet shall represent separately whether a person is alleged, assessed, recognized, or proceeding as:

- a potential or recognized trafficking survivor;
- a recipient of unconditional services;
- an asylum or protection applicant;
- a temporary-admission holder;
- a witness or protected reporter;
- a person voluntarily cooperating with an investigation;
- a suspect, accused person, or convicted person under applicable law;
- the subject of a security allegation;
- a detained person under a separate custody route;
- a person facing extradition, deportation, expulsion, transfer, or return.

One status does not establish another. A protective classification is not proof of an offence. A criminal allegation is not an asylum determination. A witness role does not waive migration rights. A suspect role does not erase survivor status, compelled-conduct analysis, or non-refoulement.

# 8. Trafficking indicators and protective identification

## 8.1 Indicator intake

Trafficking or exploitation indicators may include coercion, deception, debt, document control, threatened reporting, confinement, violence, dependency, wage theft, unsafe recruitment, family threats, forced criminality, or inability to leave. SATN-04 shall record uncertainty, source limits, cultural and disability context, and alternative explanations.

Indicator intake opens an offer of support, not a prosecution, detention, adverse immigration finding, or final victim-status adjudication.

## 8.2 Immediate support

SATN-05 may open through minimum attestation. Shelter, healthcare, food, interpretation, accessibility, legal aid, safety planning, communication, income support, child safeguarding, and urgent protection shall not depend on documents, biometrics, a police report, testimony, prosecution, conviction, or willingness to confront an alleged exploiter.

## 8.3 Reflection and recovery

Where competent law provides a reflection, recovery, or temporary-stay period, SATN-06 shall identify the authority, duration, services, removal stay, review, and transition route. A reflection period is not detention, investigative isolation, or a deadline to agree to cooperate.

## 8.4 Non-punishment and compelled conduct

A protective or adjudicative authority shall separately consider whether immigration, labour, document, sex-work, financial, or low-level criminal conduct was compelled by exploitation. Survivor status does not establish immunity automatically; equally, alleged conduct does not erase the duty to assess coercion, proportionality, protection, and remedy.

# 9. Survivor sovereignty and investigative cooperation

## 9.1 Process choice

SATN-07 shall record whether the person chooses, declines, pauses, limits, or withdraws from:

- criminal reporting;
- interviews;
- evidence provision;
- testimony;
- confrontation;
- restorative or mediation processes;
- witness protection;
- relocation;
- family contact;
- publicity or strategic litigation.

Support continues regardless of choice unless a specific lawful restriction applies independently.

## 9.2 Cooperation consent

SATN-11 requires understandable information, competent interpretation, independent advice, accessibility, known immigration and safety consequences, scope, duration, recording terms, onward use, withdrawal rules, and contact arrangements.

Consent to one interview, one subject, one jurisdiction, or one evidentiary act does not authorize unrelated intelligence tasking, undercover recruitment, biometric matching, device access, family investigation, publicity, or indefinite contact.

## 9.3 Withdrawal and lawfully obtained material

Withdrawal ends future voluntary participation. Material already lawfully acquired remains governed by its own authority, purpose, disclosure, evidence, retention, correction, and challenge rules. Withdrawal does not reduce shelter, healthcare, legal aid, protection, status access, or compensation claims.

# 10. Support, intelligence, and investigation firewall

SATN-10 and SATN-25 shall keep at least these functions separate:

- essential services and case management;
- asylum and protection adjudication;
- civil and service identity;
- trafficking support;
- witness protection;
- intelligence intake and analysis;
- criminal investigation;
- evidence custody;
- prosecution;
- border and immigration enforcement;
- public reporting and statistics.

A single organization may host more than one function only where law, personnel, access, systems, purpose, supervision, notice, review, and remedies remain separable. A shared interface, database vendor, building, funder, or administrator does not erase the firewall.

# 11. Investigation referral and acceptance

A survivor, Migration body, Shield service, or other authorized actor may offer an investigative referral. The referral shall use SATN-12 and the canonical handoff states:

`offered`, `received_not_assessed`, `deficient`, `partially_accepted`, `accepted`, `concurrent_responsibility`, `rejected`, `withdrawn`, `returned`, or `closed`.

Receipt, acknowledgement, meeting attendance, technical ingestion, or elapsed time does not open an investigation. An accepted investigation requires `SCPA-11`, a competent investigative authority, exact mandate, jurisdiction, individualized basis, methods, access controls, review, and closure.

A recipient may accept victim protection while rejecting investigation, or accept voluntary interviews while rejecting compulsory process. Sender duties survive unaccepted scope.

# 12. Protected information and source restrictions

SATN-13 and SATN-26 shall classify and protect:

- source identities and methods;
- privileged legal communications;
- humanitarian, health, shelter, and psychosocial records;
- mediation or spiritual disclosures;
- survivor location and identity;
- child and family information;
- Indigenous-restricted knowledge;
- immigration and asylum records;
- intelligence and classified material;
- evidence and chain-of-custody records.

Protected information may use sender-retained custody, redacted transfer, purpose-limited access, protected reviewer access, or a clean-team mechanism. Urgency, seriousness, interoperability, or “need to know” does not create disclosure authority.

# 13. Security allegation package

A Shield-originated or Shield-routed allegation proposed for use in a Migration matter shall enter only through SATN-14 and `SCPA-30`.

The package shall identify:

- the exact allegation and whether it concerns conduct, association, identity, risk, or source reporting;
- the originating and transmitting authorities;
- legal basis and jurisdiction;
- proposed Migration use;
- source type, collection context, and restrictions;
- analysis versus reported fact;
- confidence, corroboration, alternatives, dissent, and exculpatory or contextual material;
- known errors, aliases, translation limits, identity uncertainty, and date bounds;
- prohibited uses;
- review, expiry, correction, withdrawal, and remedy routes.

A label such as “security concern,” “network associate,” “foreign fighter,” “extremist,” “trafficker,” “smuggler,” “gang-linked,” or “intelligence match” is not a sufficient allegation package.

# 14. Reliability, corroboration, and prohibited inference

SATN-15 shall prevent:

- source secrecy from being treated as reliability;
- multiple reports derived from one source from being treated as independent corroboration;
- database repetition from becoming confirmation;
- algorithmic scores, watchlist matches, or biometric matches from becoming individualized proof;
- nationality, religion, ethnicity, route, family, neighbourhood, association, occupation, poverty, trauma, or missing documents from becoming dangerousness;
- contact with smugglers, traffickers, family members, humanitarian actors, or armed groups from proving voluntary membership;
- refusal to cooperate from proving guilt or adverse credibility;
- compelled conduct from being ignored.

Uncertainty and dissent shall remain visible to every lawful recipient.

# 15. Disclosure, protected review, and effective challenge

## 15.1 Sufficient substance

Before an allegation contributes to exclusion, adverse status, detention, family separation, extradition, deportation, expulsion, transfer, or another serious consequence, the person shall receive sufficient substance to understand and answer it, subject to narrowly lawful limitations.

## 15.2 Lawful substitute

Where direct disclosure would expose a protected source or cause a specifically identified serious harm, SATN-16 and SATN-17 shall record:

- the legal basis for limitation;
- the exact protected interest;
- why narrower redaction is insufficient;
- an independent reviewer with necessary access and authority;
- counsel, special advocate, representative, or equivalent adversarial safeguard where available;
- the gist or substitute information provided;
- limits on the decision-maker’s use;
- reasons, review, appeal, expiry, and correction.

If no mechanism provides an effective challenge appropriate to the consequence, the allegation shall not support that consequence.

# 16. Protection, exclusion, and security adjudication

SATN-18 shall keep separate findings on:

- eligibility for asylum or another protection status;
- any lawful exclusion ground;
- any security-related restriction;
- non-refoulement;
- temporary admission or stay;
- identity uncertainty;
- trafficking or compelled-conduct protection;
- criminal investigation or prosecution status.

An exclusion or security finding does not itself establish removability, detention necessity, extraditability, or a safe destination. An asylum refusal does not authorize criminal transfer. A criminal case does not determine protection. A protection grant does not adjudicate criminal guilt.

# 17. Detention and family-separation non-activation

SATN-19 shall record that none of the following alone activates arrest, detention, guarded custody, family separation, or intrusive supervision:

- a Shield request or allegation;
- a trafficking indicator;
- a witness-protection offer;
- irregular entry or route;
- missing documents;
- biometric refusal;
- inability to pay;
- adverse credibility alone;
- pending identity checks;
- administrative convenience;
- a desire to preserve testimony;
- concern that a person may disengage from services.

Any custody route requires SATN-20 and independently valid `SCPA-20`/`SCPA-21` records, individualized necessity, proportionality, alternatives, written reasons, counsel, interpretation, welfare, prompt review, time limits, release, and remedy.

A “safe house,” reception centre, witness facility, hospital, transport, or shelter becomes custody when exit is not genuinely available.

# 18. Transfer, extradition, deportation, and return

SATN-21 shall maintain separate routes for:

- extradition;
- criminal transfer;
- prisoner transfer;
- expulsion;
- deportation;
- responsibility transfer;
- witness relocation;
- protective relocation;
- evacuation;
- voluntary or assisted return;
- rematriation.

Each requires its own authority, purpose, evidence, notice, counsel, interpretation, destination, custody, specialty or use limits where applicable, independent review, challenge, non-refoulement assessment, termination, and remedy.

Shield cooperation, a warrant, an asylum refusal, or a security allegation cannot substitute for a transfer or removal record.

# 19. Non-refoulement and chain-return assessment

SATN-22 shall assess the reasonably foreseeable risk of direct, indirect, informal, disguised, or onward transfer to grave harm. The assessment shall consider destination conditions, the person’s characteristics and history, trafficking and retaliation risks, family or community threats, detention conditions, access to protection, likely onward movement, monitoring limits, and uncertainty.

Any criminal allegation, exclusion analysis, diplomatic assurance, bilateral arrangement, receiving-state promise, or route designation remains subject to independent assessment. The existence of an assurance does not prove safety. The reviewer shall consider specificity, reliability, enforcement, access, monitoring, past compliance, remedy, and chain-return risk.

A continuing duty not to expose a person to grave harm is not extinguished by denial of a particular status.

# 20. Suspensive challenge and interim relief

SATN-23 shall provide an urgent route to stop transfer, removal, detention, disclosure, family separation, or identity exposure where an effective challenge, source review, non-refoulement assessment, or remedy could otherwise become meaningless.

Where irreversible harm is plausible, the challenge shall have suspensive effect until a competent independent body decides otherwise under law. A deadline, flight booking, detention-transfer schedule, emergency label, or foreign request cannot defeat effective review.

# 21. Witness protection and safe relocation

SATN-24 distinguishes voluntary protection from custody. It shall identify consent, location, duration, family and dependant needs, legal status, livelihood, healthcare, education, accessibility, communication, identity use, travel, exit, review, and remedy.

Witness protection shall not:

- compel testimony;
- erase identity without lawful process;
- create hidden detention;
- separate families without individualized safeguarding;
- condition asylum or residence on cooperation;
- prevent access to counsel or protection authorities; or
- transfer a person to another jurisdiction without separate authority and non-refoulement review.

# 22. Identity, service, and data separation

SATN-25 shall preserve separate identifiers and access controls for service identity, civil identity, asylum identity, trafficking-support identity, witness identity, intelligence identity, investigative identity, suspect identity, travel identity, and public statistics.

A common identity-resolution service may link records only through lawful, logged, purpose-limited operations with correction and challenge. No universal watchlist, victim registry, or migration-security profile is created by this Addendum.

# 23. Information and evidence custody

SATN-26 maps ownership, possession, functional custody, technical access, evidentiary custody, disclosure authority, and disposition separately.

A change in support responsibility does not transfer evidence custody. A prosecutor receiving evidence does not gain access to shelter or health files. A Migration authority receiving an allegation does not gain source-tasking power. Shield retaining a source does not control the protection adjudication.

# 24. Correction and expungement

When an allegation, identity match, translation, association, trafficking classification, status record, or attribution is incorrect, incomplete, stale, unlawfully obtained, withdrawn, or superseded, SATN-27 shall record:

- the correction and supporting basis;
- recipients and downstream systems;
- suspension of consequential use;
- watchlist, alert, flag, and model-feature removal;
- decision reconsideration;
- affected-person notice where safe;
- public correction where public harm occurred;
- retention or deletion rules;
- audit of whether the error propagated.

A correction is incomplete if the originator changes its file but downstream recipients continue to use the old allegation.

# 25. Remedy

SATN-28 may coordinate:

- release and cessation of restrictions;
- restoration or reconsideration of protection status;
- family reunification or safe alternative placement;
- return of documents, devices, property, wages, or benefits;
- correction, expungement, deletion, or sealing;
- compensation and restitution;
- healthcare and psychosocial repair;
- legal costs;
- public correction;
- disciplinary, investigative, contractual, or institutional reform;
- guarantees of non-repetition.

Support and remedy shall not depend on conviction, publicity, strategic-litigation participation, or waiver of other claims.

# 26. Review and clock architecture

The Packet shall track independently:

- immediate support and urgent protection;
- reflection or temporary stay;
- asylum and protection adjudication;
- security-allegation use;
- investigation;
- evidence preservation;
- detention and release;
- extradition or transfer;
- deportation or return;
- witness protection;
- correction and remedy;
- data retention and disposition.

An open investigation does not prolong detention, temporary stay, witness restrictions, or allegation use. A pending asylum case does not preserve an expired investigative permission. A foreign request does not suspend domestic review. Where one act genuinely requires several valid records, the earliest expiry controls unless lawfully renewed through each route.

# 27. Public communication and anti-stigmatization

Public communication shall distinguish allegation, suspicion, investigation, charge, adjudication, victim identification, and final status. It shall not expose a survivor, shelter, route, family, source, applicant, or protected witness; imply guilt from migration status; or describe a whole community as a trafficking or security threat.

Public corrections shall receive prominence proportionate to the original harm where lawful and safe.

# 28. Emergency and Aegis interfaces

Where an emergency is active, ESDIB v0.1 is mandatory when emergency information, screening, transport, isolation, finance, cyber action, or converted capabilities intersect with Shield or Migration routes. Emergency authority cannot replace SATN-14 through SATN-23.

Any proposal to use an Aegis-converted capability for border surveillance, identity screening, intelligence, guarded custody, detention, extradition, deportation, prisoner transfer, evidence collection, armed protection, or sanctions enforcement triggers `SCPA-44`. Reversion suspends civilian assurances; it does not authorize the security use.

# 29. Termination, detachment, and closure

SATN-29 terminates each route independently and returns authority, access, credentials, custody, records, property, and responsibilities as required. Essential shelter, healthcare, legal aid, interpretation, accessibility, child protection, and safety planning shall not collapse because an investigation, cooperation request, or security allegation closes.

SATN-30 may become `closed` only after:

- all handoffs are resolved;
- coercive and information-use authorities are terminated or detached to ordinary law;
- detention, transfer, and removal routes are closed or independently continuing;
- services have a continuity owner;
- correction and affected-person access duties are complete;
- data and evidence disposition is recorded;
- remedy and compensation are complete or lawfully transferred;
- unresolved non-refoulement, child, survivor, or family duties have a responsible owner.

Reopening the Packet restores coordination only. It does not reactivate expired intelligence, investigation, detention, transfer, removal, or disclosure authority.

# 30. Canonical SATN records

| Record | Title | Function |
|---|---|---|
| `SATN-01` | Compatibility, Authority, and Jurisdiction Declaration | Pins exact instruments, authorities, jurisdictions, and non-authority effect. |
| `SATN-02` | Compound Protective-Action and Local-Case Identity Link | Links CFPAE, Shield, Migration, court, protection, investigation, and emergency identifiers without substitution. |
| `SATN-03` | Affected-Person Protected Reference and Access Plan | Defines protected identity references, representatives, access layers, and contact safety. |
| `SATN-04` | Trafficking or Exploitation Indicator Intake | Records indicators, uncertainty, source limits, and prohibited inferences without adjudicating victim or offender status. |
| `SATN-05` | Immediate Safety, Service, and Protection Offer | Records unconditional shelter, healthcare, interpretation, legal aid, income, accessibility, and safety support. |
| `SATN-06` | Reflection, Recovery, and Temporary-Stay Interface | Records a safe period, removal stay where lawful, service continuity, and independent advice. |
| `SATN-07` | Survivor Process Choice and Non-Conditioning Record | Records chosen, declined, paused, or withdrawn participation without loss of support. |
| `SATN-08` | Safe Contact, Location, Identity, and Family-Risk Plan | Protects location, communication, aliases, family links, and relocation choices. |
| `SATN-09` | Child, Dependent Person, Guardian, and Best-Interests Interface | Coordinates independent representation, safeguarding, family tracing, and review. |
| `SATN-10` | Support–Intelligence–Investigation Separation Record | Separates service data, migration data, intelligence, evidence, investigation, and prosecution functions. |
| `SATN-11` | Voluntary Investigative Cooperation Consent Record | Defines informed scope, legal advice, risks, withdrawal, and support non-retaliation. |
| `SATN-12` | Investigation Referral, Acceptance, and Non-Activation Record | Uses explicit handoff states; referral or receipt does not open an investigation. |
| `SATN-13` | Protected Source or Information Intake and Caveat Record | Preserves source, privilege, humanitarian, medical, mediation, survivor, child, and Indigenous restrictions. |
| `SATN-14` | Security Allegation Offer and Purpose Record | States exact allegation, proposed use, lawful basis, action class, recipient, and prohibited uses. |
| `SATN-15` | Allegation Provenance, Reliability, Corroboration, and Dissent Record | Separates source reporting, analysis, confidence, alternatives, exculpatory material, and unresolved disagreement. |
| `SATN-16` | Disclosure, Gist, Notice, Counsel, and Answer Package | Provides sufficient substance for meaningful challenge or records a lawful equivalent protective mechanism. |
| `SATN-17` | Independent Protected-Material Review Record | Records reviewer authority, access, adversarial substitute, necessity findings, limits, and reasons. |
| `SATN-18` | SCPA-30 Protection and Security-Allegation Adjudication Interface | Maintains protection, exclusion, security, non-refoulement, and status decisions as distinct findings. |
| `SATN-19` | Detention and Family-Separation Non-Activation Record | Records that an allegation, trafficking indicator, irregular route, or missing document does not activate custody. |
| `SATN-20` | Separate Custody, Detention, Release, and Alternative Route | Links independently authorized SCPA-20/21 records, welfare, review, release, and remedies. |
| `SATN-21` | Expulsion, Deportation, Extradition, Transfer, and Return Separation Record | Keeps each mobility consequence separately authorized, noticed, reviewed, and appealable. |
| `SATN-22` | Non-Refoulement and Chain-Return Assessment | Assesses direct, indirect, informal, and onward-transfer risk independently of exclusion or criminal cooperation. |
| `SATN-23` | Suspensive Challenge, Interim Relief, and Urgent Review Record | Stops irreversible transfer where grave-harm risk or effective-challenge defects remain unresolved. |
| `SATN-24` | Witness Protection, Safe Relocation, and Transfer Consent Record | Separates voluntary protection from hidden custody, compelled testimony, or immigration leverage. |
| `SATN-25` | Identity, Status, Service, and Enforcement Firewall Record | Separates service access, asylum, civil identity, victim identity, witness identity, and suspect identity. |
| `SATN-26` | Information, Evidence, and Custody Map | Maps possession, access, source restrictions, chain of custody, onward transfer, retention, and return. |
| `SATN-27` | Allegation Correction, Watchlist Removal, Expungement, and Notice Record | Propagates correction to all recipients and blocks continued use of superseded allegations. |
| `SATN-28` | Release, Restitution, Compensation, and Institutional Remedy Record | Coordinates remedies for wrongful disclosure, denial, detention, transfer, stigmatization, or service loss. |
| `SATN-29` | Route Termination, Authority Return, and Service Continuity Record | Ends permissions and coercive routes while preserving essential services and unresolved lawful duties. |
| `SATN-30` | Pairwise Closure and Unresolved-Duty Register | Prevents closure while review, correction, data disposition, release, remedy, or non-refoulement duties remain open. |

# 31. SCPA inheritance and conformance crosswalk

| SCPA record | Relationship | SATN record(s) | Shield record(s) | Migration record(s) | Conformance note |
|---|---|---|---|---|---|
| `SCPA-01` | extends | SATN-01 | SHIELD-01/04/41 | MOB-01 | Exact authority and version provenance. |
| `SCPA-02` | splits | SATN-01/02 | SHIELD-04 | MOB-01/22/27/29 | Jurisdiction remains route-specific. |
| `SCPA-03` | extends | SATN-02/04/12/14/18/20/21 | SHIELD-01/09/10/33 | MOB-34 | Every act and transition is separately classified. |
| `SCPA-04` | extends | SATN-04/15/18/19 | SCPA direct import via SHIELD-09/33 | MOB-04/06/10 | Individualized facts; no status inference. |
| `SCPA-05` | extends | SATN-04/15/25/27 | SHIELD-05/08/34 | MOB-05/10/33/35 | Prohibited inference, automation, and correction. |
| `SCPA-06` | extends | SATN-18/19/20/21/22/23 | SHIELD-05/33/35 | MOB-08/19/21/22/25 | Separate necessity and alternatives per route. |
| `SCPA-07` | contains | SATN-03/05/07/09/18/20/22/24 | SHIELD-05/26/28/29 | MOB-11/13/17/18 | Rights and protected-status safeguards. |
| `SCPA-08` | splits | SATN-16/18/20/21/23 | SHIELD-02/35 | MOB-11/32 | Notice and challenge remain route-specific. |
| `SCPA-09` | extends | SATN-13/14 | SHIELD-06 | MOB-09/18 | Protected intake and caveats. |
| `SCPA-10` | splits | SATN-10/14/15/26/27 | SHIELD-07/08/37 | MOB-10/33 | Purpose, minimization, dissemination, and disposition. |
| `SCPA-11` | imports | SATN-12 | SHIELD-09 referral; SCPA direct import | SCPA direct import | Investigation requires separate competent opening. |
| `SCPA-12` | imports | SATN-12/26 | SCPA direct import | SCPA direct import | Method authority remains outside the addendum. |
| `SCPA-13` | imports | SATN-12/26 | SHIELD-10/11 | SCPA direct import | Compulsory process is never inherited from referral. |
| `SCPA-14` | imports | SATN-26 | SCPA direct import | SCPA direct import | Search or entry requires separate authorization. |
| `SCPA-15` | imports | SATN-13/26 | SHIELD-11 | SCPA direct import | Disclosure or preservation order remains separate. |
| `SCPA-16` | imports | SATN-26 | SHIELD-12 | SCPA direct import | Evidence custody distinct from service records. |
| `SCPA-17` | not_applicable | — | SHIELD-21/22 when separately triggered | SCPA direct import | No asset restraint created by this addendum. |
| `SCPA-18` | extends | SATN-05/06/08/09/24 | SHIELD-26/28/29 | MOB-07/18 | Urgent protection remains temporary and non-carceral. |
| `SCPA-19` | imports | SATN-19/20 | SCPA direct import | SCPA direct import | Arrest or restraint requires separate authority. |
| `SCPA-20` | extends | SATN-19/20 | SCPA direct import | MOB-19/20 | No detention by allegation, support, or witness protection. |
| `SCPA-21` | extends | SATN-20/23 | SCPA direct import | MOB-19/20/32 | Release and alternatives have independent clocks. |
| `SCPA-22` | splits | SATN-21/22/23 | SHIELD-33 | MOB-21/22/23 | Transfer, removal, extradition, and return remain distinct. |
| `SCPA-23` | imports | SATN-20/28 | SCPA direct import | SCPA direct import | Force cannot be inferred from protection or custody. |
| `SCPA-24` | imports | SATN-20 | SCPA direct import | SCPA direct import | Weapons or restraints require separate authority. |
| `SCPA-25` | extends | SATN-02/20/24/26 | SHIELD-13 when a mission exists | MOB-34 when a route exists | Command and custody remain separate. |
| `SCPA-26` | not_applicable | — | SHIELD-15 when separately triggered | SCPA direct import | No cyber authority created. |
| `SCPA-27` | not_applicable | — | SHIELD-16 when separately triggered | SCPA direct import | No third-party cyber action created. |
| `SCPA-28` | not_applicable | — | SHIELD-20–25 when separately triggered | SCPA direct import | No sanctions, freeze, or forfeiture authority created. |
| `SCPA-29` | extends | SATN-12/14/21/26 | SHIELD-01/02/04/10 | MOB-22/34 | Cross-border requests use explicit acceptance states. |
| `SCPA-30` | implements | SATN-14/15/16/17/18/22/23 | SHIELD-33 | MOB-06/07/08/10 | Core protection, allegation, and non-refoulement interface. |
| `SCPA-31` | extends | SATN-17/18/20/21/22 | SHIELD-35; Justice controls | MOB-08/13/19/21/22 | Independent authorization and review. |
| `SCPA-32` | implements | SATN-16/23/27 | SHIELD-35 | MOB-32 | Complaint, appeal, urgent challenge, interim relief. |
| `SCPA-33` | extends | SATN-27/28/30 | SHIELD-24/25/36 | MOB-24/32/38 | Correction, restitution, compensation, and remedy. |
| `SCPA-34` | extends | SATN-07/11/24 | SCPA direct import | MOB-23 where return/reintegration applies | Participation and reintegration remain voluntary. |
| `SCPA-35` | implements | SATN-10/26/27/30 | SHIELD-37 | MOB-33/38 | Use limitation, correction, expungement, disposition. |
| `SCPA-36` | implements | SATN-29/30 | SHIELD-38 | MOB-38 | Termination does not extinguish services or remedies. |
| `SCPA-37` | implements | SATN-25 | SHIELD-32 | MOB-02/03/04/05 | Identity and service-access separation. |
| `SCPA-38` | implements | SATN-09 | SHIELD-29 | MOB-12/13/14 | Child, guardian, and best-interests safeguards. |
| `SCPA-39` | imports | SATN-03/13/22 | SHIELD-30 | MOB-24/29 | Affected Indigenous authority imported when triggered. |
| `SCPA-40` | implements | SATN-05/07/08/10/11/24 | SHIELD-26/28 | MOB-18 | Survivor sovereignty and confidentiality. |
| `SCPA-41` | extends | SATN-11/12/28 | SHIELD-27/31 | MOB-31 | Witness, worker, advocate, and whistleblower protection. |
| `SCPA-42` | extends | SATN-16/27 | SHIELD-34 | MOB-35 | Public allegation status, anti-stigma, correction. |
| `SCPA-43` | extends | SATN-29/30 | SHIELD-39 | MOB-38 | Institutional transfer and continuity. |
| `SCPA-44` | imports | SATN-02/29 | SHIELD-40 | MOB-37 | Aegis reversion imported if a converted capability enters the case. |

# 32. Handoff catalogue

At minimum, implementations shall support these explicit handoffs:

| Handoff | Sender | Recipient | May transfer | Does not transfer |
|---|---|---|---|---|
| Survivor service referral | Shield or competent investigator | Migration/support function | Minimum protected needs and chosen contact route | Investigation consent, source tasking, immigration enforcement authority |
| Protection referral | Shield victim service | Migration protection authority | Fear-of-return or protection request with consent or lawful basis | Status decision, exclusion finding, detention or removal authority |
| Investigation referral | Migration/support function or survivor | Competent investigative authority | Chosen report or separately lawful minimum | Whole service file, compelled cooperation, asylum decision authority |
| Security allegation offer | Shield competent function | Migration protection/adjudication function | SATN-14–17 package within `SCPA-30` | Automatic adverse consequence, source tasking, detention or transfer authority |
| Corroboration request | Migration competent authority | Shield or source-holding authority | Narrow factual question under SCPA-29 | Open-ended intelligence tasking or fishing expedition |
| Evidence transfer | Competent investigative authority | Prosecutor/court/authorized recipient | Lawfully obtained evidence and chain of custody | Shelter, health, legal, mediation, or asylum files by default |
| Witness protection request | Investigator/prosecutor or survivor advocate | Competent protection body | Individualized safety needs and chosen conditions | Hidden custody, compelled testimony, migration-status leverage |
| Extradition or transfer request | Foreign/domestic competent authority | Competent legal and Migration authorities | Formal request and lawful evidentiary packet | Asylum refusal, detention, surrender, or non-refoulement conclusion |
| Correction withdrawal | Originating authority | Every recipient and derivative system | Corrected record, withdrawal, use-stop, review request | Permission to retain or continue use without legal basis |
| Closure and remedy handoff | Current responsible body | Successor or remedy authority | Named unresolved duties and protected material | Residual jurisdiction or automatic authority continuation |

# 33. Conformance levels

- **SATN-L0 — Referenced:** the Addendum is cited but no operational packet is used.
- **SATN-L1 — Record conformant:** all triggered SATN and SCPA records use RIC headers, access classes, versions, and lifecycle states.
- **SATN-L2 — Pairwise interoperable:** Shield and Migration use explicit CFPAE routes, handoffs, custody maps, clocks, challenge, and closure.
- **SATN-L3 — Compound operational:** relevant Justice, Kintsugi, emergency, Indigenous, child, health, labour, and Aegis interfaces are tested in realistic multi-jurisdiction scenarios.

L0 is not sufficient for consequential implementation. L1 may support controlled prototypes. L2 is required for pairwise routing. L3 is required where custody, transfer, emergency, children, protected sources, or converted capabilities are involved.

# 34. Constitutional readiness gates

An implementation passes only if all applicable gates are satisfied:

1. exact compatible versions are pinned;
2. SCPA-RIC and CFPAE are adopted;
3. support opens without investigative cooperation;
4. trafficking indicators do not adjudicate guilt, victim status, or removability;
5. service, asylum, intelligence, investigation, and enforcement systems are separated;
6. every security allegation enters through SATN-14–18 and `SCPA-30`;
7. provenance, reliability, alternatives, dissent, and exculpatory information are visible;
8. sufficient substance or an effective lawful substitute enables challenge;
9. the decision-maker is independent from the allegation originator;
10. no allegation automatically determines status, detention, family separation, or removal;
11. non-refoulement is independently assessed and remains effective after exclusion analysis;
12. detention requires separate individualized authority and alternatives;
13. witness protection is not hidden custody;
14. extradition, deportation, expulsion, transfer, relocation, and return are separately routed;
15. challenges have suspensive effect where irreversible harm is plausible;
16. child and dependent-person safeguards are operational;
17. survivor location, identity, health, and service data are protected;
18. compelled conduct and non-punishment are considered;
19. corrections propagate to every recipient and derivative system;
20. public allegations use non-prejudicial status language;
21. remedies include release, reconsideration, correction, compensation, and institutional repair;
22. emergency routes use ESDIB without bypassing SCPA;
23. Aegis security-facing use triggers `SCPA-44`;
24. closure leaves no residual power or abandoned service, review, correction, or remedy duty.

# 35. Compound implementation tests

| # | Scenario | Pass condition |
|---:|---|---|
| 1 | Potential trafficking victim lacks documents and refuses police contact | Services and protection open through SATN-04/05/07; no investigation, detention, or adverse credibility inference. |
| 2 | Survivor accepts shelter but declines testimony | Support continues; SATN-11 remains declined; no funding, residence, or protection penalty. |
| 3 | Migration caseworker sends a service note to Shield automatically | Blocked: SATN-10/25 require separate lawful purpose and handoff; technical receipt is not acceptance. |
| 4 | Shield sends a confidential allegation about an asylum applicant | SATN-14–18 and SCPA-30 required; no automatic exclusion, detention, family separation, or removal. |
| 5 | Allegation comes from one anonymous source with no corroboration | Reliability limits and alternatives recorded; independent reviewer cannot treat source secrecy as proof. |
| 6 | Disclosure would expose a protected source | Provide a sufficient gist or lawful equivalent protective mechanism; otherwise adverse use is blocked. |
| 7 | Applicant cannot effectively answer because counsel lacks access | Consequential use pauses; SATN-16/17/23 require effective challenge or protective substitute. |
| 8 | Security body labels a trafficking survivor an associate of the trafficker | Association alone is prohibited; individualized facts and compelled-conduct analysis required. |
| 9 | Survivor committed document or low-level offences under coercion | SATN-04/18 record non-punishment assessment; support is unaffected. |
| 10 | Shield requests detention while verifying an allegation | Request alone does not activate custody; separate SCPA-20 necessity, alternatives, and review required. |
| 11 | Authority calls locked witness accommodation “protection” | Classified as custody if exit is not real; SATN-20 and SCPA Class F requirements apply. |
| 12 | Child survivor travels with an alleged family member | SATN-09 best-interests and safety assessment precede reunification or transfer. |
| 13 | Family tracing could reveal shelter location to a trafficker | SATN-08 restricts contact and location disclosure; safety overrides automatic family notification. |
| 14 | Extradition request arrives while asylum is pending | Separate SATN-21/22 routes; protection and non-refoulement review continue with suspensive relief. |
| 15 | Criminal allegation is serious but return would expose the person to torture or persecution | Exclusion and criminal cooperation remain separate from non-refoulement; transfer is blocked where required. |
| 16 | Removal authority relies on diplomatic assurances | Independent SATN-22 review assesses reliability, monitoring, enforceability, and chain-return risk; assurances do not self-validate. |
| 17 | Person “volunteers” for return after prolonged unlawful detention | Consent is treated as potentially coerced; release, independent advice, and SATN-23 review required. |
| 18 | Shield information later proves false | SATN-27 propagates correction, watchlist removal, expungement, recipient notice, and cessation of use. |
| 19 | False allegation caused detention and status denial | SATN-28 coordinates release, reconsideration, compensation, record correction, and systemic review. |
| 20 | Shield accepts victim protection but rejects investigation | Partial acceptance is recorded; support proceeds; sender retains unaccepted investigative duties. |
| 21 | Migration accepts allegation review but rejects raw source identity | Protected reviewer or sender-retained custody may be used; no silent transfer. |
| 22 | Survivor chooses to cooperate only about one trafficker | SATN-11 limits scope; unrelated intelligence tasking or status leverage is prohibited. |
| 23 | Survivor withdraws cooperation after evidence was lawfully preserved | Future voluntary cooperation stops; already lawfully obtained evidence is separately governed and support continues. |
| 24 | Emergency evacuation also involves border screening | ESDIB and separate SCPA/Migration routes required; emergency transport does not create screening or removal authority. |
| 25 | Aegis aircraft is proposed for guarded deportation transport | SCPA-44 reversion triggers; Aegis charter cannot authorize custody or deportation. |
| 26 | Public statement calls the applicant a trafficker before adjudication | SATN-27/SCPA-42 require allegation-status language, correction, and remedy. |
| 27 | Indigenous person’s protected community information is requested to assess identity | SCPA-39 restrictions apply; no universal proxy or coerced knowledge transfer. |
| 28 | Receiving authority never answers a Shield handoff | Silence is not acceptance; sender duties survive and consequential use remains blocked. |
| 29 | Investigation closes but asylum and support remain open | Routes close independently; Shield closure cannot terminate Migration services or protection. |
| 30 | All operations end but correction and compensation remain pending | SATN-30 cannot close; remedy and disposition clocks remain active. |

# 36. Minimum implementation package

A conformant implementation shall publish or protect as appropriate:

- the compatibility declaration;
- one CFPAE envelope and SATN Packet per compound case;
- all triggered SATN and SCPA records;
- the authority and responsibility map;
- the handoff and acceptance register;
- protected-information and evidence-custody maps;
- affected-person notice, counsel, access, and challenge routes;
- independent clock, expiry, detention, transfer, and non-refoulement registers;
- correction, remedy, termination, and closure records;
- a public constitutional summary that does not expose protected persons or sources.

# 37. Adoption clause

Shield v2.0 and Migration v1.1 may adopt this Addendum only through controlled successor patches that:

- pin `SH-MOB-SATN/0.1` and its exact hash;
- adopt `SCPA-RIC/0.1` and CFPAE v0.1;
- publish complete 44-record inheritance crosswalks;
- name the competent domain functions;
- preserve all stricter rights and exclusions in the parent frameworks;
- fail closed on incompatible substitutions;
- rerun the security-and-coercion cluster compound interface test.

# 38. Closing constitutional statement

Shield and Migration meet at a dangerous boundary: information about crime can determine whether a vulnerable person is protected, confined, transferred, or returned. The purpose of this Addendum is not to make that boundary frictionless. It is to make every crossing visible, lawful, contestable, reversible where possible, and accountable when wrong.

> **Support without coercive leverage. Allegations without automatic consequence. Cooperation without merged authority. Protection without refoulement. Closure without residual power.**

# Commons and Ecological Authority Cluster Conformance Adoption Patch v0.1

**Specification ID:** `CEACA/0.1`  
**Cluster release ID:** `CEA-CLUSTER/0.1`  
**Date:** 2026-08-01  
**Status:** controlled document-interface adoption specification  
**Authority effect:** none  

---

## 0. Purpose

This specification binds the commons and ecological authority successors into one exact compatibility set without creating a unified ecological sovereign. It resolves reciprocal versioning, common CERGTA inheritance, EIOI–Planetary Health role separation, MOS advisory status, cross-sector title and stewardship routing, emergency and coercive boundaries, and cluster-level closure.

It does not create rights, title, guardianship, jurisdiction, permits, tariffs, funding, emergency command, adjudication, or enforcement.

> **A cluster is a routing architecture, not a source of power. Compatibility is not authority.**

## 1. Exact controlled set

| Instrument | Exact compatible file | Cluster role |
|---|---|---|
| CERGTA/0.1 | `commons-ecological-rights-guardianship-title-resource-authority-interface-specification-v0.1.md` | controlling authority interface |
| EIPHR/0.1 | `ecological-intelligence-planetary-health-role-separation-matrix-v0.1.md` | EIOI–Planetary Health role separation |
| EIOI v2.7.1 | `ecological-intelligence-observation-interpretation-layer-v2.7.1.md` | ecological observation, provenance, methods, uncertainty, interpretation, and advisory alerts |
| PHG v0.9.1 | `planetary-health-governance-framework-v0.9.1.md` | independent synthesis, participatory audit, cross-domain coherence, and strategic recommendation |
| HEARTHSTONE v2.0.1 | `hearthstone-protocol-v2.0.1.md` | voluntary conversion, claims support, title and tenure interfaces, trusts, rematriation, stewardship, and transition |
| WATER v5.2.1 | `water-sanitation-governance-framework-v5.2.1.md` | watershed democracy, universal WASH, allocation, utilities, tariffs, guardianship interfaces, and emergency WASH |
| BIODIVERSITY v1.1.1 | `biodiversity-implementation-framework-v1.1.1.md` | Indigenous-led stewardship support, restoration programmes, rights-review support, biodiversity finance interfaces, and accountability |
| OCEANS v2.3.1 | `oceans-marine-governance-framework-v2.3.1.md` | marine stewardship, quotas and licensing interfaces, port-state measures, crew protection, precaution, and marine emergencies |
| SOIL v3.2.1 | `soil-health-land-use-governance-framework-v3.2.1.md` | living-soil protection, regenerative land-use programmes, microbial commons, tenure interfaces, certification, and remediation |
| MOS v2.8.1 | `moral-operating-system-v2.8.1.md` | advisory ethical deliberation, rights imagination, plural translation, and structural self-correction |

The exact SHA-256 digest of every completed file is frozen in the conformance registry after all patch documents are built.

## 2. Order of control

Where documents conflict, the following order governs the cluster interface:

1. independently applicable constitutional, Indigenous, treaty, and jurisdiction-specific law;
2. independently valid human-rights, labour, humanitarian, environmental, and procedural protections;
3. `CERGTA/0.1` for ecological and commons authority-class separation;
4. `EIPHR/0.1` for EIOI–PHSO–PHC separation;
5. the specific framework's bounded domain rule;
6. this adoption specification for version compatibility, transport, and closure;
7. advisory materials, examples, dashboards, model policies, targets, roadmaps, and public communication.

No lower layer can enlarge an upper-layer power.

## 3. Cluster roles

| Component | Owns | Does not own |
|---|---|---|
| EIOI | observations, provenance, methods, uncertainty, interpretation, advisory alerts | legal recognition, guardianship, title, finance, sanctions, emergency command |
| PHSO | transparent modular BHI synthesis | ecological method custody, legal effect, operational command |
| PHC | strategic interpretation, participatory audit, recommendations | binding directives, vetoes, funding freezes, emergency powers, enforcement |
| Hearthstone | transition process, claims support, trust and title interfaces, stewardship lifecycle | automatic confiscation, global title, universal court, enforcement |
| Water | WASH programmes and separately delegated watershed functions | automatic guardianship, universal tariff, household shutoff, general emergency command |
| Biodiversity | restoration and stewardship programmes, rights-review support | personhood ratification, guardian appointment, trade exclusion, ecocide adjudication |
| Oceans | marine programmes and separately delegated port, quota, or licensing functions | automatic blacklisting, collective punishment, universal high-seas jurisdiction |
| Soil | soil and land-use programmes and separately delegated standards | title adjudication, universal tax, automatic sale veto, rematriation tribunal |
| MOS | ethical questions, plural framing, rights imagination, self-correction | legal status, developmental classification, Indigenous consent, consequential authority |

## 4. Cluster-wide invariants

### 4.1 Observation–consequence membrane

An observation, citizen report, TEK contribution, satellite image, sample, digital twin, AI output, BHI module, LMCI result, Love Ledger entry, certification score, acoustic log, soil score, or threshold may open review. It does not create a legal consequence.

### 4.2 Rights–title–stewardship separation

Ecological rights do not transfer land, infrastructure, licences, concessions, carbon interests, seabed, water systems, or adjacent property. Guardians represent but do not own. Stewardship mandates do not silently change title.

### 4.3 Indigenous authority

The affected people retain authority over their own consent, representatives, law, knowledge, sacred relations, claims, and chosen governance form. Representation inside a global body never substitutes for the affected nation.

### 4.4 Essential minimums

Commercial accountability, tariffs, funding conditions, market restrictions, certification, or transition measures cannot interrupt essential life-safety and dignity functions.

### 4.5 Emergency and coercion

CDEE/ECRC may establish emergency identity and coordination. SCPA may govern separately authorized coercive execution. Neither supplies the ecological, title, guardianship, financial, or adjudicative authority missing from CERGTA, and CERGTA does not supply emergency command or coercion.

### 4.6 No authority through adoption

A document version, registry entry, framework membership, cross-reference, technical envelope, or adoption vote cannot make an advisory rule binding unless the competent legal route independently does so.

## 5. Handoff and acceptance

All consequential cross-framework handoffs use the canonical states:

`offered`, `received_not_assessed`, `deficient`, `partially_accepted`, `accepted`, `concurrent_responsibility`, `rejected`, `withdrawn`, `returned`, `closed`.

Silence and technical receipt are never acceptance. The recipient states the exact records accepted, legal purpose, restrictions, responsibility assumed, responsibility refused, clock, and return or closure conditions.

## 6. Clocks, expiry, and non-resurrection

Observation validity, model validity, legal recognition, guardianship, title actions, stewardship charters, permits, quotas, tariffs, listings, port restrictions, urgent protection, receivership, emergency authority, funding, and remedies keep independent clocks.

Expiry of one route does not automatically terminate another independently valid route. Conversely, an unresolved risk does not preserve expired authority. Any continuation requires a new lawful basis.

## 7. Correction and remedy

A correction propagates to every known recipient, registry, dashboard, model feature, certification, payment review, permit review, listing, title record, public statement, and derivative decision.

Remedies may include reconsideration, correction, deletion or sealing, service restoration, release of restrictions, return of property or records, compensation, restitution, restoration, legal costs, worker and community support, public correction, disciplinary action, interface suspension, and institutional redesign.

## 8. Compatibility states

- `compatible`: exact versions and hashes validate; required interfaces present.
- `conditionally_compatible`: non-consequential use is possible while a named implementation dependency remains.
- `failed_closed`: hash, version, authority, header, handoff, access, clock, remedy, or closure requirement is missing or incompatible.
- `retired`: release intentionally superseded and no longer accepts new handoffs.

Consequential cross-framework action requires `compatible`.

## 9. Adoption tests

The controlled set must demonstrate at least:

1. exact version identification;
2. CERGTA inheritance;
3. EIPHR role separation;
4. MOS advisory non-activation;
5. affected-nation authority;
6. rights–title–guardianship separation;
7. Hearthstone title routing;
8. metrics do not self-execute;
9. payments and restrictions use separate decisions;
10. essential minimums survive commercial enforcement;
11. emergency routes do not create permanent authority;
12. coercive execution remains separately authorized;
13. handoff acceptance is explicit;
14. clocks remain independent;
15. correction propagates;
16. remedy and closure are complete;
17. unknown versions fail closed;
18. pilots and targets do not activate power.

## 10. Release and supersession

This adoption specification remains immutable for `CEA-CLUSTER/0.1`. A later release receives a new adoption specification or version, registry, hashes, validation report, and full cluster rerun.

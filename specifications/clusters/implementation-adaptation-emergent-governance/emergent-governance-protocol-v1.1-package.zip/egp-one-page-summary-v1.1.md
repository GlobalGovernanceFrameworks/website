---
title: The Emergent Governance Protocol
section: egp-one-page-summary
version: 1.1
package: EGP/1.1
status: constitutionally-harmonized-quick-start
date: 2026-08-02
controlling_interface: GMEAIA/0.1
---

# The Emergent Governance Protocol (EGP) v1.1
## *One-Page Quick Start*

## Three shared operations

### `sense(issue)`
**Report an observation, concern, opportunity, or warning.**

Anyone may submit a signal, but it begins as an **assertion**.

- State what you observed.
- Link evidence and uncertainty.
- Identify who may be affected.
- Request review or routing.
- Do not treat the signal as a finding, emergency declaration, or proof of guilt.

### `propose(response)`
**Offer a candidate response.**

Include alternatives, affected parties and rights, who may decide, who must consent, resources, risks, test criteria, duration, exit, remedy, and protected-domain check.

A proposal is not consent, authority, funding, or enactment.

### `adopt(experiment)`
**Record that an actor claims to accept a proposal.**

Every adoption needs an effect label:

- claim only;
- expressive;
- voluntary internal;
- authorized but inactive;
- active bounded trial;
- suspended;
- terminated;
- closed;
- reference to a separate permanent enactment.

> **An EGP adoption is not active merely because it is signed, funded, coded, uploaded, or stored on a blockchain.**

## The authority envelope

A consequential trial references:

`affected parties + affected Indigenous authority + consent or lawful basis + authority + trial authorization + activation + rights + essential-service protection + monitoring + challenge + expiry + rollback + remedy + closure`

This envelope is governed by `GMEAIA/0.1`.

## Five rules

1. **Transport, do not manufacture authority.**
2. **Keep signals, proposals, consent, authorization, deployment, and activation separate.**
3. **Fail closed in protected domains.**
4. **Sunset temporary power, not continuing rights and duties.**
5. **Share learning without exposing protected people or knowledge.**

## Protected domains

Ordinary EGP experimentation cannot authorize coercion, borders, essential-service withdrawal, title transfer, child guardianship, irreversible ecological action, high-risk technology, adjudication, emergency command, taxation, forfeiture, or benefit withdrawal.

## Safe quick start

> I `sense()` [observation], affecting [asserted parties], supported by [evidence], with [uncertainty].

> I `propose()` [response], alongside [alternatives], requiring [authority and consent], for [duration], with [monitoring, exit, and remedy].

> We `adopt()` this as [effect label], under [authority], beginning only after [activation], expiring on [date], with [review and closure].

## What EGP is

A common grammar for coordination and learning.

## What EGP is not

A constitution, court, legislature, emergency command, funding authority, AI governor, or smart-contract jurisdiction.

> **EGP connects decisions. It does not authorize them.**

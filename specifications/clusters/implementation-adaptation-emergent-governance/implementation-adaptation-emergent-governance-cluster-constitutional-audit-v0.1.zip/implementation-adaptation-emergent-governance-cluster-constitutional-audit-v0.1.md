# Implementation, Adaptation, Emergent Governance, and Institutional Regeneration Cluster Constitutional Audit v0.1

**Audit ID:** `IAEG-CCA/0.1`  
**Date:** 2026-08-02  
**Status:** Constitutional source audit  
**Verdict:** **RED — constitutionally non-deployable as a shared implementation authority layer**

---

## 1. Scope and source-freeze decision

This audit treats the four EGP Markdown files as **one protocol package**, not as four frameworks:

1. *Emergent Governance Protocol v1.0* — normative core;
2. *EGP Implementation Appendix* — technical and implementation profile;
3. *EGP Glossary* — terminology;
4. *EGP One-Page Summary* — public quick-start layer.

The EGP describes itself as a minimum grammar of `sense()` → `propose()` → `adopt()`, rather than another substantive governance framework. It also claims that communities keep their own decision traditions while sharing a coordination grammar.

The remaining active documents are:

- **GGF Implementation & Adaptation Framework v1.0**
- **Institutional Regeneration Framework v0.8**
- **Implementation Methods & Tools Framework v0.7**
- **Wise Decision-Making & Integration Protocol v1.5**

The retired **Wisdom Governance / GWGF** track is excluded. Any reference to a retired body or framework is treated as stale dependency debt and cannot supply present authority.

### Cluster role

The cluster is best understood as the GGF's **implementation and institutional-method layer**:

- EGP supplies a common event grammar;
- Implementation & Adaptation selects pathways and tool stacks;
- Methods & Tools supplies practical instruments;
- Institutional Regeneration targets legacy organizations;
- WDIP supplies deliberative and epistemic methods.

That makes the cluster constitutionally important. It sits between substantive frameworks and actual action. A defect here can silently activate powers from every other cluster.

---

## 2. Executive verdict

The cluster contains valuable design commitments:

- subsidiarity;
- modularity;
- low-tech parity;
- experimentation;
- automatic review;
- learning from failure;
- cultural adaptation;
- public accountability;
- anti-capture;
- affected-community participation;
- graceful closure.

But it lacks a common constitutional membrane between **method** and **authority**.

> **A signal is not a finding. A proposal is not consent. Consent is not jurisdiction. A method is not a mandate. Adoption is not enactment. A pilot is not public law. A readiness score is not eligibility. An ethics review is not approval. An epistemic assessment is not a veto. A sunset is not lawful closure.**

The principal systemic risk is not centralization in one obvious council. It is **distributed authority laundering**: a tool, score, protocol, certified facilitator, AI system, funding tier, community label, or epistemic gate can make a decision appear authorized even though the underlying authority was never established.

### Results

| Measure | Result |
|---|---:|
| S0 systemic findings | 1 |
| S1 critical findings | 18 |
| S2 major findings | 13 |
| S3 moderate findings | 4 |
| Constitutional gates | 0 pass / 8 conditional / 28 fail |
| Compound scenarios | 1 pass / 12 conditional / 23 unsafe |

---

## 3. Systemic finding

### IAEG-00 — Method–authority collapse across the cluster — **S0**

Implementation methods, protocol calls, readiness scores, ethics gates, epistemic certification, funding tiers, and experimental adoption repeatedly carry or imply the authority of the substantive decision.

The cluster has no shared rule that:

- a method may structure deliberation but cannot create jurisdiction;
- a record may document consent but cannot manufacture it;
- a technical capability token cannot establish public office;
- a pilot framework cannot activate emergency power;
- an ethical reviewer cannot replace a competent legal authority;
- an epistemic assessor cannot suspend democracy;
- a funding administrator cannot rewrite an institution's constitution;
- a successful experiment cannot scale itself into binding policy.

Because this cluster interfaces with every substantive framework, the defect is trans-domain. An EGP `adopt()` record could appear to activate a health measure, water restriction, institutional restructuring, AI control, land-use rule, migration process, or security intervention without inheriting the constitutional requirements of the relevant domain.

---

## 4. EGP package audit

### 4.1 What EGP gets right

EGP's minimal grammar is conceptually strong:

- anyone may surface an issue;
- proposals should identify evidence, resources, tests, consent, and time limits;
- trials should include monitoring, review, exit, and learning;
- higher levels should not force local adoption;
- communities retain their own decision traditions;
- the same event grammar can connect heterogeneous systems.

This is a useful **transport and learning protocol**.

### 4.2 The missing fourth distinction

The three verbs are insufficient for consequential governance because `adopt()` compresses several legally different events:

1. deliberative acceptance;
2. consent;
3. authorization;
4. enactment;
5. trial registration;
6. operational activation;
7. implementation;
8. renewal;
9. suspension;
10. termination and closure.

The solution is not necessarily to abandon the three public verbs. EGP may retain the simple interface while requiring a deeper adoption envelope beneath `adopt()`.

### 4.3 Required fail-closed rule

> **EGP transports governance events. It does not create the authority represented by those events.**

An `adopt()` operation must be invalid for consequential use unless it references an independently valid authority package from the relevant framework and jurisdiction.

### 4.4 Sense is not verified fact

The stress packet currently allows the initiating agent to assign:

- severity;
- urgency;
- affected parties;
- evidence;
- geographic and jurisdictional scope.

Those are useful claims, but they must remain explicitly **asserted**, not verified.

A safe chain is:

`sense → receipt → validation status → jurisdictional triage → referral → investigation/assessment → decision`

The original signal remains preserved, but downstream systems must not treat its urgency or severity as self-authenticating.

### 4.5 AI and sensor agents

AI and sensors may create observations or candidate patterns. They cannot:

- establish affected-party identity;
- determine legal severity;
- declare an emergency;
- create a legal allegation;
- generate consent;
- choose an adopting authority;
- authorize or activate an intervention;
- renew an expiring power.

Machine-generated proposals must be visibly labelled and require a responsible human or lawfully constituted body before consequential routing.

### 4.6 DID and UCAN boundary

DIDs and UCANs can establish:

- cryptographic identity;
- signature validity;
- technical delegation;
- access to a software function.

They cannot establish:

- lawful jurisdiction;
- public office;
- fiduciary standing;
- affected-nation authority;
- representation of a community;
- emergency command;
- judicial competence.

A valid software capability must never be interpreted as a valid public-law capability.

### 4.7 Immutability and public-by-default

Content addressing and append-only logs may preserve accountability, but the package must support:

- protected payloads;
- sealed attachments;
- access classes;
- purpose limitation;
- correction records;
- revocation of access;
- lawful deletion or crypto-shredding;
- protected Indigenous knowledge;
- survivor and health data;
- whistleblower confidentiality;
- expungement and sealed proceedings.

Public metadata may prove that a process occurred without exposing the underlying protected content.

### 4.8 Sunset boundary

Sunset by default is appropriate for:

- pilots;
- delegated programmes;
- temporary rules;
- experimental budgets;
- optional methods.

It is not appropriate for:

- constitutional and human rights;
- essential service duties;
- remedy and compensation;
- child and dependent-person protection;
- evidence preservation;
- restoration obligations;
- pensions, wages, and debts;
- safety controls whose abrupt expiry creates harm.

Some records should expire; some should enter review; some duties persist until discharged.

---

## 5. Implementation & Adaptation Framework audit

### Strengths

The framework is careful about:

- context;
- anti-colonial practice;
- low-tech pathways;
- minimum viable implementation;
- exit safeguards;
- power mapping;
- community feedback;
- adaptation statements.

### Critical defects

#### Readiness classification

The GGF Readiness Index can route communities into different journeys. It therefore needs:

- a declared purpose;
- source and method;
- uncertainty;
- community challenge;
- correction;
- non-stigmatization;
- expiry;
- a prohibition on using the score to deny essential support, political standing, or self-determination.

#### Ethics Gate and dual-key approval

A facilitator panel or representative from a global Indigenous framework may review ethical risks. It cannot approve or reject an adaptation on behalf of the affected Indigenous nation or the competent local authority.

The gate should produce:

- concerns;
- missing safeguards;
- required consultation;
- dissent;
- a recommendation.

It should not itself create or withhold authority.

#### Crisis Quick Start

A rapid diagnostic may support emergency coordination. It cannot activate the PIS, Crisis Command, or any emergency power without the harmonized ECRC/CDEE route.

The correct chain is:

`local signal → CDEE referral → competent declaration/acceptance → bounded mission → expiry and return`

---

## 6. Implementation Methods & Tools Framework audit

### Strengths

This framework has the most practical protections in the cluster:

- analog companions;
- community refusal;
- harm detection;
- pause and retirement;
- remediation;
- accessibility;
- crip-time flexibility;
- failure learning;
- tool lifecycle management.

### Risks

#### Tool authority

A toolkit must never imply that using a template creates:

- a council;
- jurisdiction;
- a valid charter;
- an emergency ombudsperson;
- a legal consent record;
- a benefit entitlement;
- a tribunal;
- a coercive power.

Each resource card should state its **authority effect**: none, advisory, record-support, or valid only under separately cited law.

#### Certification

Facilitator certification can support quality but must not become a monopoly. The framework needs:

- local-equivalence recognition;
- open assessment;
- accessible pathways;
- conflicts and recusal;
- complaints and removal;
- liability;
- community choice;
- no denial of participation because a certified facilitator is unavailable.

#### Community veto

A community can refuse a tool within its own process. That does not automatically allow it to:

- bind another community;
- prevent individual opt-in where lawful;
- override affected outsiders;
- veto a public authority outside its jurisdiction.

The holder, object, territory, duration, and remedy of refusal must be specified.

#### Failure Library

Learning artifacts need explicit separation between:

- public method lessons;
- restricted operational details;
- identifiable testimony;
- protected community knowledge;
- evidence in active disputes.

Consent to participate in a pilot is not consent to permanent publication.

---

## 7. Institutional Regeneration Framework audit

### Strengths

The framework correctly treats institutional survival as subordinate to mission and recognizes that dissolution can be healthy.

### Critical defects

#### Funding leverage

GCF tiers, short runways, outcome rebates, module thresholds, and peer scorecards can make voluntary reform materially compulsory.

A safe funding architecture requires:

- separately enacted criteria;
- independent decision-makers;
- notice and evidence;
- support for affected workers and beneficiaries;
- essential-function continuity;
- appeal;
- proportionality;
- no ideological conformity test;
- no automatic voting rights in the fund merely from programme rank.

#### Constitutional redesign

Youth councils, citizen assemblies, Indigenous councils, future-generation guardians, vetoes, and fixed voting shares may be offered as templates. They cannot amend an IGO or public institution's charter by toolkit adoption.

Each redesign requires the institution's lawful amendment route and a derived account of:

- constituency;
- selection;
- mandate;
- conflicts;
- accountability;
- removal;
- relation to existing rights;
- review.

#### Sunsetting and Dark Archive

A purpose audit or Regeneration Index cannot dissolve an institution.

A closure route must handle:

- charter authority;
- employees and unions;
- pensions and benefits;
- beneficiaries;
- pending cases and grants;
- records and confidentiality;
- assets and debts;
- essential services;
- successor responsibility;
- appeal and remedy.

---

## 8. Wise Decision-Making & Integration Protocol audit

### Strengths

WDIP contains valuable safeguards:

- uncertainty;
- dissent;
- provenance;
- multiple epistemologies;
- power analysis;
- democratic interface;
- anti-capture;
- participant support;
- reflective review;
- post-decision learning.

### Critical defects

#### Epistemic certification power

Phase 0 gives an epistemic body the power to certify whether decision conditions meet thresholds and permits remediation to continue until certification.

This may become an external veto over an elected, judicial, community, or emergency authority.

The epistemic assessment should instead classify:

- evidence readiness;
- uncertainty;
- disinformation exposure;
- inaccessible information;
- trust deficits;
- recommended repairs.

The competent decision body then decides whether and how to proceed, giving reasons.

#### Numerical epistemic thresholds

Rules such as:

- two independent sources;
- no epistemology over 60%;
- materials covering 80% of affected populations;

may be useful defaults, but cannot be universal legitimacy thresholds. Some decisions have one authoritative measurement source; some knowledge cannot be shared; some minorities require access despite falling below a percentage.

#### Decision rule

A two-thirds vote with youth consent and no Indigenous Council objection imports three authority claims:

- who may vote;
- who represents youth;
- which Indigenous body may object.

These cannot be universalized. Affected Indigenous nations must control their own representation, and the lawful decision authority must define the decision rule.

#### Knowledge modes

Scientific, experiential, embodied, Indigenous, spiritual, intuitive, and prophetic material may all inform deliberation, but their roles must remain explicit.

A sacred or intuitive contribution may shape:

- values;
- questions;
- interpretation;
- caution;
- relational understanding.

It cannot silently become forensic fact, legal proof, medical evidence, or coercive justification.

---

## 9. Findings register


### IAEG-00 — Method–authority collapse across the cluster — **S0**

Implementation methods, protocol calls, readiness scores, ethics gates, epistemic certification, funding tiers, and experimental adoption are repeatedly allowed to carry or imply the authority of the substantive decision. The cluster lacks a common rule that a method can structure a decision but cannot create jurisdiction, legal power, consent, emergency authority, funding authority, adjudicative authority, or coercive execution.

### IAEG-01 — EGP adopt() lacks an authority constitution — **S1**

`adopt(experiment)` does not require an exact adopting authority, jurisdiction, legal basis, affected-person scope, non-derogable rights, remedy, or separation between voluntary pilot and public-law action. A community, institution, platform, or automated service can therefore appear to adopt measures over people or assets it does not lawfully govern.

### IAEG-02 — Sense signals can become consequential without validation — **S1**

Any human, AI, sensor, or community may create a stress signal with severity and urgency fields. The package lacks a constitutional separation between observation, allegation, validation, jurisdictional triage, investigation, emergency declaration, and action.

### IAEG-03 — Automated proposal and rule-engine escalation can manufacture authority — **S1**

The appendix connects analytics and machine-learning components to an adaptive rules engine and permits auto-generated relationships and proposal generation. There is no fail-closed prohibition on automated adoption, automated emergency activation, automated sanctions, or automated resource allocation.

### IAEG-04 — Public-by-default and immutable governance records conflict with protected information — **S1**

EGP treats actions as public by default and content-addressed or immutable. The package does not adequately separate public accountability from confidential deliberation, protected Indigenous knowledge, survivor data, health data, whistleblower material, sealed evidence, correction, erasure, and lawful record withdrawal.

### IAEG-05 — Identity and capability tokens are mistaken for public authority — **S1**

DIDs and UCAN capabilities can prove identity or delegated technical permission, but cannot establish public-law jurisdiction, affected-nation consent, office-holding legitimacy, fiduciary authority, emergency command, or legal competence. The appendix does not maintain this boundary.

### IAEG-06 — Sunset-by-default is overgeneralized — **S1**

Automatic expiry is valuable for pilots and delegated programmes, but cannot safely expire constitutional rights, essential services, remedies, evidence-preservation duties, child protection, environmental restoration duties, debt and pension obligations, or continuing safety controls.

### IAEG-07 — Local authority is undefined and can mask internal domination — **S1**

The core rule that communities control adoption does not define community membership, affected outsiders, minorities, residents, tenants, workers, migrants, future users, Indigenous nations, dissenters, or transboundary effects. Locality does not itself establish legitimacy.

### IAEG-08 — Implementation & Adaptation ethics gates create hidden approval power — **S1**

The framework gives certified facilitators and Indigenous-framework representatives gatekeeping and dual-key approval roles over adaptation. It does not distinguish advisory ethical review from legal authorization, nor can a global representative substitute for the affected Indigenous nation.

### IAEG-09 — Readiness scoring can determine access and intervention without due process — **S1**

Readiness indices, context rubrics, power maps, and tool-selection systems may classify communities and route them into different governance pathways. The cluster lacks rules for data minimization, contestability, correction, anti-stigmatization, and a prohibition on conditioning rights or essential support on a score.

### IAEG-10 — Quick-start and crisis stacks bypass harmonized emergency interfaces — **S1**

The Implementation & Adaptation and Methods frameworks include rapid diagnostics, crisis-response stacks, 72-hour activation kits, escalation packets, emergency ombudspersons, and responder support without consistently inheriting ECRC/CDEE authority, clocks, access classes, termination, and remedy.

### IAEG-11 — Institutional Regeneration funding creates coercive reform leverage — **S1**

GCF access, tiered funding, outcome-linked rebates, scorecards, peer pressure, and short runways can turn a nominally voluntary reform toolkit into material coercion. Funding criteria, withdrawal, appeal, essential-function continuity, worker protection, and independence are not constitutionally separated.

### IAEG-12 — Institutional redesign templates enumerate vetoes and voting shares without derivation — **S1**

Fixed youth voting shares, future-generation vetoes, Indigenous councils, citizen assemblies, and non-state thresholds are offered as modular blueprints without establishing who may alter an institution's charter, how constituencies are constituted, or how rights and accountability attach.

### IAEG-13 — Graceful sunsetting can become unauthorized dissolution — **S1**

Purpose audits, obsolescence scores, dark archives, and sunsetting protocols can influence closure of institutions or programmes without a complete route for charter authority, employees, pensions, beneficiaries, records, liabilities, essential functions, succession, appeal, and unresolved duties.

### IAEG-14 — WDIP epistemic gate can suspend democratic or emergency action — **S1**

Phase 0 permits an external epistemic body to certify whether decision conditions meet thresholds and to continue remediation until certification. This creates a hidden power to delay, invalidate, or precondition lawful decisions, while urgency exceptions can then bypass the same gate.

### IAEG-15 — WDIP decision rule imports unconstituted veto actors — **S1**

The protocol uses supermajority choice with youth consent and no Indigenous Council objection, but does not constitutionally establish those bodies, their constituencies, scope, conflicts, or relation to affected Indigenous nations and lawful decision authorities.

### IAEG-16 — WDIP knowledge integration risks authority laundering — **S1**

Scientific synthesis, Indigenous knowledge, spiritual councils, prophecy, intuitive input, and AI simulation are combined without a common provenance and consequence membrane. Protected knowledge or spiritual interpretation can be treated as institutional evidence without clear consent and bounded use.

### IAEG-17 — Facilitator certification can become professional monopoly and hidden jurisdiction — **S1**

Training levels, certified facilitators, ethics auditors, catalyst teams, and implementation liaisons may become required intermediaries. The frameworks lack open qualification routes, recognition of local competence, conflict rules, liability, complaints, removal, and a prohibition on withholding participation for lack of certification.

### IAEG-18 — Failure libraries and transparency systems can expose participants — **S1**

Required learning capture, public pilots, story banks, dark archives, video testimony, and failure libraries may retain sensitive institutional, community, worker, health, conflict, or Indigenous information. Anonymization, withdrawal, purpose limitation, access, deletion, and harm remedy are incomplete.

### IAEG-19 — EGP's four documents are internally inconsistent in maturity and scope — **S2**

The one-page guide describes a simple voluntary grammar, while the appendix specifies a large technical stack with identity, authorization, immutable storage, analytics, automated relationships, and deployable services. The package lacks one normative core and a clear non-normative implementation profile.

### IAEG-20 — The word adopt conflates recording and legal effect — **S2**

EGP needs separate operations for proposed trial, consent, authorization, enactment, activation, implementation, suspension, renewal, expiry, and closure. A single adopt record cannot safely represent all of them.

### IAEG-21 — Consent is a free-text field rather than a validated authority object — **S2**

Proposals mention a consent mechanism, but the schemas do not encode affected parties, required consent holders, refusal, withdrawal, internal dissent, capacity, representation, or proof that the adopting entity may rely on that consent.

### IAEG-22 — Severity and urgency are self-asserted — **S2**

Signals can label themselves local, regional, global, or immediate without method, uncertainty, challenge, or verification. These fields could bias routing, visibility, automated proposal generation, or emergency escalation.

### IAEG-23 — Adaptive experimentation lacks a protected-domain exclusion list — **S2**

Some domains are not safely sandboxed through ordinary experimentation: detention, policing, essential services, child protection, health treatment, migration status, irreversible ecological intervention, title transfer, benefit withdrawal, and high-risk technology.

### IAEG-24 — Implementation tools blur recommendation and maintained core — **S2**

The Methods framework distinguishes core tools and forks but does not fully define who controls the core, how deprecation decisions are appealed, how harmful updates are rolled back, or how local forks remain interoperable without central capture.

### IAEG-25 — Community veto language is overbroad — **S2**

A community may refuse a tool for itself, but cannot necessarily veto use by another lawful community, prevent an individual from opting in, or bind affected outsiders. The scope and holder of refusal rights need definition.

### IAEG-26 — Institutional audits lack independence architecture — **S2**

Regeneration audits, readiness assessments, ethics gates, epistemic baselines, and facilitator reviews do not share conflict-of-interest, funding-independence, evidence-access, minority-report, correction, and appeal requirements.

### IAEG-27 — Funding and participation support are not separated — **S2**

Facilitator payment, pilot grants, GCF access, and implementation support can depend on using the cluster's methods. Essential participation support and independent advice should remain available even when a community rejects a recommended tool.

### IAEG-28 — AI roles exceed bounded assistance — **S2**

AI is used for sensing, proposal generation, simulations, readiness diagnostics, tool finding, pattern recognition, and adaptive rules. Human-in-the-loop language is insufficient without prohibited decisions, auditability, model/version records, correction propagation, and non-automation rules.

### IAEG-29 — Retired or stale institutional dependencies remain — **S2**

Active documents continue to reference the retired Indigenous & Traditional Knowledge Governance Framework as an approval or oversight actor, and WDIP retains historical GWGF/Wisdom Council terminology. Retired bodies must not supply live authority.

### IAEG-30 — Cultural adaptation can become cultural essentialism — **S2**

Templates map tools to Indigenous, digital, urban, oral, spiritual, or regional contexts without ensuring self-identification, internal plurality, non-use, and protection against external classification.

### IAEG-31 — Metrics can become mandates through scaling rules — **S2**

Pilot success, readiness scores, module completion, adoption percentages, trust scores, and regeneration tiers may trigger scaling or funding consequences without a distinct authorization and review decision.

### IAEG-32 — Terminology is inconsistent across implementation layers — **S3**

Framework, protocol, toolkit, operating system, operating manual, grammar, stack, service, system call, adoption, activation, and implementation are used without a shared taxonomy of normative force.

### IAEG-33 — Versioning and compatibility are incomplete — **S3**

The four EGP files do not clearly pin one another by version and hash, and the other frameworks import moving names rather than exact compatible releases.

### IAEG-34 — Offline-first claims need a legal parity rule — **S3**

Analog and low-tech alternatives are emphasized, but the documents do not state that paper, oral, assisted, and offline records have equal legal dignity and cannot receive reduced service or slower remedies.

### IAEG-35 — Targets and illustrative numbers look more authoritative than intended — **S3**

Thresholds such as 60% epistemic representation, 80% language coverage, 30% voting power, 3-of-5 modules, 72-hour activation, and fixed training levels require clear labels as examples, defaults, or binding rules.

---

## 10. Constitutional gate results

| Gate | Requirement | Result |
|---|---|---|
| G01 | Method does not create authority | **FAIL** |
| G02 | Exact adopting authority and jurisdiction | **FAIL** |
| G03 | Observation separated from allegation and action | **FAIL** |
| G04 | No automated adoption or emergency activation | **FAIL** |
| G05 | Protected data and lawful deletion | **FAIL** |
| G06 | Identity token not treated as public office | **FAIL** |
| G07 | Sunset exclusions for continuing duties | **CONDITIONAL** |
| G08 | Affected-party and transboundary standing | **CONDITIONAL** |
| G09 | Affected Indigenous nation controls consent | **CONDITIONAL** |
| G10 | Readiness scores contestable and non-dispositive | **FAIL** |
| G11 | ECRC/CDEE inheritance for crisis tools | **FAIL** |
| G12 | Funding independent of ideological or method conformity | **FAIL** |
| G13 | Institutional amendment authority | **FAIL** |
| G14 | Dissolution and unresolved-duty custody | **FAIL** |
| G15 | Epistemic review advisory, not veto | **FAIL** |
| G16 | Decision constituencies lawfully constituted | **FAIL** |
| G17 | Knowledge provenance and protected use | **FAIL** |
| G18 | Facilitator qualification and accountability | **FAIL** |
| G19 | Failure-library privacy and withdrawal | **CONDITIONAL** |
| G20 | One normative EGP core | **FAIL** |
| G21 | Adoption lifecycle decomposed | **FAIL** |
| G22 | Consent represented as structured record | **FAIL** |
| G23 | Severity and urgency validation | **FAIL** |
| G24 | Protected domains excluded from ordinary experiments | **CONDITIONAL** |
| G25 | Core-tool stewardship and fork governance | **CONDITIONAL** |
| G26 | Refusal scope bounded | **CONDITIONAL** |
| G27 | Independent audit architecture | **FAIL** |
| G28 | Participation support independent | **FAIL** |
| G29 | AI prohibited-decision list | **FAIL** |
| G30 | No retired body supplies authority | **FAIL** |
| G31 | Scaling requires new authorization | **FAIL** |
| G32 | Normative-force taxonomy | **FAIL** |
| G33 | Exact version compatibility | **FAIL** |
| G34 | Offline and assisted parity | **CONDITIONAL** |
| G35 | Illustrative thresholds labelled | **FAIL** |
| G36 | Correction, remedy, closure and authority return | **FAIL** |

---

## 11. Compound scenario results

| Scenario | Test | Result |
|---|---|---|
| S01 | Pollution sensor auto-routes emergency response | **UNSAFE** |
| S02 | AI generates proposal and adaptive engine auto-adopts | **UNSAFE** |
| S03 | Community adopts traffic pilot on municipal roads | **CONDITIONAL** |
| S04 | Community adopts curfew affecting non-members | **UNSAFE** |
| S05 | Local majority adopts measure over Indigenous territory | **UNSAFE** |
| S06 | Stress packet publishes survivor health data | **UNSAFE** |
| S07 | Immutable record contains protected sacred knowledge | **UNSAFE** |
| S08 | UCAN token presented as legal authority | **UNSAFE** |
| S09 | Pilot sunset terminates essential water service | **UNSAFE** |
| S10 | Pilot sunset closes temporary grant with orderly closure | **CONDITIONAL** |
| S11 | Readiness score denies a community funding | **UNSAFE** |
| S12 | Ethics gate blocks lawful local adaptation | **UNSAFE** |
| S13 | Retired Indigenous framework representative grants approval | **UNSAFE** |
| S14 | Quick-start stack declares emergency | **UNSAFE** |
| S15 | CDEE-authorized responder uses toolkit under bounded mission | **CONDITIONAL** |
| S16 | GCF tier pressures IGO to change charter | **UNSAFE** |
| S17 | Voluntary IGO adopts internal workflow pilot | **CONDITIONAL** |
| S18 | Regeneration score triggers programme dissolution | **UNSAFE** |
| S19 | Lawful charter authority conducts closure with worker protections | **CONDITIONAL** |
| S20 | WDIP epistemic body indefinitely pauses elected decision | **UNSAFE** |
| S21 | Existential urgency overrides epistemic gate without ECRC route | **UNSAFE** |
| S22 | Youth consent and Indigenous non-objection treated as universal veto | **UNSAFE** |
| S23 | Affected Indigenous nation defines its own consent route | **CONDITIONAL** |
| S24 | Prophecy or intuition recorded as coercive evidence | **UNSAFE** |
| S25 | Protected knowledge used only within consented deliberation | **CONDITIONAL** |
| S26 | Certified facilitator becomes mandatory gatekeeper | **UNSAFE** |
| S27 | Community uses uncertified local facilitator | **CONDITIONAL** |
| S28 | Failure library publishes identifiable whistleblower story | **UNSAFE** |
| S29 | Anonymized learning artifact with withdrawal and access controls | **CONDITIONAL** |
| S30 | AI tool finder recommends non-consequential workshop method | **CONDITIONAL** |
| S31 | AI readiness score routes benefits or sanctions | **UNSAFE** |
| S32 | Community veto prevents another community's independent pilot | **UNSAFE** |
| S33 | Community refuses a tool for its own process | **PASS** |
| S34 | Successful pilot automatically scales into binding policy | **UNSAFE** |
| S35 | Successful pilot informs a separately authorized enactment | **CONDITIONAL** |
| S36 | Paper adoption record receives equal status and remedy | **CONDITIONAL** |

---

## 12. Recommended corrective architecture

The next artifact should be:

# Governance Method, Experiment, Adoption, and Implementation Authority Interface Specification v0.1

**Working ID:** `GMEAIA/0.1`

The final name can be shortened. The constitutional object is more important than the acronym.

### Required action classes

1. observation and sense signal;
2. validation and provenance;
3. jurisdictional triage and referral;
4. proposal;
5. deliberative method selection;
6. affected-party and affected-nation identification;
7. consent and refusal;
8. authority and legal-basis verification;
9. trial authorization;
10. adoption registration;
11. operational activation;
12. monitoring and protected data;
13. review and challenge;
14. renewal, amendment, suspension, and expiry;
15. termination, rollback, remedy, learning capture, and authority return;
16. funding and participation support;
17. facilitator, auditor, and technical-service accountability;
18. emergency and coercive-interface handoffs.

### Canonical doctrine

> **Methods structure how authority is exercised. They do not create the authority.**

### EGP-specific constitutional profile

EGP can remain elegant at the public level:

`sense()` → `propose()` → `adopt()`

But `adopt()` must contain or reference a deeper envelope:

`consent + authority + scope + rights + activation + clocks + review + exit + remedy`

Without that envelope, the record means only:

> “This agent reports that an adoption was claimed.”

It does not mean that the adoption was lawful, binding, active, or valid for downstream execution.

### Protected-domain rule

Ordinary experimental adoption must fail closed for:

- detention, policing, search, seizure, force, and surveillance;
- migration status and border action;
- essential water, food, shelter, health, and income;
- child protection and guardianship;
- title, tenure, rematriation, and eviction;
- irreversible ecological interventions;
- high-risk AI, biotech, and cyber operations;
- criminal or civil adjudication;
- emergency declarations and command.

Those domains may use pilots only through their controlling constitutional interfaces.

---

## 13. Recommended sequence

1. Draft `GMEAIA/0.1`.
2. Reconstitute the four EGP files as one version-pinned package:
   - normative core;
   - schema/profile;
   - quick-start derivative;
   - glossary derivative.
3. Revise EGP so `adopt()` is transport, not authority.
4. Revise Implementation & Adaptation:
   - readiness non-disposition;
   - advisory ethics review;
   - ECRC/CDEE crisis boundary;
   - retired-dependency cleanup.
5. Revise Methods & Tools:
   - authority-effect labels;
   - facilitator accountability;
   - failure-library privacy;
   - bounded refusal.
6. Revise Institutional Regeneration:
   - funding independence;
   - charter amendment;
   - worker and beneficiary protections;
   - lawful closure.
7. Revise WDIP:
   - epistemic assessment without veto;
   - derived decision rights;
   - protected knowledge;
   - democratic and emergency interfaces.
8. Run a final cluster harmonization test.

---

## 14. Bottom line

The cluster should remain a method layer, not become a shadow constitution.

Its promise is substantial: a civilization-wide capacity to sense problems, formulate alternatives, run bounded experiments, adapt tools, regenerate institutions, deliberate under uncertainty, and share learning.

That promise becomes safe when every method can answer:

- Who is acting?
- Under what authority?
- Over whom and what?
- Who must consent?
- What rights cannot be experimented away?
- What information is protected?
- When does the action begin and end?
- Who may challenge it?
- How is harm repaired?
- Where does authority return?

Until those questions are encoded, the cluster's simplicity makes it powerful—but also makes it capable of silently carrying powers it did not earn.
